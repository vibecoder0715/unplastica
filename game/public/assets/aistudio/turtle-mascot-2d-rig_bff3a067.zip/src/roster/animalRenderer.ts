import { TearDrop, TurtlePose } from '../turtle/types';
import {
  drawEmotionProps,
  drawExpressiveAnimalBrows,
  drawExpressiveAnimalMouth,
  drawGlossyAnimalEye,
  drawOvalSpot,
  drawSoftCheekBlushes,
  IRIS_PALETTES,
  renderTurtle,
} from '../turtle/renderer';

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

/**
 * Helper to fill a Path2D with a 3-stop linear gradient, add an inner rim highlight,
 * and stroke with a crisp dark species-tinted outline.
 * If `openStrokePath` is provided, only `openStrokePath` is stroked so the attachment root
 * remains 100% open and seamlessly embedded ("嵌入") into the parent body!
 */
function fillRimAndStroke(
  ctx: CanvasRenderingContext2D,
  path: Path2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  cLight: string,
  cMid: string,
  cDark: string,
  outlineColor: string,
  lineWidth = 3.5,
  rimHighlightColor: string | Path2D = 'rgba(255, 250, 220, 0.55)',
  rimPath?: Path2D,
  openStrokePath?: Path2D,
): void {
  const resolvedOpenStroke =
    openStrokePath ?? (rimHighlightColor instanceof Path2D ? rimHighlightColor : undefined);
  const resolvedRimColor =
    typeof rimHighlightColor === 'string' ? rimHighlightColor : 'rgba(255, 250, 220, 0.55)';

  const grad = ctx.createLinearGradient(x0, y0, x1, y1);
  grad.addColorStop(0, cLight);
  grad.addColorStop(0.55, cMid);
  grad.addColorStop(1, cDark);
  ctx.fillStyle = grad;
  ctx.fill(path);

  if (rimPath) {
    ctx.save();
    ctx.clip(path);
    ctx.strokeStyle = resolvedRimColor;
    ctx.lineWidth = 5.5;
    ctx.stroke(rimPath);
    ctx.restore();
  }

  ctx.lineWidth = lineWidth;
  ctx.strokeStyle = outlineColor;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke(resolvedOpenStroke ?? path);
}

function withHexAlpha(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  if (clean.length === 6) {
    const r = parseInt(clean.slice(0, 2), 16);
    const g = parseInt(clean.slice(2, 4), 16);
    const b = parseInt(clean.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  return hex;
}

/**
 * Draws an articulated mammalian/reptilian limb or paw that is biologically embedded ("嵌入")
 * into the shoulder/hip: its fill feathers smoothly into the torso at the top root (zero
 * semicircular capsule edge!), while becoming 100% opaque across the body boundary so the
 * torso outline is cleanly bridged between the flared shoulder/hip lines.
 */
function drawSculptedPawLimb(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  length: number,
  thickness: number,
  cLight: string,
  cMid: string,
  cDark: string,
  outline: string,
  opts?: {
    pawTipColor?: string;
    pawPadColor?: string;
    stripesColor?: string;
    clawsColor?: string;
    hoofColor?: string;
    webbed?: boolean;
  },
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);

  const w = thickness * 0.5;
  const isStandingLimb = Math.abs(angle) < 1.0;
  const rootArch = isStandingLimb ? -14 : -w * 0.85;
  // Closed fill path with flared anatomical shoulder/hip root and sculpted lower paw
  const fillP = new Path2D();
  fillP.moveTo(-w * 1.06, 0);
  fillP.quadraticCurveTo(0, rootArch, w * 1.06, 0);
  fillP.bezierCurveTo(w * 1.02, length * 0.24, w * 1.26, length * 0.55, w * 1.15, length * 0.88);
  fillP.bezierCurveTo(w * 0.85, length + w * 0.85, -w * 0.3, length + w * 0.95, -w * 0.92, length);
  fillP.bezierCurveTo(-w * 1.25, length * 0.78, -w * 1.04, length * 0.34, -w * 1.06, 0);
  fillP.closePath();

  // Open stroke path starting below the root and flaring out into the shoulder/hip
  const strokeP = new Path2D();
  strokeP.moveTo(-w * 1.04, 4);
  strokeP.bezierCurveTo(-w * 1.02, length * 0.34, -w * 1.25, length * 0.78, -w * 0.92, length);
  strokeP.bezierCurveTo(-w * 0.3, length + w * 0.95, w * 0.85, length + w * 0.85, w * 1.15, length * 0.88);
  strokeP.bezierCurveTo(w * 1.26, length * 0.55, w * 1.02, length * 0.24, w * 1.04, 4);

  const rim = new Path2D();
  rim.moveTo(-w * 0.82, Math.max(18, length * 0.24));
  rim.bezierCurveTo(-w * 1.04, length * 0.48, -w * 1.08, length * 0.78, -w * 0.75, length * 0.95);

  // 100% opaque anatomical gradient starting at cMid so limbs weld seamlessly into the cMid torso flank
  const grad = ctx.createLinearGradient(0, rootArch, 0, length + w * 0.8);
  grad.addColorStop(0, cMid);
  grad.addColorStop(0.55, cMid);
  grad.addColorStop(1, cDark);
  ctx.fillStyle = grad;
  ctx.fill(fillP);

  ctx.save();
  ctx.clip(fillP);
  ctx.strokeStyle = 'rgba(255, 248, 215, 0.34)';
  ctx.lineWidth = 4.5;
  ctx.stroke(rim);

  if (opts?.pawTipColor) {
    ctx.fillStyle = opts.pawTipColor;
    ctx.beginPath();
    ctx.ellipse(w * 0.1, length * 0.92, w * 1.25, w * 0.85, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  if (opts?.stripesColor) {
    ctx.fillStyle = opts.stripesColor;
    for (const sy of [0.32, 0.52, 0.68]) {
      ctx.beginPath();
      ctx.moveTo(-w * 1.2, length * sy - 5);
      ctx.quadraticCurveTo(0, length * sy + 3, w * 0.4, length * sy - 2);
      ctx.quadraticCurveTo(0, length * sy + 9, -w * 1.2, length * sy + 4);
      ctx.closePath();
      ctx.fill();
    }
  }

  if (opts?.hoofColor) {
    ctx.fillStyle = opts.hoofColor;
    ctx.fillRect(-w * 1.3, length * 0.82, w * 2.6, w * 1.2);
    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 2.0;
    ctx.beginPath();
    ctx.moveTo(0, length * 0.84);
    ctx.lineTo(0, length + w);
    ctx.stroke();
  }

  if (opts?.pawPadColor) {
    ctx.fillStyle = opts.pawPadColor;
    drawOvalSpot(ctx, w * 0.08, length * 0.86, w * 0.48, w * 0.36, 0.1);
    drawOvalSpot(ctx, -w * 0.42, length * 0.96, w * 0.2, w * 0.16, -0.2);
    drawOvalSpot(ctx, w * 0.05, length * 0.99, w * 0.22, w * 0.16, 0);
    drawOvalSpot(ctx, w * 0.52, length * 0.95, w * 0.2, w * 0.16, 0.2);
  }

  ctx.restore();

  // Stroke ONLY the open outer contour (never across the shoulder/hip root!)
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = outline;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke(strokeP);

  // Claws or toe dividers
  if (opts?.clawsColor) {
    ctx.fillStyle = opts.clawsColor;
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.2;
    for (const cxOff of [-w * 0.45, 0, w * 0.45]) {
      ctx.beginPath();
      ctx.moveTo(cxOff - 2, length + w * 0.32);
      ctx.quadraticCurveTo(cxOff + 3, length + w * 0.88, cxOff + 7, length + w * 0.48);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  } else if (!opts?.hoofColor) {
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(-w * 0.2, length + w * 0.58);
    ctx.lineTo(-w * 0.15, length + w * 0.18);
    ctx.moveTo(w * 0.32, length + w * 0.56);
    ctx.lineTo(w * 0.25, length + w * 0.18);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Helper to draw an open-rooted tail that embeds seamlessly ("嵌入") into the posterior body.
 * Supports both Path2D pairs and numeric coordinate arguments.
 */
function drawEmbeddedTail(
  ctx: CanvasRenderingContext2D,
  fillPathOrBaseX: Path2D | number,
  openStrokePathOrBaseY: Path2D | number,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  cLight: string | number,
  cMid: string,
  cDark: string,
  outline: string,
  lineWidth: number | string | ((ctx: CanvasRenderingContext2D) => void) = 3.5,
  decorateInside?: ((ctx: CanvasRenderingContext2D) => void) | (() => void),
): void {
  if (typeof fillPathOrBaseX === 'number' && typeof openStrokePathOrBaseY === 'number') {
    if (typeof cLight === 'number') {
      // 13-arg articulated polar signature: (ctx, baseX, baseY, angle, length, baseW, tipW, curlY, cLight, cMid, cDark, outline, decorateFn)
      const baseX = fillPathOrBaseX;
      const baseY = openStrokePathOrBaseY;
      const angle = x0;
      const length = y0;
      const baseHalfW = x1 * 0.5;
      const tipHalfW = Math.max(3, y1 * 0.5);
      const curlY = cLight;
      const colLight = cMid;
      const colMid = cDark;
      const colDark = outline;
      const colOutline = typeof lineWidth === 'string' ? lineWidth : '#1f1610';
      const decFn = typeof decorateInside === 'function' ? decorateInside : undefined;

      ctx.save();
      ctx.translate(baseX, baseY);
      ctx.rotate(angle);

      const fillP = new Path2D();
      fillP.moveTo(0, -baseHalfW);
      fillP.quadraticCurveTo(10, 0, 0, baseHalfW);
      fillP.bezierCurveTo(-length * 0.35, baseHalfW * 0.95, -length * 0.72, curlY + tipHalfW, -length, curlY);
      fillP.bezierCurveTo(-length * 0.72, curlY - tipHalfW, -length * 0.35, -baseHalfW * 0.85, 0, -baseHalfW);
      fillP.closePath();

      const strokeP = new Path2D();
      strokeP.moveTo(0, -baseHalfW);
      strokeP.bezierCurveTo(-length * 0.35, -baseHalfW * 0.85, -length * 0.72, curlY - tipHalfW, -length, curlY);
      strokeP.bezierCurveTo(-length * 0.72, curlY + tipHalfW, -length * 0.35, baseHalfW * 0.95, 0, baseHalfW);

      fillRimAndStroke(
        ctx,
        fillP,
        0,
        -baseHalfW,
        -length * 0.5,
        Math.max(baseHalfW, curlY + tipHalfW),
        colLight,
        colMid,
        colDark,
        colOutline,
        3.4,
        strokeP,
      );

      if (decFn) {
        ctx.save();
        ctx.clip(fillP);
        decFn(ctx);
        ctx.restore();
        ctx.lineWidth = 3.4;
        ctx.strokeStyle = colOutline;
        ctx.stroke(strokeP);
      }

      ctx.restore();
      return;
    }

    const baseX = fillPathOrBaseX;
    const baseY = openStrokePathOrBaseY;
    const tipX = x0;
    const tipY = y0;
    const baseHalfW = x1 * 0.5;
    const curveY = y1;
    const midX = (baseX + tipX) * 0.5;
    const midY = (baseY + tipY) * 0.5 + curveY;

    const fillP = new Path2D();
    fillP.moveTo(baseX + 8, baseY - baseHalfW);
    fillP.quadraticCurveTo(midX, midY - baseHalfW * 0.55, tipX, tipY);
    fillP.quadraticCurveTo(midX, midY + baseHalfW * 0.65, baseX + 8, baseY + baseHalfW);
    fillP.closePath();

    const strokeP = new Path2D();
    strokeP.moveTo(baseX, baseY - baseHalfW);
    strokeP.quadraticCurveTo(midX, midY - baseHalfW * 0.55, tipX, tipY);
    strokeP.quadraticCurveTo(midX, midY + baseHalfW * 0.65, baseX, baseY + baseHalfW);

    fillRimAndStroke(
      ctx,
      fillP,
      Math.min(baseX, tipX),
      Math.min(baseY, tipY) - baseHalfW,
      Math.max(baseX, tipX),
      Math.max(baseY, tipY) + baseHalfW,
      cLight,
      cMid,
      cDark,
      outline,
      3.4,
      'rgba(255, 250, 220, 0.5)',
      undefined,
      strokeP,
    );
    return;
  }

  const fillPath = fillPathOrBaseX as Path2D;
  const openStrokePath = openStrokePathOrBaseY as Path2D;
  const resolvedLW = typeof lineWidth === 'number' ? lineWidth : 3.5;
  fillRimAndStroke(
    ctx,
    fillPath,
    x0,
    y0,
    x1,
    y1,
    cLight as string,
    cMid,
    cDark,
    outline,
    resolvedLW,
    'rgba(255, 250, 220, 0.5)',
    undefined,
    openStrokePath,
  );
  if (decorateInside) {
    ctx.save();
    ctx.clip(fillPath);
    decorateInside(ctx);
    ctx.restore();
    ctx.lineWidth = resolvedLW;
    ctx.strokeStyle = outline;
    ctx.stroke(openStrokePath);
  }
}

const LAND_STANDING_ANIMAL_IDS = new Set<string>([
  'animal_01_malayan_tiger',
  'animal_02_asian_elephant',
  'animal_03_malayan_tapir',
  'animal_04_orangutan',
  'animal_05_sun_bear',
  'animal_06_sunda_pangolin',
  'animal_07_sambar_deer',
  'animal_08_greater_mousedeer',
  'animal_09_long_tailed_macaque',
  'animal_10_dusky_leaf_monkey',
  'animal_11_malayan_porcupine',
  'animal_12_malayan_flying_fox',
  'animal_13_raffles_banded_langur',
  'animal_14_malayan_crested_fireback',
  'animal_15_rhinoceros_hornbill',
  'animal_16_reticulated_python',
  'animal_17_clouded_monitor_lizard',
  'animal_18_black_giant_squirrel',
  'animal_19_smooth_coated_otter',
  'animal_23_southern_river_terrapin',
  'animal_24_southeast_asian_box_turtle',
  'animal_25_asian_water_monitor',
  'animal_41_giant_panda',
]);

/**
 * Renders any of the 41 Animal species (`A01`–`A41`) as a pure 2D vector Canvas rig.
 * - Land animals stand grounded on their planted feet (`shadowY = 186`, damped vertical bob).
 * - Sea/aquatic animals float and swim naturally.
 * - All limbs, tails, necks, and quills are biologically embedded ("嵌入") via open-root strokes.
 */
export function renderAnimalAsset(
  ctx: CanvasRenderingContext2D,
  assetId: string,
  width: number,
  height: number,
  pose: TurtlePose,
  tearDrops: TearDrop[],
  elapsedSec?: number,
): void {
  void elapsedSec;
  if (assetId === 'animal_28_green_sea_turtle') {
    renderTurtle(ctx, width, height, pose, tearDrops);
    return;
  }

  ctx.clearRect(0, 0, width, height);
  void tearDrops;

  const isLandStanding = LAND_STANDING_ANIMAL_IDS.has(assetId);
  // Species-specific scale multipliers requested by user:
  // A30 Whale Shark (+80% within viewport), A32 False Killer Whale (+30%), A33 Blacktip Reef Shark (+30%)
  const speciesScaleMult =
    assetId === 'animal_30_whale_shark'
      ? 1.48
      : assetId === 'animal_32_false_killer_whale' || assetId === 'animal_33_blacktip_reef_shark'
        ? 1.28
        : 1.0;

  ctx.save();
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  const cx = width * 0.5;
  const cy = height * (isLandStanding ? 0.5 : 0.49);
  const baseRadius = Math.min(width, height * 1.08);
  const scale = clamp((baseRadius / 650) * speciesScaleMult, 0.35, 1.85);

  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  // Continuous horizontal direction turn (facing: +1 right, -1 left)
  const dirSign = pose.facing >= 0 ? 1 : -1;
  const turnSquash = 0.22 + 0.78 * Math.abs(pose.facing);
  ctx.scale(dirSign * turnSquash, 1);

  // Ground contact shadow for standing land animals vs floating water shadow for aquatic animals
  const effectiveBodyY = isLandStanding ? pose.bodyY * 0.14 : pose.bodyY;
  const effectiveBodyRot = isLandStanding ? pose.bodyRot * 0.22 : pose.bodyRot;

  ctx.save();
  const shadowY = isLandStanding ? 186 : 232 - effectiveBodyY * 0.2;
  const shadowScale = isLandStanding ? 1.04 : 1 - effectiveBodyY * 0.003;
  ctx.translate(-6, shadowY);
  ctx.scale(shadowScale, isLandStanding ? 0.19 : 0.22);
  const shGrad = ctx.createRadialGradient(0, 0, 14, 0, 0, 205);
  shGrad.addColorStop(0, isLandStanding ? 'rgba(65, 90, 65, 0.22)' : 'rgba(75, 115, 125, 0.16)');
  shGrad.addColorStop(0.65, isLandStanding ? 'rgba(65, 90, 65, 0.09)' : 'rgba(75, 115, 125, 0.06)');
  shGrad.addColorStop(1, 'rgba(65, 90, 65, 0)');
  ctx.fillStyle = shGrad;
  ctx.beginPath();
  ctx.arc(0, 0, 205, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Root body transform (grounded standing posture for land animals, swimming posture for aquatic)
  const groundedPose: TurtlePose = isLandStanding
    ? {
        ...pose,
        bodyY: effectiveBodyY,
        bodyRot: effectiveBodyRot,
        shellOffsetY: pose.shellOffsetY * 0.25,
        shellRot: pose.shellRot * 0.25,
        hindNearAngle: pose.hindNearAngle * 0.18,
        hindFarAngle: pose.hindFarAngle * 0.18,
      }
    : pose;

  ctx.save();
  ctx.translate(groundedPose.bodyX, groundedPose.bodyY);
  ctx.rotate(groundedPose.bodyRot);
  ctx.scale(groundedPose.bodyScaleX, groundedPose.bodyScaleY);

  switch (assetId) {
    case 'animal_01_malayan_tiger':
      drawMalayanTigerRig(ctx, groundedPose);
      break;
    case 'animal_02_asian_elephant':
      drawAsianElephantRig(ctx, groundedPose);
      break;
    case 'animal_03_malayan_tapir':
      drawMalayanTapirRig(ctx, groundedPose);
      break;
    case 'animal_04_orangutan':
      drawPrimateRig(ctx, groundedPose, 'orangutan');
      break;
    case 'animal_05_sun_bear':
      drawSunBearRig(ctx, groundedPose);
      break;
    case 'animal_06_sunda_pangolin':
      drawSundaPangolinRig(ctx, groundedPose);
      break;
    case 'animal_07_sambar_deer':
      drawCervidRig(ctx, groundedPose, true);
      break;
    case 'animal_08_greater_mousedeer':
      drawCervidRig(ctx, groundedPose, false);
      break;
    case 'animal_09_long_tailed_macaque':
      drawPrimateRig(ctx, groundedPose, 'macaque');
      break;
    case 'animal_10_dusky_leaf_monkey':
      drawPrimateRig(ctx, groundedPose, 'dusky');
      break;
    case 'animal_13_raffles_banded_langur':
      drawPrimateRig(ctx, groundedPose, 'langur');
      break;
    case 'animal_11_malayan_porcupine':
      drawMalayanPorcupineRig(ctx, groundedPose);
      break;
    case 'animal_12_malayan_flying_fox':
      drawMalayanFlyingFoxRig(ctx, groundedPose);
      break;
    case 'animal_14_malayan_crested_fireback':
      drawAvianRig(ctx, groundedPose, 'fireback');
      break;
    case 'animal_15_rhinoceros_hornbill':
      drawAvianRig(ctx, groundedPose, 'hornbill');
      break;
    case 'animal_16_reticulated_python':
      drawReticulatedPythonRig(ctx, groundedPose);
      break;
    case 'animal_17_clouded_monitor_lizard':
      drawMonitorLizardRig(ctx, groundedPose, true);
      break;
    case 'animal_25_asian_water_monitor':
      drawMonitorLizardRig(ctx, groundedPose, false);
      break;
    case 'animal_18_black_giant_squirrel':
      drawBlackGiantSquirrelRig(ctx, groundedPose);
      break;
    case 'animal_19_smooth_coated_otter':
      drawSmoothCoatedOtterRig(ctx, groundedPose);
      break;
    case 'animal_20_giant_freshwater_prawn':
      drawCrustaceanRig(ctx, groundedPose, 'prawn');
      break;
    case 'animal_38_harlequin_shrimp':
      drawCrustaceanRig(ctx, groundedPose, 'harlequin');
      break;
    case 'animal_21_asian_arowana':
      drawSculptedFishRig(ctx, groundedPose, 'arowana');
      break;
    case 'animal_22_clown_featherback':
      drawSculptedFishRig(ctx, groundedPose, 'featherback');
      break;
    case 'animal_23_southern_river_terrapin':
      drawRiverTerrapinRig(ctx, groundedPose);
      break;
    case 'animal_24_southeast_asian_box_turtle':
      drawBoxTurtleRig(ctx, groundedPose);
      break;
    case 'animal_29_hawksbill_sea_turtle':
      drawHawksbillSeaTurtleRig(ctx, groundedPose);
      break;
    case 'animal_26_giant_snakehead':
      drawSculptedFishRig(ctx, groundedPose, 'snakehead');
      break;
    case 'animal_34_clownfish':
      drawSculptedFishRig(ctx, groundedPose, 'clownfish');
      break;
    case 'animal_27_dugong':
      drawMarineMammalRig(ctx, groundedPose, 'dugong');
      break;
    case 'animal_31_indo_pacific_humpback_dolphin':
      drawMarineMammalRig(ctx, groundedPose, 'pink_dolphin');
      break;
    case 'animal_32_false_killer_whale':
      drawMarineMammalRig(ctx, groundedPose, 'false_killer_whale');
      break;
    case 'animal_30_whale_shark':
      drawSharkRig(ctx, groundedPose, 'whale_shark');
      break;
    case 'animal_33_blacktip_reef_shark':
      drawSharkRig(ctx, groundedPose, 'blacktip');
      break;
    case 'animal_35_giant_clam':
      drawGiantClamRig(ctx, groundedPose);
      break;
    case 'animal_36_bluespotted_ribbontail_ray':
      drawBluespottedRayRig(ctx, groundedPose);
      break;
    case 'animal_37_coconut_octopus':
      drawCephalopodRig(ctx, groundedPose, 'octopus');
      break;
    case 'animal_39_cuttlefish':
      drawCephalopodRig(ctx, groundedPose, 'cuttlefish');
      break;
    case 'animal_40_sea_star':
      drawHornedSeaStarRig(ctx, groundedPose);
      break;
    case 'animal_41_giant_panda':
      drawGiantPandaRig(ctx, groundedPose);
      break;
    default:
      drawMalayanTigerRig(ctx, groundedPose);
      break;
  }

  // Shared white-bordered comic emotion props (waving rays, laugh marks, question mark, angry vein, sleepy Zzz, blush hearts)
  drawEmotionProps(ctx, groundedPose);

  ctx.restore();
  ctx.restore();
}

/* ============================================================================
 * A01: MALAYAN TIGER (Panthera tigris jacksoni)
 * ========================================================================== */
function drawMalayanTigerRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#261408';
  const cLight = '#ffbe4f';
  const cMid = '#f28b24';
  const cDark = '#c95e10';
  const creamLight = '#fffDF5';
  const creamDark = '#f0dec2';
  const stripeCol = '#241207';

  // 1. Far Hind Leg (Back-Right, grounded at y=186)
  drawSculptedPawLimb(ctx, -52, 82, pose.hindFarAngle * 0.35, 104, 50, cMid, cDark, '#9e4408', outline, {
    pawTipColor: creamLight,
    stripesColor: stripeCol,
    clawsColor: '#fff5e0',
  });

  // 2. Far Front Limb (Front-Right, grounded at y=186 when not raised to chin for 'wondered')
  const drawTigerFarFront = () => {
    if (pose.farFlipperChinAmount > 0.4) {
      drawSculptedPawLimb(ctx, 52, 64, -2.45 + pose.farFlipperAngle * 0.35, 96, 50, cLight, cMid, cDark, outline, {
        pawTipColor: creamLight,
        pawPadColor: '#f48fb1',
        stripesColor: stripeCol,
      });
    } else {
      drawSculptedPawLimb(ctx, 52, 78, pose.farFlipperAngle * 0.35, 108, 52, cLight, cMid, cDark, outline, {
        pawTipColor: creamLight,
        stripesColor: stripeCol,
        clawsColor: '#fff5e0',
      });
    }
  };
  if (pose.farFlipperChinAmount <= 0.4) drawTigerFarFront();

  // 3. Sculpted Torso & Fluffy Cream Chest Ruff
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const torso = new Path2D();
  torso.moveTo(-148, 38);
  torso.bezierCurveTo(-158, -28, -92, -62, -10, -52);
  torso.bezierCurveTo(64, -44, 96, 8, 86, 76);
  torso.bezierCurveTo(76, 134, -8, 146, -84, 132);
  torso.bezierCurveTo(-132, 122, -144, 82, -148, 38);
  torso.closePath();
  fillRimAndStroke(ctx, torso, -120, -55, 60, 135, cLight, cMid, cDark, outline, 3.6);

  ctx.save();
  ctx.clip(torso);
  ctx.fillStyle = stripeCol;
  const backStripes: Array<[number, number, number, number, number]> = [
    [-115, -18, 12, 38, 0.25],
    [-82, -26, 13, 44, 0.18],
    [-46, -30, 12, 42, 0.12],
    [-12, -26, 11, 36, 0.08],
    [-124, 24, 26, 9, -0.25],
    [-116, 48, 24, 8, -0.2],
  ];
  for (const [sx, sy, srx, sry, srot] of backStripes) {
    drawOvalSpot(ctx, sx, sy, srx, sry, srot);
  }

  // Cream chest ruff positioned on the front chest (x = 18..84) between the front legs
  // so the near front leg at x = -4 welds directly into pure orange shoulder fur!
  const chest = new Path2D();
  chest.moveTo(22, 18);
  chest.bezierCurveTo(48, 8, 82, 24, 84, 76);
  chest.bezierCurveTo(84, 120, 52, 138, 18, 130);
  chest.bezierCurveTo(14, 92, 14, 46, 22, 18);
  chest.closePath();
  const chGrad = ctx.createLinearGradient(20, 15, 50, 135);
  chGrad.addColorStop(0, creamLight);
  chGrad.addColorStop(1, creamDark);
  ctx.fillStyle = chGrad;
  ctx.fill(chest);
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);

  // 4. Articulated Striped Tail drawn over posterior rump with open root & untwisted parallel Bezier contours ("嵌入")!
  ctx.save();
  ctx.translate(-142, 52);
  ctx.rotate(pose.hindNearAngle * 0.45 + Math.sin(pose.waveRaysPhase * 0.7) * 0.08);
  const tailFill = new Path2D();
  tailFill.moveTo(2, -13);
  tailFill.quadraticCurveTo(16, 0, 2, 13);
  tailFill.bezierCurveTo(-52, -8, -110, -64, -124, -122);
  tailFill.bezierCurveTo(-130, -148, -102, -156, -92, -130);
  tailFill.bezierCurveTo(-78, -82, -32, -32, 2, -13);
  tailFill.closePath();
  const tailOpen = new Path2D();
  tailOpen.moveTo(0, -13);
  tailOpen.bezierCurveTo(-32, -32, -78, -82, -92, -130);
  tailOpen.bezierCurveTo(-102, -156, -130, -148, -124, -122);
  tailOpen.bezierCurveTo(-110, -64, -52, -8, 0, 13);
  fillRimAndStroke(ctx, tailFill, -80, -130, 8, 12, cLight, cMid, cMid, outline, 3.4, tailOpen);
  ctx.save();
  ctx.clip(tailFill);
  ctx.fillStyle = stripeCol;
  drawOvalSpot(ctx, -110, -135, 22, 18, 0.2);
  drawOvalSpot(ctx, -88, -92, 18, 8, 0.5);
  drawOvalSpot(ctx, -64, -62, 18, 8, 0.6);
  drawOvalSpot(ctx, -38, -36, 16, 7, 0.7);
  ctx.restore();
  ctx.lineWidth = 3.4;
  ctx.strokeStyle = outline;
  ctx.stroke(tailOpen);
  ctx.restore();
  ctx.restore();

  // Near Hind Leg & Near Front Leg drawn over torso with feathered roots so all 4 feet stand on the ground!
  drawSculptedPawLimb(ctx, -108, 80, pose.hindNearAngle * 0.35, 106, 58, cLight, cMid, cDark, outline, {
    pawTipColor: creamLight,
    stripesColor: stripeCol,
    clawsColor: '#fff5e0',
  });

  const downAmt = pose.nearFlipperDownAmount;
  const waveAmt = clamp(1 - downAmt - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, 54, cLight, cMid, cDark, outline, {
      pawTipColor: creamLight,
      stripesColor: stripeCol,
      clawsColor: '#fff5e0',
    });
  }

  // 5. Articulated Tiger Head Group
  ctx.save();
  ctx.translate(38 + pose.headX, -38 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey, erot, isLeft] of [
    [-82, -108, -0.38, true],
    [88, -94, 0.42, false],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    ctx.rotate(erot);
    const earP = new Path2D();
    earP.arc(0, 0, 36, Math.PI * 0.85, Math.PI * 2.15);
    earP.closePath();
    fillRimAndStroke(ctx, earP, 0, -36, 0, 20, cLight, cMid, cDark, outline, 3.5);
    ctx.save();
    ctx.clip(earP);
    ctx.fillStyle = stripeCol;
    ctx.beginPath();
    ctx.arc(0, -24, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = creamLight;
    drawOvalSpot(ctx, isLeft ? 4 : -4, -2, 18, 16, 0);
    ctx.restore();
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = outline;
    ctx.stroke(earP);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.moveTo(4, -128);
  headP.bezierCurveTo(78, -126, 126, -72, 124, -12);
  headP.bezierCurveTo(142, 12, 136, 54, 102, 74);
  headP.bezierCurveTo(64, 98, -42, 102, -96, 74);
  headP.bezierCurveTo(-136, 52, -138, 6, -118, -22);
  headP.bezierCurveTo(-116, -84, -64, -130, 4, -128);
  headP.closePath();

  const hGrad = ctx.createRadialGradient(-8 + lookX * 0.4, -75 + lookY * 0.4, 16, 4, -10, 165);
  hGrad.addColorStop(0, '#ffd46b');
  hGrad.addColorStop(0.45, cLight);
  hGrad.addColorStop(0.82, cMid);
  hGrad.addColorStop(1, cDark);
  ctx.fillStyle = hGrad;
  ctx.fill(headP);

  ctx.save();
  ctx.clip(headP);
  ctx.fillStyle = creamLight;
  drawOvalSpot(ctx, -84 + lookX * 0.5, 34 + lookY * 0.5, 48, 38, -0.2);
  drawOvalSpot(ctx, 94 + lookX * 0.5, 40 + lookY * 0.5, 44, 34, 0.2);
  drawOvalSpot(ctx, -38 + lookX * 0.6, -54 + lookY * 0.6, 22, 14, -0.25);
  drawOvalSpot(ctx, 74 + lookX * 0.6, -42 + lookY * 0.6, 20, 13, 0.25);
  drawOvalSpot(ctx, 18 + lookX * 0.85, 32 + lookY * 0.85, 52, 34, 0.08);

  ctx.fillStyle = stripeCol;
  drawOvalSpot(ctx, 14 + lookX * 0.5, -102 + lookY * 0.5, 7, 26, 0.05);
  drawOvalSpot(ctx, -22 + lookX * 0.5, -96 + lookY * 0.5, 22, 7, 0.35);
  drawOvalSpot(ctx, 50 + lookX * 0.5, -92 + lookY * 0.5, 22, 7, -0.35);
  drawOvalSpot(ctx, -18 + lookX * 0.5, -76 + lookY * 0.5, 18, 6, 0.25);
  drawOvalSpot(ctx, 46 + lookX * 0.5, -72 + lookY * 0.5, 18, 6, -0.25);
  drawOvalSpot(ctx, -92 + lookX * 0.5, 18 + lookY * 0.5, 22, 6, -0.15);
  drawOvalSpot(ctx, -86 + lookX * 0.5, 38 + lookY * 0.5, 24, 6, -0.05);
  drawOvalSpot(ctx, 98 + lookX * 0.5, 24 + lookY * 0.5, 20, 6, 0.15);
  drawOvalSpot(ctx, 94 + lookX * 0.5, 44 + lookY * 0.5, 22, 6, 0.05);

  drawSoftCheekBlushes(ctx, -58 + lookX * 0.8, 22 + lookY * 0.8, 86 + lookX * 0.8, 32 + lookY * 0.8, 28, 16, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 42 + lookY, 0.88, 0.08, pose, outline);

  ctx.save();
  ctx.translate(22 + lookX, 10 + lookY);
  const noseP = new Path2D();
  noseP.moveTo(-20, -8);
  noseP.quadraticCurveTo(0, -14, 20, -8);
  noseP.quadraticCurveTo(16, 10, 0, 14);
  noseP.quadraticCurveTo(-16, 10, -20, -8);
  noseP.closePath();
  fillRimAndStroke(ctx, noseP, 0, -12, 0, 14, '#ffa6b8', '#f06292', '#ad1457', outline, 3.0);
  ctx.restore();

  drawGlossyAnimalEye(ctx, 'left', -38 + lookX * 0.85, -16 + lookY * 0.85, 30, 35, -0.1, pose, IRIS_PALETTES.emerald, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 74 + lookX * 0.85, -4 + lookY * 0.85, 26, 32, 0.14, pose, IRIS_PALETTES.emerald, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -38 + lookX * 0.85, -62 + lookY * 0.85, 74 + lookX * 0.85, -48 + lookY * 0.85, 42, pose, outline, 4.5);

  ctx.restore();

  // 6. Foreground Waving Paw & Chin-Touching Paw (drawn AFTER head so hand is never covered!)
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      42 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      118,
      54,
      cLight,
      cMid,
      cDark,
      outline,
      {
        pawTipColor: creamLight,
        pawPadColor: '#f48fb1',
        stripesColor: stripeCol,
      },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) drawTigerFarFront();
}

/* ============================================================================
 * A02: ASIAN ELEPHANT (Elephas maximus)
 * - Removed '<' line artifact on center of trunk
 * - Ivory tusks enlarged by +30% with realistic curved ivory taper
 * - Embedded legs & tail
 * ========================================================================== */
function drawAsianElephantRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#232830';
  const cLight = '#b0bec5';
  const cMid = '#8796a1';
  const cDark = '#5c6b75';
  const nailCol = '#f5ebd6';

  drawSculptedPawLimb(ctx, -52, 82, pose.hindFarAngle * 0.35, 104, 58, cMid, cDark, '#48555e', outline, {
    pawTipColor: nailCol,
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 54, 78, pose.farFlipperAngle * 0.35, 108, 58, cLight, cMid, cDark, outline, {
      pawTipColor: nailCol,
    });
  }

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const torso = new Path2D();
  torso.ellipse(-34, 42, 128, 92, 0.06, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -120, -45, 50, 130, cLight, cMid, cDark, outline, 3.6);

  // Embedded tufted elephant tail drawn right on the posterior rump contour with open root so there is zero cut-line!
  drawEmbeddedTail(
    ctx,
    -160,
    40,
    pose.hindNearAngle * 0.45 + Math.sin(pose.waveRaysPhase) * 0.06,
    66,
    18,
    5,
    18,
    cLight,
    cMid,
    cMid,
    outline,
    (tCtx) => {
      tCtx.fillStyle = '#2d333b';
      drawOvalSpot(tCtx, -66, 18, 12, 7, 0.35);
    },
  );
  ctx.restore();

  drawSculptedPawLimb(ctx, -110, 80, pose.hindNearAngle * 0.35, 106, 64, cLight, cMid, cDark, outline, {
    pawTipColor: nailCol,
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, 60, cLight, cMid, cDark, outline, {
      pawTipColor: nailCol,
    });
  }

  // Head, Large Fan Ears & Expressive Curved Trunk
  ctx.save();
  ctx.translate(38 + pose.headX, -34 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey, rx, ry, rot] of [
    [-112, -12, 62, 78, -0.22],
    [114, 2, 52, 68, 0.25],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    ctx.rotate(rot + Math.sin(pose.waveRaysPhase) * 0.04);
    const earP = new Path2D();
    earP.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, -rx, -ry, rx, ry, cLight, cMid, cDark, outline, 3.5);
    ctx.save();
    ctx.clip(earP);
    ctx.fillStyle = 'rgba(244, 164, 176, 0.65)';
    drawOvalSpot(ctx, 0, 12, rx * 0.72, ry * 0.7, 0);
    ctx.restore();
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = outline;
    ctx.stroke(earP);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.moveTo(0, -122);
  headP.bezierCurveTo(45, -138, 108, -96, 108, -12);
  headP.bezierCurveTo(108, 58, 64, 92, 4, 92);
  headP.bezierCurveTo(-68, 92, -108, 52, -106, -16);
  headP.bezierCurveTo(-104, -96, -42, -136, 0, -122);
  headP.closePath();
  fillRimAndStroke(ctx, headP, -60, -125, 40, 90, '#c5d1d8', cLight, cMid, outline, 3.7);

  ctx.save();
  ctx.clip(headP);
  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 24 + lookY * 0.8, 78 + lookX * 0.8, 32 + lookY * 0.8, 28, 16, pose.blushAlpha);
  ctx.restore();

  drawExpressiveAnimalMouth(ctx, 12 + lookX, 54 + lookY, 0.82, 0.08, pose, outline);

  // Left Ivory Tusk (+30% larger, curving out from cheek socket with open root)
  const drawIvoryTusk = (tx: number, ty: number, dir: number, scale: number) => {
    ctx.save();
    ctx.translate(tx + lookX, ty + lookY);
    ctx.scale(scale, scale);
    const tuskP = new Path2D();
    tuskP.moveTo(-11, -10);
    tuskP.bezierCurveTo(-9, 24, 6 * dir, 48, 28 * dir, 38);
    tuskP.bezierCurveTo(14 * dir, 22, 6, 4, 9, -12);
    tuskP.closePath();
    const tuskOpen = new Path2D();
    tuskOpen.moveTo(-10, -2);
    tuskOpen.bezierCurveTo(-9, 24, 6 * dir, 48, 28 * dir, 38);
    tuskOpen.bezierCurveTo(14 * dir, 22, 6, 4, 8, -4);
    fillRimAndStroke(ctx, tuskP, -8, -6, 22 * dir, 38, '#fffffa', '#faf0d7', '#dfc896', outline, 2.6, tuskOpen);
    ctx.restore();
  };
  drawIvoryTusk(-20, 28, -0.85, 1.35);

  // Clean Sculpted Trunk (NO '<' crease artifact in center of trunk; open root so it embeds smoothly into face!)
  ctx.save();
  ctx.translate(22 + lookX, 6 + lookY);
  const trunkCurl = Math.sin(pose.waveRaysPhase * 0.8) * 0.08 + (pose.farFlipperChinAmount > 0.4 ? -0.35 : 0);
  ctx.rotate(trunkCurl);
  const trunkFill = new Path2D();
  trunkFill.moveTo(-24, -10);
  trunkFill.bezierCurveTo(-22, 42, 12, 92, 58, 84);
  trunkFill.bezierCurveTo(86, 78, 96, 46, 76, 36);
  trunkFill.bezierCurveTo(58, 28, 48, 52, 34, 48);
  trunkFill.bezierCurveTo(16, 42, 18, 6, 22, -12);
  trunkFill.closePath();
  const trunkOpen = new Path2D();
  trunkOpen.moveTo(-24, -4);
  trunkOpen.bezierCurveTo(-22, 42, 12, 92, 58, 84);
  trunkOpen.bezierCurveTo(86, 78, 96, 46, 76, 36);
  trunkOpen.bezierCurveTo(58, 28, 48, 52, 34, 48);
  trunkOpen.bezierCurveTo(16, 42, 18, 6, 22, -6);
  fillRimAndStroke(ctx, trunkFill, -20, -10, 75, 85, cLight, cMid, cDark, outline, 3.5, trunkOpen);
  ctx.fillStyle = '#f4a4b0';
  drawOvalSpot(ctx, 78, 44, 6, 4, 0.3);
  ctx.restore();

  // Right Ivory Tusk (+30% larger)
  drawIvoryTusk(52, 26, 1.05, 1.35);

  drawGlossyAnimalEye(ctx, 'left', -42 + lookX * 0.85, -18 + lookY * 0.85, 27, 32, -0.1, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 68 + lookX * 0.85, -6 + lookY * 0.85, 23, 28, 0.14, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -42 + lookX * 0.85, -60 + lookY * 0.85, 68 + lookX * 0.85, -46 + lookY * 0.85, 38, pose, outline, 4.2);

  ctx.strokeStyle = outline;
  ctx.lineWidth = 3.0;
  ctx.beginPath();
  ctx.moveTo(0, -122);
  ctx.quadraticCurveTo(-8, -142, -18, -146);
  ctx.moveTo(4, -122);
  ctx.quadraticCurveTo(6, -145, 14, -148);
  ctx.stroke();

  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -38 + pose.nearFlipperShoulderX,
      42 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      116,
      58,
      cLight,
      cMid,
      cDark,
      outline,
      { pawTipColor: nailCol },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 52, 66, -2.45 + pose.farFlipperAngle * 0.35, 95, 54, cLight, cMid, cDark, outline, {
      pawTipColor: nailCol,
    });
  }
}

/* ============================================================================
 * A03: MALAYAN TAPIR (Tapirus indicus)
 * - Fixed eye/nose overlap: Eyes positioned cleanly above & separated from the
 *   flexible proboscis snout, with open-root snout integration
 * ========================================================================== */
function drawMalayanTapirRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#141619';
  const darkLight = '#4f565e';
  const darkMid = '#2f353b';
  const darkDeep = '#1b1f24';
  const saddleLight = '#ffffff';
  const saddleMid = '#e6ecef';
  const saddleDark = '#c8d2d9';

  drawSculptedPawLimb(ctx, -52, 82, pose.hindFarAngle * 0.35, 104, 48, darkLight, darkMid, darkDeep, outline, {
    pawTipColor: '#e0d6c8',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 52, 78, pose.farFlipperAngle * 0.35, 108, 48, darkLight, darkMid, darkDeep, outline, {
      pawTipColor: '#e0d6c8',
    });
  }

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const torso = new Path2D();
  torso.ellipse(-32, 42, 126, 86, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -120, -40, 60, 120, darkLight, darkMid, darkDeep, outline, 3.6);

  ctx.save();
  ctx.clip(torso);
  const saddle = new Path2D();
  saddle.moveTo(-118, -50);
  saddle.bezierCurveTo(-55, -55, -2, -50, 8, -42);
  saddle.bezierCurveTo(18, 12, 10, 88, -12, 135);
  saddle.lineTo(-115, 135);
  saddle.bezierCurveTo(-132, 72, -130, 0, -118, -50);
  saddle.closePath();
  fillRimAndStroke(ctx, saddle, -110, -45, 0, 125, saddleLight, saddleMid, saddleDark, outline, 3.2);
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);
  ctx.restore();

  drawSculptedPawLimb(ctx, -108, 80, pose.hindNearAngle * 0.35, 106, 54, darkLight, darkMid, darkDeep, outline, {
    pawTipColor: '#e0d6c8',
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, 50, darkLight, darkMid, darkDeep, outline, {
      pawTipColor: '#e0d6c8',
    });
  }

  ctx.save();
  ctx.translate(42 + pose.headX, -32 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey, rot] of [
    [-76, -98, -0.35],
    [76, -86, 0.38],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    ctx.rotate(rot);
    const earP = new Path2D();
    earP.ellipse(0, 0, 26, 36, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, 0, -36, 0, 36, darkLight, darkMid, darkDeep, outline, 3.4);
    ctx.save();
    ctx.clip(earP);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 8;
    ctx.stroke(earP);
    ctx.fillStyle = '#e8a5b2';
    drawOvalSpot(ctx, 0, 6, 13, 18, 0);
    ctx.restore();
    ctx.lineWidth = 3.4;
    ctx.strokeStyle = outline;
    ctx.stroke(earP);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.moveTo(0, -112);
  headP.bezierCurveTo(72, -110, 118, -58, 114, 8);
  headP.bezierCurveTo(110, 68, 64, 94, -4, 90);
  headP.bezierCurveTo(-76, 86, -112, 44, -106, -18);
  headP.bezierCurveTo(-100, -78, -54, -114, 0, -112);
  headP.closePath();
  fillRimAndStroke(ctx, headP, -60, -110, 50, 90, darkLight, darkMid, darkDeep, outline, 3.7);

  ctx.save();
  ctx.clip(headP);
  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 22 + lookY * 0.8, 82 + lookX * 0.8, 28 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();

  drawExpressiveAnimalMouth(ctx, 14 + lookX, 54 + lookY, 0.78, 0.08, pose, outline);

  // Eyes drawn first and placed higher & wider so the tapir snout never overlaps the eyes!
  drawGlossyAnimalEye(ctx, 'left', -46 + lookX * 0.85, -24 + lookY * 0.85, 25, 29, -0.08, pose, IRIS_PALETTES.warmBrown, darkLight, darkMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 72 + lookX * 0.85, -18 + lookY * 0.85, 21, 25, 0.12, pose, IRIS_PALETTES.warmBrown, darkLight, darkMid, outline);
  drawExpressiveAnimalBrows(ctx, -46 + lookX * 0.85, -64 + lookY * 0.85, 72 + lookX * 0.85, -52 + lookY * 0.85, 36, pose, '#8b95a1', 4.2);

  // Tapir Proboscis Snout positioned cleanly below the eye line (y = +4 to +48) with open root
  const snoutFill = new Path2D();
  snoutFill.moveTo(-6 + lookX, 4 + lookY);
  snoutFill.bezierCurveTo(32 + lookX, 0 + lookY, 68 + lookX, 16 + lookY, 62 + lookX, 38 + lookY);
  snoutFill.bezierCurveTo(56 + lookX, 54 + lookY, 20 + lookX, 50 + lookY, 0 + lookX, 32 + lookY);
  snoutFill.closePath();
  const snoutOpen = new Path2D();
  snoutOpen.moveTo(4 + lookX, 3 + lookY);
  snoutOpen.bezierCurveTo(34 + lookX, 0 + lookY, 68 + lookX, 16 + lookY, 62 + lookX, 38 + lookY);
  snoutOpen.bezierCurveTo(56 + lookX, 54 + lookY, 20 + lookX, 50 + lookY, 2 + lookX, 32 + lookY);
  fillRimAndStroke(ctx, snoutFill, 0, 2, 65, 48, '#636b75', darkLight, darkMid, outline, 3.3, snoutOpen);
  ctx.fillStyle = '#f48fb1';
  drawOvalSpot(ctx, 48 + lookX, 32 + lookY, 8, 9, 0.2);
  ctx.fillStyle = outline;
  drawOvalSpot(ctx, 49 + lookX, 32 + lookY, 4, 5, 0.2);

  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      42 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      116,
      50,
      darkLight,
      darkMid,
      darkDeep,
      outline,
      { pawTipColor: '#e0d6c8' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 52, 66, -2.45 + pose.farFlipperAngle * 0.35, 94, 46, darkLight, darkMid, darkDeep, outline, {
      pawTipColor: '#e0d6c8',
    });
  }
}

/* ============================================================================
 * A04, A09, A10, A13: PRIMATES (Distinct anatomical silhouettes per species!)
 * - A04 Bornean Orangutan: Broad stocky rust-orange torso, shaggy cheek flanges, long arms, tailless
 * - A09 Long-Tailed Macaque: Slender torso, smaller elongated cranium, cheek whisker tufts, extra-long sweeping tail
 * - A10 Dusky Leaf Monkey: Pot-bellied leaf-monkey silhouette, tall pointed silver crown tuft, bold white eye spectacles & mouth patch
 * - A13 Raffles' Banded Langur (Presbytis femoralis): Jet-black coat, erect pointed dark crown crest, white eye-rings + pale cheek crescents, vertical white chest-to-belly stripe, bold white inner-thigh bands
 * ========================================================================== */
function drawPrimateRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'orangutan' | 'macaque' | 'dusky' | 'langur',
): void {
  const pal = {
    orangutan: {
      outline: '#2b1206',
      cLight: '#f57f29',
      cMid: '#d95614',
      cDark: '#9e3608',
      faceLight: '#f7cfa6',
      faceDark: '#d99e6c',
      belly: '#e87a38',
      iris: IRIS_PALETTES.warmBrown,
      hasTail: false,
      headScaleX: 1.08,
      headScaleY: 1.0,
      torsoRx: 118,
      torsoRy: 92,
    },
    macaque: {
      outline: '#261b10',
      cLight: '#c79b63',
      cMid: '#9c713e',
      cDark: '#6e4c24',
      faceLight: '#f5cfa8',
      faceDark: '#d49d6e',
      belly: '#ebd6b7',
      iris: IRIS_PALETTES.amberGold,
      hasTail: true,
      headScaleX: 0.84,
      headScaleY: 0.94,
      torsoRx: 96,
      torsoRy: 80,
    },
    dusky: {
      outline: '#171a1f',
      cLight: '#7a8391',
      cMid: '#525a66',
      cDark: '#323740',
      faceLight: '#3b4047',
      faceDark: '#262a30',
      belly: '#c2ccd9',
      iris: IRIS_PALETTES.warmBrown,
      hasTail: true,
      headScaleX: 0.96,
      headScaleY: 0.96,
      torsoRx: 108,
      torsoRy: 90,
    },
    langur: {
      outline: '#0d0f14',
      cLight: '#383d47',
      cMid: '#1e2229',
      cDark: '#0f1217',
      faceLight: '#2b3038',
      faceDark: '#171a20',
      belly: '#f5f8fc',
      iris: IRIS_PALETTES.warmBrown,
      hasTail: true,
      headScaleX: 0.92,
      headScaleY: 0.95,
      torsoRx: 98,
      torsoRy: 86,
    },
  }[species];

  // 1. Far Hind & Far Front Limbs (Grounded at y=186)
  drawSculptedPawLimb(ctx, -50, 82, pose.hindFarAngle * 0.35, 104, 46, pal.cMid, pal.cDark, pal.cDark, pal.outline, {
    pawTipColor: pal.faceDark,
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(
      ctx,
      50,
      76,
      pose.farFlipperAngle * 0.35,
      110,
      species === 'orangutan' ? 52 : 46,
      pal.cLight,
      pal.cMid,
      pal.cDark,
      pal.outline,
      { pawTipColor: pal.faceDark },
    );
  }

  // 2. Species-Distinct Torso
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const torso = new Path2D();
  torso.ellipse(-24, 42, pal.torsoRx, pal.torsoRy, 0.08, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -100, -45, 60, 125, pal.cLight, pal.cMid, pal.cDark, pal.outline, 3.6);
  ctx.save();
  ctx.clip(torso);
  if (species === 'langur') {
    // Raffles' Banded Langur: Distinct vertical bright-white chest & ventral midline stripe!
    ctx.fillStyle = '#ffffff';
    drawOvalSpot(ctx, 14, 48, 32, 78, 0.06);
  } else if (species === 'dusky') {
    // Dusky Leaf Monkey: Rounded pale silvery-grey pot-belly patch
    ctx.fillStyle = pal.belly;
    drawOvalSpot(ctx, 10, 62, 72, 66, 0.1);
  } else {
    ctx.fillStyle = pal.belly;
    drawOvalSpot(ctx, 6, 56, 68, 66, 0.08);
  }
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = pal.outline;
  ctx.stroke(torso);

  // 3. Species-specific Embedded Tail drawn over posterior rump with open root & untwisted parallel curves ("嵌入")!
  if (pal.hasTail) {
    ctx.save();
    const tailBaseX = -24 - pal.torsoRx + 4;
    ctx.translate(tailBaseX, 46);
    ctx.rotate(pose.hindNearAngle * 0.45 + Math.sin(pose.waveRaysPhase * 0.7) * 0.08);
    const isLongMacaque = species === 'macaque';
    const tailFill = new Path2D();
    const tailOpen = new Path2D();
    if (isLongMacaque) {
      tailFill.moveTo(0, -12);
      tailFill.quadraticCurveTo(14, 0, 0, 12);
      tailFill.bezierCurveTo(-64, 18, -154, -44, -188, -142);
      tailFill.bezierCurveTo(-198, -176, -166, -186, -156, -150);
      tailFill.bezierCurveTo(-128, -62, -48, -12, 0, -12);
      tailFill.closePath();
      tailOpen.moveTo(0, -12);
      tailOpen.bezierCurveTo(-48, -12, -128, -62, -156, -150);
      tailOpen.bezierCurveTo(-166, -186, -198, -176, -188, -142);
      tailOpen.bezierCurveTo(-154, -44, -64, 18, 0, 12);
    } else {
      tailFill.moveTo(0, -12);
      tailFill.quadraticCurveTo(14, 0, 0, 12);
      tailFill.bezierCurveTo(-60, 14, -138, -42, -156, -118);
      tailFill.bezierCurveTo(-162, -148, -128, -156, -120, -122);
      tailFill.bezierCurveTo(-108, -60, -42, -10, 0, -12);
      tailFill.closePath();
      tailOpen.moveTo(0, -12);
      tailOpen.bezierCurveTo(-42, -10, -108, -60, -120, -122);
      tailOpen.bezierCurveTo(-128, -156, -162, -148, -156, -118);
      tailOpen.bezierCurveTo(-138, -42, -60, 14, 0, 12);
    }
    fillRimAndStroke(ctx, tailFill, -150, -155, 10, 14, pal.cLight, pal.cMid, pal.cMid, pal.outline, 3.4, tailOpen);
    ctx.restore();
  }
  ctx.restore();

  // 4. Near Hind Leg & Near Front Leg (Grounded at y=186, with bright white femoral thigh band for A13 Raffles' Banded Langur!)
  drawSculptedPawLimb(ctx, -100, 80, pose.hindNearAngle * 0.35, 106, 52, pal.cLight, pal.cMid, pal.cDark, pal.outline, {
    pawTipColor: pal.faceDark,
    stripesColor: species === 'langur' ? '#ffffff' : undefined,
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(
      ctx,
      -6,
      74,
      pose.nearFlipperAngle * 0.35,
      112,
      species === 'orangutan' ? 52 : 46,
      pal.cLight,
      pal.cMid,
      pal.cDark,
      pal.outline,
      { pawTipColor: pal.faceLight },
    );
  }

  // 5. Primate Head & Species-Specific Facial Architecture
  ctx.save();
  ctx.translate(34 + pose.headX, -42 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX * pal.headScaleX, pose.headScaleY * pal.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  // Ears
  for (const [ex, ey] of [
    [-98, -14],
    [102, -4],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    const earP = new Path2D();
    if (species === 'macaque') {
      earP.moveTo(0, -28);
      earP.quadraticCurveTo(28, -18, 22, 18);
      earP.quadraticCurveTo(0, 28, -20, 12);
      earP.closePath();
    } else {
      earP.arc(0, 0, 26, 0, Math.PI * 2);
    }
    fillRimAndStroke(ctx, earP, 0, -26, 0, 26, pal.faceLight, pal.faceDark, pal.cDark, pal.outline, 3.4);
    ctx.restore();
  }

  // Erect Crown Tuft / Crest for Dusky Leaf Monkey (A10) and Raffles' Banded Langur (A13)
  if (species === 'dusky' || species === 'langur') {
    const crestP = new Path2D();
    crestP.moveTo(-42, -96);
    crestP.quadraticCurveTo(-12, -152, 4, -156);
    crestP.quadraticCurveTo(22, -148, 48, -94);
    crestP.closePath();
    fillRimAndStroke(
      ctx,
      crestP,
      0,
      -154,
      0,
      -94,
      species === 'dusky' ? '#e2e8f0' : '#4a5260',
      species === 'dusky' ? '#b8c2d0' : '#262b33',
      pal.cDark,
      pal.outline,
      3.3,
    );
  }

  const headP = new Path2D();
  if (species === 'orangutan') {
    headP.moveTo(4, -116);
    headP.bezierCurveTo(68, -116, 118, -56, 126, 12);
    headP.bezierCurveTo(132, 68, 76, 102, 4, 100);
    headP.bezierCurveTo(-72, 100, -126, 66, -120, 8);
    headP.bezierCurveTo(-114, -58, -64, -116, 4, -116);
    headP.closePath();
  } else if (species === 'macaque') {
    headP.moveTo(4, -122);
    headP.bezierCurveTo(66, -120, 102, -66, 114, -4);
    headP.bezierCurveTo(126, 26, 98, 72, 54, 92);
    headP.bezierCurveTo(18, 108, -18, 106, -54, 90);
    headP.bezierCurveTo(-102, 68, -124, 22, -108, -8);
    headP.bezierCurveTo(-96, -68, -60, -122, 4, -122);
    headP.closePath();
  } else {
    headP.arc(4, -14, 104, 0, Math.PI * 2);
  }
  fillRimAndStroke(ctx, headP, -60, -115, 50, 95, pal.cLight, pal.cMid, pal.cDark, pal.outline, 3.7);

  ctx.save();
  ctx.clip(headP);
  if (species === 'dusky') {
    ctx.fillStyle = '#d0d8e4';
    drawOvalSpot(ctx, 4, -92, 86, 36, 0);
  } else if (species === 'langur') {
    ctx.fillStyle = '#eef2f7';
    drawOvalSpot(ctx, -86, 18, 30, 52, -0.2);
    drawOvalSpot(ctx, 94, 24, 28, 48, 0.2);
  } else if (species === 'macaque') {
    ctx.fillStyle = '#e8d4b4';
    drawOvalSpot(ctx, -84, 22, 34, 42, -0.25);
    drawOvalSpot(ctx, 90, 26, 32, 40, 0.25);
    ctx.fillStyle = '#4a3216';
    const peak = new Path2D();
    peak.moveTo(-64, -96);
    peak.quadraticCurveTo(8, -52, 16 + lookX * 0.4, -42 + lookY * 0.4);
    peak.quadraticCurveTo(32, -54, 78, -92);
    peak.lineTo(78, -125);
    peak.lineTo(-64, -125);
    peak.closePath();
    ctx.fill(peak);
  }

  ctx.fillStyle = pal.faceLight;
  drawOvalSpot(ctx, -28 + lookX * 0.6, -16 + lookY * 0.6, 44, 42, -0.1);
  drawOvalSpot(ctx, 64 + lookX * 0.6, -6 + lookY * 0.6, 40, 38, 0.1);
  drawOvalSpot(ctx, 18 + lookX * 0.8, 38 + lookY * 0.8, 66, 46, 0.05);

  if (species === 'dusky') {
    ctx.fillStyle = '#ffffff';
    drawOvalSpot(ctx, -38 + lookX * 0.8, -16 + lookY * 0.8, 40, 42, -0.08);
    drawOvalSpot(ctx, 68 + lookX * 0.8, -4 + lookY * 0.8, 36, 38, 0.1);
    drawOvalSpot(ctx, 18 + lookX * 0.85, 44 + lookY * 0.85, 52, 34, 0.05);
  } else if (species === 'langur') {
    ctx.fillStyle = '#cfd6e0';
    drawOvalSpot(ctx, -38 + lookX * 0.8, -16 + lookY * 0.8, 33, 36, -0.08);
    drawOvalSpot(ctx, 68 + lookX * 0.8, -4 + lookY * 0.8, 29, 32, 0.1);
  }

  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 22 + lookY * 0.8, 82 + lookX * 0.8, 30 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = pal.outline;
  ctx.stroke(headP);

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 44 + lookY, 0.86, 0.08, pose, pal.outline);

  ctx.fillStyle = pal.outline;
  drawOvalSpot(ctx, 14 + lookX, 14 + lookY, 5, 7, -0.2);
  drawOvalSpot(ctx, 28 + lookX, 15 + lookY, 5, 7, 0.2);

  drawGlossyAnimalEye(ctx, 'left', -38 + lookX * 0.85, -16 + lookY * 0.85, 28, 33, -0.1, pose, pal.iris, pal.faceLight, pal.faceDark, pal.outline);
  drawGlossyAnimalEye(ctx, 'right', 68 + lookX * 0.85, -4 + lookY * 0.85, 24, 29, 0.14, pose, pal.iris, pal.faceLight, pal.faceDark, pal.outline);
  drawExpressiveAnimalBrows(ctx, -38 + lookX * 0.85, -60 + lookY * 0.85, 68 + lookX * 0.85, -46 + lookY * 0.85, 40, pose, pal.outline, 4.4);

  if (species === 'orangutan') {
    ctx.strokeStyle = pal.outline;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(-14, -114);
    ctx.quadraticCurveTo(-6, -142, 8, -144);
    ctx.moveTo(6, -114);
    ctx.quadraticCurveTo(18, -140, 30, -136);
    ctx.stroke();
  }

  ctx.restore();

  // Foreground Waving Arm & Chin-Touching Arm
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      38 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      122,
      48,
      pal.cLight,
      pal.cMid,
      pal.cDark,
      pal.outline,
      { pawTipColor: pal.faceLight },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 50, 64, -2.45 + pose.farFlipperAngle * 0.35, 96, 46, pal.cLight, pal.cMid, pal.cDark, pal.outline, {
      pawTipColor: pal.faceLight,
    });
  }
}

/* ============================================================================
 * A05: SUN BEAR (Helarctos malayanus)
 * ========================================================================== */
function drawSunBearRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#120d0a';
  const cLight = '#4a3d36';
  const cMid = '#2b221e';
  const cDark = '#171210';
  const tanLight = '#f7d6ad';
  const tanDark = '#cf9863';

  drawSculptedPawLimb(ctx, -50, 82, pose.hindFarAngle * 0.35, 104, 52, cLight, cMid, cDark, outline, {
    pawPadColor: '#f4a29d',
    clawsColor: '#e8dec8',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 52, 78, pose.farFlipperAngle * 0.35, 108, 52, cLight, cMid, cDark, outline, {
      pawPadColor: '#f4a29d',
      clawsColor: '#e8dec8',
    });
  }

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const torso = new Path2D();
  torso.ellipse(-24, 44, 114, 92, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -100, -45, 60, 130, cLight, cMid, cDark, outline, 3.6);

  ctx.save();
  ctx.clip(torso);
  const sunCrest = new Path2D();
  sunCrest.moveTo(-42, 10);
  sunCrest.quadraticCurveTo(8, 38, 48, 12);
  sunCrest.quadraticCurveTo(64, 24, 46, 56);
  sunCrest.quadraticCurveTo(8, 92, -44, 52);
  sunCrest.closePath();
  fillRimAndStroke(ctx, sunCrest, -40, 10, 45, 85, '#ffe57f', '#ffb300', '#e65100', outline, 2.8);
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);
  ctx.restore();

  drawSculptedPawLimb(ctx, -104, 80, pose.hindNearAngle * 0.35, 106, 58, cLight, cMid, cDark, outline, {
    pawPadColor: '#f4a29d',
    clawsColor: '#e8dec8',
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, 54, cLight, cMid, cDark, outline, {
      pawPadColor: '#f4a29d',
      clawsColor: '#e8dec8',
    });
  }

  ctx.save();
  ctx.translate(34 + pose.headX, -42 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey] of [
    [-86, -86],
    [88, -74],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    const earP = new Path2D();
    earP.arc(0, 0, 28, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, 0, -28, 0, 28, cLight, cMid, cDark, outline, 3.5);
    ctx.fillStyle = tanDark;
    drawOvalSpot(ctx, 0, 2, 14, 14, 0);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.ellipse(4, -10, 112, 98, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -80, -105, 60, 85, cLight, cMid, cDark, outline, 3.7);

  ctx.save();
  ctx.clip(headP);
  const muzzleP = new Path2D();
  muzzleP.ellipse(20 + lookX * 0.8, 26 + lookY * 0.8, 56, 44, 0.06, 0, Math.PI * 2);
  const mGrad = ctx.createLinearGradient(20, -15, 20, 70);
  mGrad.addColorStop(0, tanLight);
  mGrad.addColorStop(1, tanDark);
  ctx.fillStyle = mGrad;
  ctx.fill(muzzleP);

  drawSoftCheekBlushes(ctx, -58 + lookX * 0.8, 22 + lookY * 0.8, 84 + lookX * 0.8, 30 + lookY * 0.8, 28, 16, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  drawExpressiveAnimalMouth(ctx, 20 + lookX, 42 + lookY, 0.86, 0.08, pose, outline);

  ctx.fillStyle = '#1a120e';
  drawOvalSpot(ctx, 24 + lookX, 8 + lookY, 20, 14, 0.06);
  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  drawOvalSpot(ctx, 18 + lookX, 4 + lookY, 7, 4, -0.1);

  drawGlossyAnimalEye(ctx, 'left', -38 + lookX * 0.85, -16 + lookY * 0.85, 28, 33, -0.1, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 70 + lookX * 0.85, -4 + lookY * 0.85, 24, 29, 0.14, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -38 + lookX * 0.85, -58 + lookY * 0.85, 70 + lookX * 0.85, -44 + lookY * 0.85, 38, pose, tanLight, 4.2);

  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      40 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      118,
      54,
      cLight,
      cMid,
      cDark,
      outline,
      { pawPadColor: '#f4a29d', clawsColor: '#e8dec8' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 52, 64, -2.45 + pose.farFlipperAngle * 0.35, 96, 50, cLight, cMid, cDark, outline, {
      pawPadColor: '#f4a29d',
    });
  }
}

/* ============================================================================
 * A06: SUNDA PANGOLIN (Manis javanica)
 * - Sharp conical tapering snout/head
 * - Distinct overlapping artichoke-like V-tipped keratin scales across tail, torso & crown
 * - Embedded prehensile tail & limbs
 * ========================================================================== */
function drawPangolinArtichokeScale(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  rot: number,
  cLight: string,
  cMid: string,
  cDark: string,
  outline: string,
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  const sp = new Path2D();
  sp.moveTo(-w * 0.5, 0);
  sp.quadraticCurveTo(-w * 0.4, h * 0.72, 0, h);
  sp.quadraticCurveTo(w * 0.4, h * 0.72, w * 0.5, 0);
  sp.quadraticCurveTo(0, -h * 0.25, -w * 0.5, 0);
  sp.closePath();
  const grad = ctx.createLinearGradient(0, -h * 0.2, 0, h);
  grad.addColorStop(0, cDark);
  grad.addColorStop(0.55, cMid);
  grad.addColorStop(1, cLight);
  ctx.fillStyle = grad;
  ctx.fill(sp);
  ctx.strokeStyle = 'rgba(255,235,190,0.45)';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(0, -h * 0.1);
  ctx.lineTo(0, h * 0.85);
  ctx.stroke();
  ctx.strokeStyle = outline;
  ctx.lineWidth = 2.2;
  ctx.stroke(sp);
  ctx.restore();
}

function drawSundaPangolinRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#2b180a';
  const scaleLight = '#eab66a';
  const scaleMid = '#ba7a2d';
  const scaleDark = '#75440e';
  const skinLight = '#f5d2b3';
  const skinDark = '#cfa07a';

  drawSculptedPawLimb(ctx, -50, 82, pose.hindFarAngle * 0.35, 104, 46, scaleLight, scaleMid, scaleDark, outline, {
    clawsColor: '#fff5e0',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 78, pose.farFlipperAngle * 0.35, 108, 44, skinLight, skinDark, scaleMid, outline, {
      clawsColor: '#fff5e0',
    });
  }

  // 1. Armored Torso + Embedded Armored Prehensile Tail (anterior torso scales naturally overlap tail root, while torso outline stays open across tail base!)
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  drawEmbeddedTail(
    ctx,
    -130,
    46,
    pose.hindNearAngle * 0.45 + Math.sin(pose.waveRaysPhase * 0.6) * 0.06,
    132,
    50,
    12,
    40,
    scaleLight,
    scaleMid,
    scaleDark,
    outline,
    (tCtx) => {
      for (let i = 0; i < 5; i++) {
        const tx = -22 - i * 22;
        const ty = 2 + i * 8;
        drawPangolinArtichokeScale(tCtx, tx, ty, 24 - i * 2, 22 - i * 1.5, 1.35, scaleLight, scaleMid, scaleDark, outline);
      }
    },
  );

  const torso = new Path2D();
  torso.ellipse(-28, 38, 122, 84, 0.08, 0, Math.PI * 2);
  // Open posterior arc on torso stroke so the dark outline NEVER cuts across the armored tail root!
  const torsoOpen = new Path2D();
  torsoOpen.ellipse(-28, 38, 122, 84, 0.08, -Math.PI * 0.86, Math.PI * 0.78);
  fillRimAndStroke(ctx, torso, -110, -45, 50, 125, scaleLight, scaleMid, scaleDark, outline, 3.6, torsoOpen);

  ctx.save();
  ctx.clip(torso);
  ctx.fillStyle = skinLight;
  drawOvalSpot(ctx, 48, 84, 42, 34, 0.12);
  for (let row = -2; row <= 1; row++) {
    for (let col = -3; col <= 2; col++) {
      const sx = col * 32 + (row % 2) * 16 - 26;
      const sy = row * 22 - 4;
      drawPangolinArtichokeScale(ctx, sx, sy, 32, 26, 1.45, scaleLight, scaleMid, scaleDark, outline);
    }
  }
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torsoOpen);
  ctx.restore();

  drawSculptedPawLimb(ctx, -100, 80, pose.hindNearAngle * 0.35, 106, 52, scaleLight, scaleMid, scaleDark, outline, {
    clawsColor: '#fff5e0',
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, 46, scaleLight, scaleMid, scaleDark, outline, {
      clawsColor: '#fff5e0',
    });
  }

  // 3. Sharp Conical Pangolin Head with Completely Outlined Rounded Cranium & Crown Scales
  ctx.save();
  ctx.translate(46 + pose.headX, -28 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 12;
  const lookY = pose.headLookY * 8;

  const headFill = new Path2D();
  headFill.moveTo(-76, -54);
  headFill.bezierCurveTo(-24, -84, 52, -52, 128 + lookX * 0.5, 16 + lookY * 0.5);
  headFill.bezierCurveTo(136 + lookX * 0.5, 26 + lookY * 0.5, 122 + lookX * 0.5, 42 + lookY * 0.5, 104 + lookX * 0.5, 44 + lookY * 0.5);
  headFill.bezierCurveTo(42, 62, -38, 66, -84, 38);
  headFill.bezierCurveTo(-108, 22, -108, -28, -76, -54);
  headFill.closePath();

  fillRimAndStroke(ctx, headFill, -85, -80, 90, 60, skinLight, skinDark, scaleMid, outline, 3.6);

  ctx.save();
  ctx.clip(headFill);
  for (let i = 0; i < 4; i++) {
    drawPangolinArtichokeScale(
      ctx,
      -52 + i * 26,
      -46 + i * 10,
      28 - i * 2,
      22 - i * 1.5,
      1.25,
      scaleLight,
      scaleMid,
      scaleDark,
      outline,
    );
  }
  drawSoftCheekBlushes(ctx, -28 + lookX * 0.8, 22 + lookY * 0.8, 62 + lookX * 0.8, 26 + lookY * 0.8, 20, 12, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headFill);

  drawExpressiveAnimalMouth(ctx, 46 + lookX * 0.7, 36 + lookY * 0.7, 0.68, 0.12, pose, outline);

  ctx.fillStyle = '#3d2214';
  drawOvalSpot(ctx, 118 + lookX * 0.5, 24 + lookY * 0.5, 11, 9, 0.25);

  drawGlossyAnimalEye(ctx, 'left', -18 + lookX * 0.75, -6 + lookY * 0.75, 19, 22, -0.06, pose, IRIS_PALETTES.warmBrown, skinLight, skinDark, outline);
  drawGlossyAnimalEye(ctx, 'right', 54 + lookX * 0.75, 2 + lookY * 0.75, 16, 19, 0.1, pose, IRIS_PALETTES.warmBrown, skinLight, skinDark, outline);
  drawExpressiveAnimalBrows(ctx, -18 + lookX * 0.75, -36 + lookY * 0.75, 54 + lookX * 0.75, -26 + lookY * 0.75, 28, pose, outline, 3.6);

  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -34 + pose.nearFlipperShoulderX,
      40 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      114,
      46,
      scaleLight,
      scaleMid,
      scaleDark,
      outline,
      { clawsColor: '#fff5e0' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 50, 64, -2.45 + pose.farFlipperAngle * 0.35, 92, 44, skinLight, skinDark, scaleMid, outline, {
      clawsColor: '#fff5e0',
    });
  }
}

/* ============================================================================
 * A07 & A08: SAMBAR DEER & GREATER MOUSEDEER (Kancil)
 * Distinct body shapes, spots, throat chevrons, and antlers matching reference!
 * ========================================================================== */
function drawCervidRig(ctx: CanvasRenderingContext2D, pose: TurtlePose, hasAntlers: boolean): void {
  const outline = '#261408';
  const cLight = hasAntlers ? '#d9914c' : '#f0a854';
  const cMid = hasAntlers ? '#a66229' : '#c47425';
  const cDark = hasAntlers ? '#6e3b12' : '#874810';
  const cream = '#fff8eb';

  const legThick = hasAntlers ? 42 : 34;

  drawSculptedPawLimb(ctx, -50, 82, pose.hindFarAngle * 0.35, 104, legThick, cMid, cDark, '#592e0d', outline, {
    hoofColor: '#2b1b10',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 50, 78, pose.farFlipperAngle * 0.35, 108, legThick, cLight, cMid, cDark, outline, {
      hoofColor: '#2b1b10',
    });
  }

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const torso = new Path2D();
  torso.ellipse(-28, 42, hasAntlers ? 116 : 102, hasAntlers ? 82 : 72, hasAntlers ? 0.04 : -0.12, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -110, -40, 55, 120, cLight, cMid, cDark, outline, 3.5);
  ctx.save();
  ctx.clip(torso);
  ctx.fillStyle = cream;
  drawOvalSpot(ctx, 48, 52, 38, 60, 0.15);
  if (!hasAntlers) {
    // Signature white throat chevron stripes of Greater Mousedeer (Kancil)
    ctx.strokeStyle = cream;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(12, -8);
    ctx.lineTo(56, 26);
    ctx.moveTo(4, 14);
    ctx.lineTo(52, 48);
    ctx.stroke();
  }
  ctx.fillStyle = 'rgba(255, 248, 225, 0.85)';
  for (const [sx, sy] of [
    [-88, 16],
    [-62, 6],
    [-36, 18],
    [-74, 38],
    [-48, 42],
  ]) {
    drawOvalSpot(ctx, sx, sy, 7, 5, 0.1);
  }
  ctx.restore();
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);

  // Short perky deer tail with open root drawn after torso so there is zero seam line across the rump!
  ctx.save();
  ctx.translate(hasAntlers ? -134 : -122, 18);
  ctx.rotate(pose.hindNearAngle * 0.5);
  const tailFill = new Path2D();
  tailFill.moveTo(8, 10);
  tailFill.quadraticCurveTo(-28, -26, -12, -46);
  tailFill.quadraticCurveTo(18, -32, 18, 4);
  tailFill.closePath();
  const tailOpen = new Path2D();
  tailOpen.moveTo(0, 8);
  tailOpen.quadraticCurveTo(-28, -26, -12, -46);
  tailOpen.quadraticCurveTo(18, -32, 14, 0);
  fillRimAndStroke(ctx, tailFill, -25, -45, 18, 10, cLight, cMid, cMid, outline, 3.2, tailOpen);
  ctx.restore();
  ctx.restore();

  // Near Hind & Near Front Legs embedded over torso ("嵌入") and grounded at y=186
  drawSculptedPawLimb(ctx, -104, 80, pose.hindNearAngle * 0.35, 106, legThick + 4, cLight, cMid, cDark, outline, {
    hoofColor: '#2b1b10',
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -6, 76, pose.nearFlipperAngle * 0.35, 110, legThick + 2, cLight, cMid, cDark, outline, {
      hoofColor: '#2b1b10',
    });
  }

  ctx.save();
  ctx.translate(38 + pose.headX, -42 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  if (hasAntlers) {
    ctx.strokeStyle = '#6e4726';
    ctx.lineWidth = 11;
    ctx.lineCap = 'round';
    for (const dir of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(dir * 32, -88);
      ctx.quadraticCurveTo(dir * 64, -148, dir * 44, -190);
      ctx.moveTo(dir * 46, -134);
      ctx.lineTo(dir * 82, -154);
      ctx.moveTo(dir * 38, -112);
      ctx.lineTo(dir * 16, -142);
      ctx.stroke();
    }
  }

  for (const [ex, ey, rot] of [
    [-86, -78, -0.55],
    [88, -68, 0.58],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    ctx.rotate(rot);
    const earP = new Path2D();
    earP.ellipse(0, 0, 22, 44, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, 0, -44, 0, 44, cLight, cMid, cDark, outline, 3.4);
    ctx.fillStyle = '#f2b6c1';
    drawOvalSpot(ctx, 0, 4, 11, 26, 0);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.ellipse(6, -10, hasAntlers ? 102 : 94, hasAntlers ? 88 : 78, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -75, -95, 55, 80, cLight, cMid, cDark, outline, 3.6);

  ctx.save();
  ctx.clip(headP);
  ctx.fillStyle = cream;
  drawOvalSpot(ctx, 22 + lookX * 0.8, 34 + lookY * 0.8, 48, 34, 0.06);
  drawSoftCheekBlushes(ctx, -52 + lookX * 0.8, 20 + lookY * 0.8, 78 + lookX * 0.8, 28 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  drawExpressiveAnimalMouth(ctx, 20 + lookX, 42 + lookY, 0.84, 0.08, pose, outline);
  ctx.fillStyle = '#24150c';
  drawOvalSpot(ctx, 26 + lookX, 12 + lookY, 16, 12, 0.06);

  drawGlossyAnimalEye(
    ctx,
    'left',
    -36 + lookX * 0.85,
    -16 + lookY * 0.85,
    29,
    34,
    -0.1,
    pose,
    hasAntlers ? IRIS_PALETTES.warmBrown : IRIS_PALETTES.emerald,
    cLight,
    cMid,
    outline,
  );
  drawGlossyAnimalEye(
    ctx,
    'right',
    66 + lookX * 0.85,
    -4 + lookY * 0.85,
    25,
    30,
    0.14,
    pose,
    hasAntlers ? IRIS_PALETTES.warmBrown : IRIS_PALETTES.emerald,
    cLight,
    cMid,
    outline,
  );
  drawExpressiveAnimalBrows(ctx, -36 + lookX * 0.85, -58 + lookY * 0.85, 66 + lookX * 0.85, -44 + lookY * 0.85, 38, pose, outline, 4.0);

  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      40 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      118,
      legThick + 2,
      cLight,
      cMid,
      cDark,
      outline,
      { hoofColor: '#2b1b10' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 50, 64, -2.45 + pose.farFlipperAngle * 0.35, 94, legThick, cLight, cMid, cDark, outline, {
      hoofColor: '#2b1b10',
    });
  }
}

/* ============================================================================
 * A11: MALAYAN PORCUPINE (Hystrix brachyura)
 * - Sharp needle-pointed black-and-ivory quills ("pines")
 * - Quills 100% intact and embedded ("嵌入") into the body & head, trailing
 *   continuously from the top of the head down the nape and across the back
 *   with zero gap or disconnection!
 * - Detailed legs with coarse bristle texture & digging claws, plus white nape crescent
 * ========================================================================== */
function drawSharpPorcupineQuill(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  length: number,
  halfWidth: number,
  outline: string,
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  const qFill = new Path2D();
  qFill.moveTo(-8, -halfWidth);
  qFill.quadraticCurveTo(length * 0.52, -halfWidth * 0.92, length, 0);
  qFill.quadraticCurveTo(length * 0.52, halfWidth * 0.92, -8, halfWidth);
  qFill.closePath();

  // Open root so the base of every quill embeds seamlessly into the skin/fur ("嵌入")!
  const qOpen = new Path2D();
  qOpen.moveTo(4, -halfWidth * 0.95);
  qOpen.quadraticCurveTo(length * 0.52, -halfWidth * 0.92, length, 0);
  qOpen.quadraticCurveTo(length * 0.52, halfWidth * 0.92, 4, halfWidth * 0.95);

  fillRimAndStroke(ctx, qFill, 0, -halfWidth, length, halfWidth, '#fffdf5', '#ede0c4', '#4a2e16', outline, 2.5, qOpen);
  ctx.save();
  ctx.clip(qFill);
  // Warm brown root follicle blend + bold dark subterminal band + needle-sharp ivory tip
  ctx.fillStyle = '#5c381c';
  ctx.fillRect(-10, -halfWidth * 1.5, length * 0.22, halfWidth * 3);
  ctx.fillStyle = '#1f1209';
  ctx.fillRect(length * 0.34, -halfWidth * 1.5, length * 0.34, halfWidth * 3);
  ctx.restore();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = outline;
  ctx.stroke(qOpen);
  ctx.restore();
}

function drawMalayanPorcupineRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#1f1209';
  const cLight = '#9e6b43';
  const cMid = '#6e4526';
  const cDark = '#472a14';

  // 1. Far Hind & Far Front Legs planted on ground at y=186
  drawSculptedPawLimb(ctx, -48, 82, pose.hindFarAngle * 0.35, 104, 46, cMid, cDark, outline, outline, {
    clawsColor: '#f5ebd6',
    stripesColor: '#3b2210',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 78, pose.farFlipperAngle * 0.35, 108, 44, cLight, cMid, cDark, outline, {
      clawsColor: '#f5ebd6',
      stripesColor: '#472a14',
    });
  }

  // 2. Sculpted Porcupine Torso with coarse bristle texture & signature white nape collar
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // Background fan of long sharp quills emerging from rump
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    const qx = -112 + t * 54;
    const qy = 26 - Math.sin(t * Math.PI) * 32;
    const qAng = -2.75 + t * 0.55 + Math.sin(pose.waveRaysPhase + i * 0.6) * 0.025;
    const qLen = 148 + Math.sin(t * Math.PI) * 28;
    drawSharpPorcupineQuill(ctx, qx, qy, qAng, qLen, 7.5, outline);
  }

  const torso = new Path2D();
  torso.ellipse(-18, 46, 112, 82, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -100, -35, 60, 125, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(torso);
  // Signature Hystrix brachyura white neck/shoulder crescent stripe
  ctx.strokeStyle = '#fff9eb';
  ctx.lineWidth = 9;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(28, -2);
  ctx.quadraticCurveTo(44, 36, 26, 74);
  ctx.stroke();
  // Coarse bristle fur dashes along flank & belly
  ctx.strokeStyle = '#3b2210';
  ctx.lineWidth = 2.4;
  for (const [bx, by] of [
    [-76, 48],
    [-46, 56],
    [-16, 62],
    [-62, 78],
    [-28, 84],
    [4, 86],
  ]) {
    ctx.beginPath();
    ctx.moveTo(bx, by);
    ctx.lineTo(bx - 16, by + 6);
    ctx.stroke();
  }
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);

  // Foreground overlapping rows of embedded dorsal quills ("嵌入" directly into the back!)
  for (let i = 0; i < 10; i++) {
    const t = i / 9;
    const qx = -96 + t * 88;
    const qy = 8 - Math.sin(t * Math.PI) * 28 + (1 - t) * 14;
    const qAng = -2.62 + t * 0.52 + Math.sin(pose.waveRaysPhase + i * 0.5) * 0.025;
    const qLen = 132 - t * 28;
    drawSharpPorcupineQuill(ctx, qx, qy, qAng, qLen, 6.8, outline);
  }
  ctx.restore();

  // 3. Near Hind & Near Front Legs embedded over torso ("嵌入") and grounded at y=186
  drawSculptedPawLimb(ctx, -96, 80, pose.hindNearAngle * 0.35, 106, 52, cLight, cMid, cDark, outline, {
    clawsColor: '#f5ebd6',
    stripesColor: '#472a14',
  });

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -4, 76, pose.nearFlipperAngle * 0.35, 110, 46, cLight, cMid, cDark, outline, {
      clawsColor: '#f5ebd6',
      stripesColor: '#472a14',
    });
  }

  // 4. Porcupine Head with Continuous Trailing Crown-to-Back Quills ("嵌入" into top of head!)
  ctx.save();
  ctx.translate(38 + pose.headX, -32 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  const headP = new Path2D();
  headP.ellipse(6, -6, 104, 86, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -75, -90, 55, 80, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(headP);
  // Coarse snout & cheek fur texture lines
  ctx.strokeStyle = '#472a14';
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(-58, 12);
  ctx.lineTo(-78, 18);
  ctx.moveTo(-52, 28);
  ctx.lineTo(-74, 34);
  ctx.stroke();
  drawSoftCheekBlushes(ctx, -52 + lookX * 0.8, 22 + lookY * 0.8, 76 + lookX * 0.8, 30 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  // Continuous trailing crest of sharp quills embedded directly inside the crown & nape (trailing from forehead top to body with zero disconnection!)
  const crownQuills: Array<[number, number, number, number]> = [
    [28, -76, -2.18, 86],
    [10, -82, -2.26, 98],
    [-10, -84, -2.34, 112],
    [-30, -80, -2.42, 122],
    [-50, -72, -2.48, 128],
    [-68, -58, -2.54, 132],
    [-82, -40, -2.58, 128],
  ];
  for (let i = 0; i < crownQuills.length; i++) {
    const [cqx, cqy, cqAng, cqLen] = crownQuills[i];
    drawSharpPorcupineQuill(
      ctx,
      cqx,
      cqy,
      cqAng + Math.sin(pose.waveRaysPhase + i * 0.4) * 0.02,
      cqLen,
      6.2,
      outline,
    );
  }

  drawExpressiveAnimalMouth(ctx, 20 + lookX, 42 + lookY, 0.84, 0.08, pose, outline);
  ctx.fillStyle = '#331d10';
  drawOvalSpot(ctx, 24 + lookX, 12 + lookY, 16, 12, 0.08);

  drawGlossyAnimalEye(ctx, 'left', -36 + lookX * 0.85, -14 + lookY * 0.85, 27, 32, -0.1, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 66 + lookX * 0.85, -4 + lookY * 0.85, 23, 28, 0.14, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -36 + lookX * 0.85, -56 + lookY * 0.85, 66 + lookX * 0.85, -42 + lookY * 0.85, 36, pose, '#fff8eb', 4.0);
  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -34 + pose.nearFlipperShoulderX,
      40 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      112,
      46,
      cLight,
      cMid,
      cDark,
      outline,
      { clawsColor: '#f5ebd6', stripesColor: '#472a14' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 50, 64, -2.45 + pose.farFlipperAngle * 0.35, 92, 44, cLight, cMid, cDark, outline, {
      clawsColor: '#f5ebd6',
    });
  }
}

/* ============================================================================
 * A12: MALAYAN FLYING FOX (Pteropus vampyrus)
 * ========================================================================== */
function drawMalayanFlyingFoxRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#1a1114';
  const wingLight = '#543c47';
  const wingMid = '#36252d';
  const wingDark = '#1f1419';
  const furLight = '#e68a35';
  const furMid = '#ba5d18';
  const furDark = '#7d370a';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  const drawWing = (side: -1 | 1, isForegroundWave: boolean) => {
    ctx.save();
    const isLeft = side === -1;
    const flap = isLeft
      ? isForegroundWave
        ? 0.28 + pose.nearFlipperAngle * 0.75
        : pose.nearFlipperAngle * 0.45
      : -pose.farFlipperAngle * 0.45;
    ctx.translate(side * 48 + (isLeft ? pose.nearFlipperShoulderX : 0), 12 + (isLeft ? pose.nearFlipperShoulderY : 0));
    ctx.scale(side, 1);
    ctx.rotate(flap);

    const wP = new Path2D();
    wP.moveTo(0, -18);
    wP.bezierCurveTo(68, -74, 148, -92, 198, -54);
    wP.quadraticCurveTo(164, -12, 174, 28);
    wP.quadraticCurveTo(124, 14, 118, 58);
    wP.quadraticCurveTo(64, 38, 12, 68);
    wP.closePath();
    fillRimAndStroke(ctx, wP, 0, -80, 190, 65, wingLight, wingMid, wingDark, outline, 3.5);

    ctx.strokeStyle = '#e8dec8';
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.arc(82, -62, 9, Math.PI * 0.8, Math.PI * 1.8);
    ctx.stroke();

    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(14, -22);
    ctx.quadraticCurveTo(96, -34, 172, 26);
    ctx.moveTo(14, -22);
    ctx.quadraticCurveTo(72, 6, 116, 56);
    ctx.stroke();
    ctx.restore();
  };

  drawWing(1, false);
  if (waveAmt < 0.45) {
    drawWing(-1, false);
  }

  // Grounded clawed bat feet grasping perch/ground
  drawSculptedPawLimb(ctx, -38, 114, pose.hindNearAngle * 0.3, 62, 30, '#36252d', '#1f1419', outline, outline, {
    clawsColor: '#e8dec8',
  });
  drawSculptedPawLimb(ctx, 28, 114, pose.hindFarAngle * 0.3, 62, 30, '#36252d', '#1f1419', outline, outline, {
    clawsColor: '#e8dec8',
  });

  const bodyP = new Path2D();
  bodyP.ellipse(0, 48, 74, 86, 0, 0, Math.PI * 2);
  fillRimAndStroke(ctx, bodyP, -60, -35, 60, 130, '#422c35', '#291a20', '#170e12', outline, 3.6);
  ctx.save();
  ctx.clip(bodyP);
  const mantleP = new Path2D();
  mantleP.ellipse(0, 12, 72, 54, 0, 0, Math.PI * 2);
  fillRimAndStroke(ctx, mantleP, -65, -40, 65, 60, furLight, furMid, furDark, outline, 2.8);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyP);

  ctx.save();
  ctx.translate(16 + pose.headX, -48 + pose.headY);
  ctx.rotate(pose.headRot);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey, rot] of [
    [-68, -82, -0.35],
    [72, -76, 0.38],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    ctx.rotate(rot);
    const earP = new Path2D();
    earP.moveTo(-22, 18);
    earP.quadraticCurveTo(0, -48, 22, 18);
    earP.closePath();
    fillRimAndStroke(ctx, earP, 0, -45, 0, 18, wingLight, wingMid, wingDark, outline, 3.4);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.ellipse(4, -6, 94, 84, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -70, -85, 60, 80, furLight, furMid, furDark, outline, 3.6);
  drawSoftCheekBlushes(ctx, -48 + lookX * 0.8, 20 + lookY * 0.8, 68 + lookX * 0.8, 26 + lookY * 0.8, 24, 14, pose.blushAlpha);

  drawExpressiveAnimalMouth(ctx, 14 + lookX, 38 + lookY, 0.82, 0.06, pose, outline);
  ctx.fillStyle = '#1f1419';
  drawOvalSpot(ctx, 18 + lookX, 10 + lookY, 14, 10, 0.05);

  drawGlossyAnimalEye(ctx, 'left', -34 + lookX * 0.85, -14 + lookY * 0.85, 27, 32, -0.08, pose, IRIS_PALETTES.amber, furLight, furMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 58 + lookX * 0.85, -6 + lookY * 0.85, 24, 29, 0.12, pose, IRIS_PALETTES.amber, furLight, furMid, outline);
  drawExpressiveAnimalBrows(ctx, -34 + lookX * 0.85, -54 + lookY * 0.85, 58 + lookX * 0.85, -42 + lookY * 0.85, 36, pose, outline, 4.0);
  ctx.restore();

  if (waveAmt >= 0.45) {
    drawWing(-1, true);
  }
}

/* ============================================================================
 * A14 & A15: AVIAN SPECIES (Malayan Crested Fireback & Rhinoceros Hornbill)
 * - A14 Malayan Crested Fireback: During expressive emotions (Laugh, Waving,
 *   Congratulate, Blush), the peacock-like tail feathers behind it expand and
 *   open out into a breathtaking graceful fan!
 * ========================================================================== */
function drawAvianRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'fireback' | 'hornbill',
): void {
  const isHornbill = species === 'hornbill';
  const outline = '#10141c';
  const cLight = isHornbill ? '#3c434f' : '#2c467a';
  const cMid = isHornbill ? '#222730' : '#192a4d';
  const cDark = isHornbill ? '#11141a' : '#0d172b';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Compute graceful peacock-tail fan expansion amount for A14 Malayan Crested Fireback!
  const fanExpand = !isHornbill
    ? clamp(
        Math.max(
          pose.mouthOpen * 1.45,
          waveAmt * 0.9,
          pose.confettiAmount,
          pose.blushAlpha * 0.85,
        ),
        0,
        1,
      )
    : 0;

  // 1. Tail Feathers (Expands into a radiant 9-plume peacock fan on A14 when laughing/waving!)
  ctx.save();
  ctx.translate(-112, 48);
  ctx.rotate(pose.hindNearAngle * 0.5);
  if (!isHornbill && fanExpand > 0.05) {
    const numPlumes = 9;
    for (let i = 0; i < numPlumes; i++) {
      const norm = i / (numPlumes - 1) - 0.5; // -0.5 to +0.5
      const baseAngle = -0.35 + norm * (0.45 + fanExpand * 1.85);
      const sway = Math.sin(pose.waveRaysPhase * 1.2 + i * 0.6) * 0.04 * fanExpand;
      const len = 148 + (1 - Math.abs(norm) * 0.5) * 42 * fanExpand;
      const isCentralBuff = Math.abs(norm) < 0.22;
      ctx.save();
      ctx.rotate(baseAngle + sway);
      const plume = new Path2D();
      plume.moveTo(8, -6);
      plume.bezierCurveTo(-len * 0.45, -24, -len * 0.85, -22, -len, 0);
      plume.bezierCurveTo(-len * 0.85, 22, -len * 0.45, 20, 8, 6);
      plume.closePath();
      fillRimAndStroke(
        ctx,
        plume,
        -len,
        -18,
        0,
        18,
        isCentralBuff ? '#fffbeb' : '#38bdf8',
        isCentralBuff ? '#f5d08a' : '#1d4ed8',
        isCentralBuff ? '#b45309' : '#1e1b4b',
        outline,
        2.8,
      );
      // Iridescent peacock/fireback ocellus eyespot near feather tip
      ctx.save();
      ctx.clip(plume);
      ctx.fillStyle = isCentralBuff ? '#f59e0b' : '#10b981';
      drawOvalSpot(ctx, -len * 0.78, 0, 16, 10, 0);
      ctx.fillStyle = '#fef08a';
      drawOvalSpot(ctx, -len * 0.78, 0, 9, 5.5, 0);
      ctx.fillStyle = '#1e1b4b';
      drawOvalSpot(ctx, -len * 0.8, 0, 5, 3.5, 0);
      ctx.restore();
      ctx.restore();
    }
  } else {
    const tailFill = new Path2D();
    tailFill.moveTo(12, -16);
    tailFill.bezierCurveTo(-68, -68, -148, -32, -166, 38);
    tailFill.bezierCurveTo(-128, 68, -52, 48, 18, 22);
    tailFill.closePath();
    const tailOpen = new Path2D();
    tailOpen.moveTo(4, -14);
    tailOpen.bezierCurveTo(-68, -68, -148, -32, -166, 38);
    tailOpen.bezierCurveTo(-128, 68, -52, 48, 8, 18);
    fillRimAndStroke(
      ctx,
      tailFill,
      -150,
      -45,
      15,
      55,
      isHornbill ? '#ffffff' : '#fff3d6',
      isHornbill ? '#e2e8f0' : '#d6b46e',
      isHornbill ? '#cbd5e1' : '#223359',
      outline,
      3.5,
      tailOpen,
    );
    if (isHornbill) {
      ctx.save();
      ctx.clip(tailFill);
      ctx.fillStyle = '#11141a';
      ctx.fillRect(-125, -45, 36, 115);
      ctx.restore();
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = outline;
      ctx.stroke(tailOpen);
    }
  }
  ctx.restore();

  // 2. Bird Legs & Claws planted on ground
  ctx.strokeStyle = isHornbill ? '#5c6670' : '#d9483b';
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  for (const lx of [-42, 18]) {
    ctx.beginPath();
    ctx.moveTo(lx, 112);
    ctx.lineTo(lx, 174);
    ctx.moveTo(lx - 18, 178);
    ctx.lineTo(lx + 22, 174);
    ctx.stroke();
  }

  const drawFeatheredWing = (x: number, y: number, ang: number, scaleX = 1) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scaleX, 1);
    ctx.rotate(ang);
    const wingFill = new Path2D();
    wingFill.moveTo(14, -14);
    wingFill.bezierCurveTo(-48, -24, -124, 18, -112, 74);
    wingFill.bezierCurveTo(-78, 96, 12, 68, 22, 14);
    wingFill.closePath();
    const wingOpen = new Path2D();
    wingOpen.moveTo(6, -15);
    wingOpen.bezierCurveTo(-48, -24, -124, 18, -112, 74);
    wingOpen.bezierCurveTo(-78, 96, 12, 68, 18, 18);
    fillRimAndStroke(ctx, wingFill, -110, -20, 20, 80, cLight, cMid, cDark, outline, 3.5, wingOpen);
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.4;
    for (const fy of [18, 38, 56]) {
      ctx.beginPath();
      ctx.moveTo(-18, fy - 12);
      ctx.quadraticCurveTo(-58, fy, -94, fy + 8);
      ctx.stroke();
    }
    ctx.restore();
  };

  // Far Wing behind body so both wings are visible during idle and waving
  if (pose.farFlipperChinAmount <= 0.4) {
    drawFeatheredWing(52, 26, -0.25 - pose.farFlipperAngle * 0.35, -0.82);
  }

  // 3. Plumage Body
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);
  const bodyP = new Path2D();
  bodyP.ellipse(-18, 42, 108, 82, 0.08, 0, Math.PI * 2);
  fillRimAndStroke(ctx, bodyP, -100, -40, 60, 120, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(bodyP);
  if (!isHornbill) {
    ctx.fillStyle = '#f59e0b';
    drawOvalSpot(ctx, -68, 2, 58, 30, 0.2);
    ctx.fillStyle = '#dc2626';
    drawOvalSpot(ctx, -78, 8, 38, 20, 0.2);
  } else {
    ctx.fillStyle = '#f8fafc';
    drawOvalSpot(ctx, -24, 106, 86, 36, 0.05);
  }
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyP);
  ctx.restore();

  if (waveAmt < 0.45) {
    drawFeatheredWing(-38, 28, pose.nearFlipperAngle * 0.4 + 0.15);
  }

  // 4. Head, Crown/Casque, Eyes & Articulated Beak-Mouth
  ctx.save();
  ctx.translate(38 + pose.headX, -44 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  if (!isHornbill) {
    ctx.strokeStyle = outline;
    ctx.lineWidth = 3.2;
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 9 - 10, -84);
      ctx.lineTo(i * 18 - 14, -138);
      ctx.stroke();
      ctx.fillStyle = '#1e3a8a';
      drawOvalSpot(ctx, i * 18 - 14, -142, 10, 7, i * 0.15);
      ctx.fillStyle = '#38bdf8';
      drawOvalSpot(ctx, i * 18 - 14, -142, 5, 3.5, i * 0.15);
    }
  }

  const headP = new Path2D();
  headP.arc(0, -8, 86, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -65, -90, 55, 75, cLight, cMid, cDark, outline, 3.6);

  if (!isHornbill) {
    ctx.save();
    ctx.clip(headP);
    ctx.fillStyle = '#e53935';
    drawOvalSpot(ctx, -26 + lookX * 0.7, -8 + lookY * 0.7, 42, 46, -0.1);
    drawOvalSpot(ctx, 50 + lookX * 0.7, 0 + lookY * 0.7, 38, 42, 0.1);
    ctx.restore();
    ctx.lineWidth = 3.6;
    ctx.strokeStyle = outline;
    ctx.stroke(headP);
  }

  drawSoftCheekBlushes(ctx, -44 + lookX * 0.8, 22 + lookY * 0.8, 64 + lookX * 0.8, 28 + lookY * 0.8, 24, 14, pose.blushAlpha);

  drawGlossyAnimalEye(ctx, 'left', -32 + lookX * 0.85, -14 + lookY * 0.85, 25, 29, -0.08, pose, isHornbill ? IRIS_PALETTES.crimsonRed : IRIS_PALETTES.amber, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 52 + lookX * 0.85, -6 + lookY * 0.85, 21, 25, 0.12, pose, isHornbill ? IRIS_PALETTES.crimsonRed : IRIS_PALETTES.amber, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -32 + lookX * 0.85, -52 + lookY * 0.85, 52 + lookX * 0.85, -42 + lookY * 0.85, 34, pose, '#ffffff', 4.0);

  const openAmt = clamp(pose.mouthOpen, 0, 1);
  if (isHornbill) {
    if (openAmt > 0.06) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(16 + lookX, 12 + lookY);
      ctx.quadraticCurveTo(88 + lookX, 14 + lookY, 138 + lookX, 28 + lookY);
      ctx.quadraticCurveTo(88 + lookX, 26 + openAmt * 34 + lookY, 14 + lookX, 22 + openAmt * 18 + lookY);
      ctx.closePath();
      ctx.fillStyle = '#7f1d1d';
      ctx.fill();
      ctx.fillStyle = '#f43f5e';
      drawOvalSpot(ctx, 56 + lookX, 22 + openAmt * 12 + lookY, 26, 8, 0.1);
      ctx.strokeStyle = outline;
      ctx.lineWidth = 3.0;
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(14 + lookX, 16 + lookY);
    ctx.rotate(openAmt * 0.34);
    const lowerBill = new Path2D();
    lowerBill.moveTo(0, -4);
    lowerBill.bezierCurveTo(54, 4, 112, 12, 142, 18);
    lowerBill.bezierCurveTo(106, 34, 44, 28, -4, 14);
    lowerBill.closePath();
    fillRimAndStroke(ctx, lowerBill, 0, -4, 142, 30, '#fff9c4', '#fbc02d', '#d97706', outline, 3.3);
    ctx.restore();

    const upperBill = new Path2D();
    upperBill.moveTo(12 + lookX, -36 + lookY);
    upperBill.bezierCurveTo(96 + lookX, -34 + lookY, 162 + lookX, 2 + lookY, 158 + lookX, 28 + lookY);
    upperBill.bezierCurveTo(112 + lookX, 24 + lookY, 54 + lookX, 18 + lookY, 10 + lookX, 14 + lookY);
    upperBill.closePath();
    fillRimAndStroke(ctx, upperBill, 12, -36, 158, 28, '#fff59d', '#fbc02d', '#ea580c', outline, 3.5);

    const casqueP = new Path2D();
    casqueP.moveTo(-8 + lookX, -66 + lookY);
    casqueP.bezierCurveTo(46 + lookX, -114 + lookY, 124 + lookX, -112 + lookY, 112 + lookX, -58 + lookY);
    casqueP.bezierCurveTo(96 + lookX, -36 + lookY, 38 + lookX, -32 + lookY, -8 + lookX, -42 + lookY);
    casqueP.closePath();
    fillRimAndStroke(ctx, casqueP, -8, -112, 115, -36, '#ff8a65', '#e53935', '#991b1b', outline, 3.5);
  } else {
    if (openAmt > 0.06) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(8 + lookX, 14 + lookY);
      ctx.quadraticCurveTo(38 + lookX, 16 + lookY, 56 + lookX, 24 + lookY);
      ctx.quadraticCurveTo(36 + lookX, 28 + openAmt * 26 + lookY, 6 + lookX, 22 + openAmt * 14 + lookY);
      ctx.closePath();
      ctx.fillStyle = '#7f1d1d';
      ctx.fill();
      ctx.fillStyle = '#fb7185';
      drawOvalSpot(ctx, 28 + lookX, 22 + openAmt * 10 + lookY, 14, 6, 0.12);
      ctx.strokeStyle = outline;
      ctx.lineWidth = 2.8;
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(8 + lookX, 16 + lookY);
    ctx.rotate(openAmt * 0.38);
    const lowerBeak = new Path2D();
    lowerBeak.moveTo(-2, -2);
    lowerBeak.quadraticCurveTo(28, 4, 48, 8);
    lowerBeak.quadraticCurveTo(26, 20, -4, 12);
    lowerBeak.closePath();
    fillRimAndStroke(ctx, lowerBeak, -2, -2, 48, 18, '#fff9db', '#d4b459', '#8c6d1f', outline, 3.0);
    ctx.restore();

    const upperBeak = new Path2D();
    upperBeak.moveTo(6 + lookX, -2 + lookY);
    upperBeak.quadraticCurveTo(54 + lookX, -2 + lookY, 64 + lookX, 22 + lookY);
    upperBeak.quadraticCurveTo(34 + lookX, 20 + lookY, 6 + lookX, 16 + lookY);
    upperBeak.closePath();
    fillRimAndStroke(ctx, upperBeak, 6, -2, 64, 22, '#fffbeb', '#ebd07a', '#a17c28', outline, 3.3);
  }
  ctx.restore();

  // 5. Foreground Waving Wing or Chin-touching Wing
  if (waveAmt >= 0.45) {
    drawFeatheredWing(-38 + pose.nearFlipperShoulderX, 28 + pose.nearFlipperShoulderY, 1.15 + pose.nearFlipperAngle * 0.75);
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawFeatheredWing(56, 68, -2.15 + pose.farFlipperAngle * 0.35);
  }
}

/* ============================================================================
 * A16: RETICULATED PYTHON (Malayopython reticulatus)
 * Matches 16_reticulated_python.png: Continuous, seamless S-coiled python body
 * where the tapering tail emerges smoothly from the base coil, with gold,
 * dark-mahogany, and cream reticulated diamond mesh, ventral scutes & forked tongue.
 * (No dark vertical crown line on head per user fix #9)
 * ========================================================================== */
function drawReticulatedPythonRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#241608';
  const cLight = '#f5cf62';
  const cMid = '#c7922c';
  const cDark = '#7d5210';
  const bellyCream = '#fff6d6';

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Unified Continuous Base Coil + Tapering S-Curved Tail (one single path, zero seam)
  const tailWaveX = Math.sin(pose.waveRaysPhase * 0.9) * 10 + pose.nearFlipperAngle * 14;
  const tailWaveY = Math.cos(pose.waveRaysPhase * 0.9) * 6;
  const baseAndTail = new Path2D();
  baseAndTail.moveTo(-20, 54);
  baseAndTail.bezierCurveTo(68, 52, 128, 68, 128, 98);
  baseAndTail.bezierCurveTo(128, 132, 54, 146, -24, 144);
  baseAndTail.bezierCurveTo(-96, 142, -148, 118, -166, 68);
  baseAndTail.bezierCurveTo(-182, 24, -176 + tailWaveX * 0.6, -22 + tailWaveY, -148 + tailWaveX, -58 + tailWaveY);
  baseAndTail.bezierCurveTo(-152 + tailWaveX * 0.5, -18 + tailWaveY, -144, 22, -122, 52);
  baseAndTail.bezierCurveTo(-102, 66, -64, 56, -20, 54);
  baseAndTail.closePath();

  fillRimAndStroke(ctx, baseAndTail, -175, -58, 128, 144, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(baseAndTail);
  ctx.fillStyle = bellyCream;
  const bellyBand = new Path2D();
  bellyBand.moveTo(-162, 58);
  bellyBand.bezierCurveTo(-136, 116, -84, 132, -18, 132);
  bellyBand.bezierCurveTo(56, 132, 114, 120, 126, 98);
  bellyBand.lineTo(128, 148);
  bellyBand.lineTo(-175, 148);
  bellyBand.closePath();
  ctx.fill(bellyBand);

  // Ventral scute ribs along belly band
  ctx.strokeStyle = 'rgba(125, 82, 16, 0.28)';
  ctx.lineWidth = 1.6;
  for (let vx = -140; vx <= 105; vx += 18) {
    ctx.beginPath();
    ctx.moveTo(vx, 120);
    ctx.lineTo(vx - 6, 142);
    ctx.stroke();
  }

  // Reticulated diamond net markings following the tail and base coil
  for (const [dx, dy, dr, rot] of [
    [-148 + tailWaveX * 0.3, 14, 11, -0.35],
    [-136, 52, 14, -0.25],
    [-104, 88, 18, -0.1],
    [-56, 96, 20, 0],
    [-6, 96, 20, 0],
    [44, 96, 20, 0],
    [92, 94, 18, 0.08],
  ] as const) {
    ctx.save();
    ctx.translate(dx, dy);
    ctx.rotate(rot);
    ctx.fillStyle = '#3b230c';
    ctx.strokeStyle = '#fff5cc';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(0, -dr);
    ctx.lineTo(dr, 0);
    ctx.lineTo(0, dr);
    ctx.lineTo(-dr, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = cLight;
    drawOvalSpot(ctx, 0, 0, dr * 0.25, dr * 0.2, 0);
    ctx.restore();
  }
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(baseAndTail);

  // 2. Middle Loop & Rising Neck Pillar (open top on neck pillar so it merges into head)
  for (const [cx, cy, rx, ry, rot] of [
    [-6, 44, 108, 40, -0.04],
    [16, -4, 62, 46, 0.12],
  ] as const) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    const coilP = new Path2D();
    coilP.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, coilP, -rx, -ry, rx, ry, cLight, cMid, cDark, outline, 3.6);

    ctx.save();
    ctx.clip(coilP);
    ctx.fillStyle = bellyCream;
    drawOvalSpot(ctx, 0, ry * 0.78, rx * 0.88, ry * 0.36, 0);

    for (let dx = -rx + 28; dx < rx - 20; dx += 46) {
      ctx.fillStyle = '#3b230c';
      ctx.strokeStyle = '#fff5cc';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(dx, -20);
      ctx.lineTo(dx + 19, -2);
      ctx.lineTo(dx, 16);
      ctx.lineTo(dx - 19, -2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = cLight;
      drawOvalSpot(ctx, dx, -2, 5, 4, 0);
    }
    ctx.restore();
    ctx.lineWidth = 3.6;
    ctx.strokeStyle = outline;
    ctx.stroke(coilP);
    ctx.restore();
  }
  ctx.restore();

  // 3. Python Head Group (clean golden crown with subtle scale shimmer, no forehead line!)
  ctx.save();
  ctx.translate(24 + pose.headX, -54 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  const headP = new Path2D();
  headP.ellipse(4, -4, 98, 78, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -75, -80, 60, 75, cLight, cMid, cDark, outline, 3.7);
  ctx.save();
  ctx.clip(headP);
  // Subtle golden crown scale arches (no vertical dark line)
  ctx.strokeStyle = 'rgba(125, 82, 16, 0.24)';
  ctx.lineWidth = 2.0;
  for (const [sx, sy] of [
    [-16, -48],
    [12, -52],
    [0, -34],
  ]) {
    ctx.beginPath();
    ctx.arc(sx + lookX * 0.5, sy + lookY * 0.4, 11, Math.PI * 0.15, Math.PI * 0.85);
    ctx.stroke();
  }
  drawSoftCheekBlushes(ctx, -48 + lookX * 0.8, 18 + lookY * 0.8, 68 + lookX * 0.8, 24 + lookY * 0.8, 24, 14, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  // Sensory labial heat pits along upper lip
  ctx.fillStyle = '#4a2c0a';
  for (const px of [-14, 2, 34, 48]) {
    drawOvalSpot(ctx, px + lookX, 22 + lookY, 3.2, 2.2, 0);
  }

  // Forked crimson snake tongue flicking out
  const tongueFlick = Math.sin(pose.waveRaysPhase * 1.5) * 4;
  ctx.strokeStyle = '#e11d48';
  ctx.lineWidth = 3.2;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(22 + lookX, 42 + lookY);
  ctx.quadraticCurveTo(32 + lookX, 58 + lookY, 36 + lookX + tongueFlick, 66 + lookY);
  ctx.lineTo(28 + lookX + tongueFlick, 76 + lookY);
  ctx.moveTo(36 + lookX + tongueFlick, 66 + lookY);
  ctx.lineTo(46 + lookX + tongueFlick, 74 + lookY);
  ctx.stroke();

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 34 + lookY, 0.82, 0.08, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -34 + lookX * 0.85, -12 + lookY * 0.85, 27, 32, -0.08, pose, IRIS_PALETTES.amber, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 62 + lookX * 0.85, -2 + lookY * 0.85, 23, 28, 0.12, pose, IRIS_PALETTES.amber, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -34 + lookX * 0.85, -52 + lookY * 0.85, 62 + lookX * 0.85, -38 + lookY * 0.85, 36, pose, outline, 4.0);
  ctx.restore();
}

/* ============================================================================
 * A17 & A25: CLOUDED MONITOR LIZARD & ASIAN WATER MONITOR
 * Completely rebuilt Varanus lizard anatomy (User Fixes #10 & #16):
 * - Sharp, wedge-shaped lizard head (not rounded mammal head)
 * - Smaller, alert reptile eyes positioned laterally on the sharp snout
 * - Continuous, muscular neck-to-torso and torso-to-tail transitions ("嵌入")
 * - Intricate bead-like scale textures, gular throat folds, and long recurved claws
 * - A17 Clouded Monitor (isClouded=true): Sandy-olive arboreal monitor with netted
 *   yellow-cream ocelli crossbands, banded whip tail, and pinkish-blue forked tongue.
 * - A25 Asian Water Monitor (isClouded=false): Deep forest-olive giant monitor with
 *   bold yellow transverse rosette rows, laterally compressed high-crested swimming tail,
 *   dark temporal eye-stripe, and long slate-blue forked Varanus tongue.
 * ========================================================================== */
function drawMonitorLizardRig(ctx: CanvasRenderingContext2D, pose: TurtlePose, isClouded: boolean): void {
  const outline = isClouded ? '#292111' : '#122416';
  const cLight = isClouded ? '#dfd084' : '#5ca856';
  const cMid = isClouded ? '#9e8842' : '#2f6e31';
  const cDark = isClouded ? '#5c4b1b' : '#173d1a';
  const spotCol = isClouded ? '#fff3b0' : '#facc15';
  const bellyCol = isClouded ? '#f7eed2' : '#e8dfa2';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Far Hind Leg & Far Front Leg behind torso (all 4 legs grounded on y=186!)
  drawSculptedPawLimb(ctx, -48, 86, pose.hindFarAngle * 0.45 - 0.05, 100, 42, cMid, cDark, outline, outline, {
    clawsColor: '#e8dec8',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 78, pose.farFlipperAngle * 0.35 - 0.08, 108, 42, cMid, cDark, outline, outline, {
      clawsColor: '#e8dec8',
    });
  }

  // 1. Unified Continuous Monitor Body + Tail + Muscular Neck Bridge (Single Path2D like A16 Python!)
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const tailSwing = Math.sin(pose.waveRaysPhase * 0.85) * 10 + pose.hindNearAngle * 22;

  const bodyAndTail = new Path2D();
  if (isClouded) {
    // Continuous arboreal whip tail + elongated monitor torso + rising muscular neck
    bodyAndTail.moveTo(-298, 118 + tailSwing);
    bodyAndTail.bezierCurveTo(-244, 72 + tailSwing * 0.4, -172, 24, -104, 16);
  } else {
    // High-crested laterally compressed swimming blade tail + torso + rising muscular neck
    bodyAndTail.moveTo(-308, 102 + tailSwing);
    bodyAndTail.bezierCurveTo(-246, 36 + tailSwing * 0.4, -168, -6, -104, 12);
  }
  bodyAndTail.bezierCurveTo(-68, -28, -12, -40, 24, -30);
  bodyAndTail.bezierCurveTo(52, -38, 72, -56, 88, -42);
  bodyAndTail.bezierCurveTo(106, -18, 96, 44, 62, 84);
  bodyAndTail.bezierCurveTo(18, 120, -64, 118, -104, 82);
  if (isClouded) {
    bodyAndTail.bezierCurveTo(-162, 86, -228, 110 + tailSwing * 0.4, -282, 136 + tailSwing);
    bodyAndTail.bezierCurveTo(-298, 142 + tailSwing, -310, 128 + tailSwing, -298, 118 + tailSwing);
  } else {
    bodyAndTail.bezierCurveTo(-162, 92, -230, 118 + tailSwing * 0.4, -288, 134 + tailSwing);
    bodyAndTail.bezierCurveTo(-308, 138 + tailSwing, -320, 116 + tailSwing, -308, 102 + tailSwing);
  }
  bodyAndTail.closePath();

  fillRimAndStroke(ctx, bodyAndTail, -300, -48, 98, 126, cLight, cMid, cDark, outline, 3.6);

  ctx.save();
  ctx.clip(bodyAndTail);
  // Tail banding & dorsal keel ridge inside continuous tail
  ctx.fillStyle = spotCol;
  for (const [tx, ty, rx, ry] of [
    [-144, 54, 9, 28],
    [-184, 70 + tailSwing * 0.25, 8, 26],
    [-224, 88 + tailSwing * 0.5, 7, 22],
    [-262, 108 + tailSwing * 0.75, 6, 18],
  ] as const) {
    drawOvalSpot(ctx, tx, ty, rx, ry, -0.32);
  }
  if (!isClouded) {
    ctx.strokeStyle = cLight;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(-116, 16);
    ctx.bezierCurveTo(-172, 2, -238, 42 + tailSwing * 0.4, -296, 98 + tailSwing);
    ctx.stroke();
  }

  // Cream-ochre plated reptile chest & gular throat folds on the front chest (x = 48)
  // so the near front leg at x = 0 welds seamlessly into the green monitor flank!
  ctx.fillStyle = bellyCol;
  drawOvalSpot(ctx, 54, 72, 42, 44, 0.12);
  ctx.strokeStyle = 'rgba(60, 50, 20, 0.25)';
  ctx.lineWidth = 1.8;
  for (let gy = -4; gy <= 84; gy += 16) {
    ctx.beginPath();
    ctx.arc(46, gy, 38, 0.15, 1.15);
    ctx.stroke();
  }

  // Bead-like monitor lizard osteoderm scales & species-specific dorsal patterns (strictly above leg roots!)
  if (isClouded) {
    for (const [sx, sy, rx, ry] of [
      [-86, 8, 15, 10],
      [-48, -2, 16, 11],
      [-8, 6, 15, 10],
      [-68, 34, 15, 9],
      [-26, 36, 14, 9],
      [14, 28, 13, 8],
    ] as const) {
      ctx.fillStyle = cDark;
      drawOvalSpot(ctx, sx, sy, rx + 3, ry + 2, 0.15);
      ctx.strokeStyle = spotCol;
      ctx.lineWidth = 3.2;
      ctx.beginPath();
      ctx.ellipse(sx, sy, rx, ry, 0.15, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = cLight;
      drawOvalSpot(ctx, sx, sy, 4, 3, 0.15);
    }
  } else {
    for (const [sx, sy, r] of [
      [-92, 4, 10],
      [-86, 26, 9],
      [-56, -4, 11],
      [-50, 18, 10],
      [-44, 38, 8],
      [-18, 0, 11],
      [-12, 22, 10],
      [18, 8, 9],
      [24, 28, 8],
    ] as const) {
      ctx.fillStyle = '#122416';
      drawOvalSpot(ctx, sx, sy, r + 3, r * 0.78 + 2, 0.12);
      ctx.fillStyle = spotCol;
      drawOvalSpot(ctx, sx, sy, r, r * 0.72, 0.12);
      ctx.fillStyle = cMid;
      drawOvalSpot(ctx, sx, sy, r * 0.38, r * 0.3, 0.12);
    }
  }
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyAndTail);
  ctx.restore();

  // Near Hind Leg & Near Front Leg planted on ground (y ≈ 186) with alpha-feathered root weld
  drawSculptedPawLimb(ctx, -96, 82, pose.hindNearAngle * 0.45 + 0.06, 104, 46, cLight, cMid, cDark, outline, {
    clawsColor: '#f5ecd7',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, 0, 74, pose.nearFlipperAngle * 0.35 + 0.05, 112, 44, cLight, cMid, cDark, outline, {
      clawsColor: '#f5ecd7',
    });
  }

  // 2. Closed, Smoothly Rounded Wedge Varanus Lizard Head (zero flat vertical cut on back of head!)
  ctx.save();
  ctx.translate(64 + pose.headX, -42 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 12;
  const lookY = pose.headLookY * 8;

  const headFill = new Path2D();
  headFill.moveTo(-64, 4);
  headFill.bezierCurveTo(-66, -34, -34, -56, 22, -52);
  headFill.bezierCurveTo(46, -50, 68 + lookX * 0.5, -26 + lookY * 0.4, 98 + lookX * 0.75, -8 + lookY * 0.55);
  headFill.bezierCurveTo(116 + lookX * 0.8, 4 + lookY * 0.6, 112 + lookX * 0.8, 18 + lookY * 0.6, 94 + lookX * 0.7, 28 + lookY * 0.6);
  headFill.bezierCurveTo(58 + lookX * 0.4, 46 + lookY * 0.4, -12, 54, -46, 40);
  headFill.bezierCurveTo(-60, 32, -64, 18, -64, 4);
  headFill.closePath();

  fillRimAndStroke(ctx, headFill, -66, -56, 112, 52, cLight, cMid, cDark, outline, 3.6);

  ctx.save();
  ctx.clip(headFill);
  ctx.fillStyle = bellyCol;
  drawOvalSpot(ctx, 18 + lookX * 0.4, 36 + lookY * 0.4, 78, 22, 0.06);

  ctx.strokeStyle = 'rgba(25, 40, 20, 0.26)';
  ctx.lineWidth = 1.6;
  for (const [hx, hy, hr] of [
    [16, -24, 9],
    [36, -18, 8],
    [54, -12, 7],
    [26, -8, 8],
  ] as const) {
    ctx.beginPath();
    ctx.ellipse(hx + lookX * 0.5, hy + lookY * 0.4, hr, hr * 0.65, 0.15, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (!isClouded) {
    ctx.fillStyle = '#122416';
    drawOvalSpot(ctx, -36 + lookX * 0.4, -12 + lookY * 0.4, 24, 7, -0.12);
    ctx.fillStyle = spotCol;
    drawOvalSpot(ctx, 64 + lookX * 0.6, 4 + lookY * 0.5, 6, 12, 0.2);
    drawOvalSpot(ctx, 82 + lookX * 0.7, 6 + lookY * 0.5, 5, 10, 0.2);
  } else {
    ctx.fillStyle = '#4a3c14';
    drawOvalSpot(ctx, -34 + lookX * 0.4, -10 + lookY * 0.4, 20, 6, -0.1);
  }

  ctx.fillStyle = cDark;
  drawOvalSpot(ctx, -42 + lookX * 0.25, 4 + lookY * 0.25, 6, 11, 0.15);

  drawSoftCheekBlushes(ctx, -14 + lookX * 0.6, 14 + lookY * 0.6, 56 + lookX * 0.7, 16 + lookY * 0.6, 18, 10, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headFill);

  ctx.fillStyle = outline;
  const nostrilX = (isClouded ? 62 : 82) + lookX * 0.75;
  const nostrilY = (isClouded ? -6 : -2) + lookY * 0.55;
  drawOvalSpot(ctx, nostrilX, nostrilY, 4.5, 2.8, 0.25);

  const tongueFlick = Math.sin(pose.waveRaysPhase * 1.6) * 4;
  ctx.strokeStyle = isClouded ? '#e879a0' : '#64748b';
  ctx.lineWidth = 2.8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(86 + lookX * 0.75, 20 + lookY * 0.6);
  ctx.quadraticCurveTo(106 + lookX * 0.8, 26 + lookY * 0.6, 116 + lookX * 0.8 + tongueFlick, 30 + lookY * 0.6);
  ctx.lineTo(128 + lookX * 0.8 + tongueFlick, 24 + lookY * 0.6);
  ctx.moveTo(116 + lookX * 0.8 + tongueFlick, 30 + lookY * 0.6);
  ctx.lineTo(126 + lookX * 0.8 + tongueFlick, 38 + lookY * 0.6);
  ctx.stroke();

  drawExpressiveAnimalMouth(ctx, 42 + lookX * 0.65, 22 + lookY * 0.6, 0.78, 0.08, pose, outline);

  const iris = isClouded ? IRIS_PALETTES.goldenHazel : IRIS_PALETTES.amber;
  drawGlossyAnimalEye(ctx, 'left', -12 + lookX * 0.65, -14 + lookY * 0.65, 17, 19, -0.06, pose, iris, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 48 + lookX * 0.7, -10 + lookY * 0.65, 14, 16, 0.1, pose, iris, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -12 + lookX * 0.65, -38 + lookY * 0.65, 48 + lookX * 0.7, -32 + lookY * 0.65, 24, pose, outline, 3.6);
  ctx.restore();

  // Foreground Waving Limb (waves outward to top-left!) or Chin-Touching Limb
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -28 + pose.nearFlipperShoulderX,
      36 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      108,
      44,
      cLight,
      cMid,
      cDark,
      outline,
      { clawsColor: '#f5ecd7' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 58, 66, -2.45 + pose.farFlipperAngle * 0.35, 88, 42, cLight, cMid, cDark, outline, {
      clawsColor: '#f5ecd7',
    });
  }
}

/* ============================================================================
 * A18 & A19: BLACK GIANT SQUIRREL & SMOOTH-COATED OTTER
 * - A18 Black Giant Squirrel (User Fix #11: "where is the nose?"): Huge fluffy
 *   plume tail seamlessly embedded ("嵌入"), jet-black dorsal coat, warm orange-buff
 *   chest & cheeks, ear tufts, and a distinct sculpted squirrel nose pad + whiskers!
 * - A19 Smooth-Coated Otter (User Fix #12: "Tails seems detached"): Sleek chestnut
 *   river otter with thick muscular rudder tail seamlessly embedded ("嵌入") into
 *   the lower back, cream throat patch, whiskers, and webbed paws.
 * ========================================================================== */
function drawBlackGiantSquirrelRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#141110';
  const cLight = '#423a38';
  const cMid = '#26201f';
  const cDark = '#141010';
  const buff = '#f5b062';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Far Hind Leg & Far Front Leg behind torso (all 4 legs grounded on y=184!)
  drawSculptedPawLimb(ctx, -48, 88, pose.hindFarAngle * 0.4, 96, 46, cLight, cMid, cDark, outline, {
    pawTipColor: buff,
    clawsColor: '#3d3028',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 78, pose.farFlipperAngle * 0.35 - 0.08, 106, 44, cLight, cMid, cDark, outline, {
      pawTipColor: buff,
      clawsColor: '#3d3028',
    });
  }

  // Torso + Seamlessly Embedded Giant Plume Tail ("嵌入")
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const torso = new Path2D();
  torso.ellipse(-18, 42, 98, 84, 0.06, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -95, -40, 55, 120, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(torso);
  ctx.fillStyle = buff;
  drawOvalSpot(ctx, 48, 52, 38, 66, 0.08);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);

  // Huge Fluffy Plume Tail emerging continuously from lower rump (drawn after torso with open root & untwisted curves!)
  ctx.save();
  ctx.translate(-110, 48);
  ctx.rotate(pose.hindNearAngle * 0.4 + Math.sin(pose.waveRaysPhase * 0.6) * 0.06);
  const tailFill = new Path2D();
  tailFill.moveTo(0, -18);
  tailFill.quadraticCurveTo(18, 0, 0, 18);
  tailFill.bezierCurveTo(-84, 18, -168, -74, -122, -178);
  tailFill.bezierCurveTo(-82, -242, 16, -202, -10, -108);
  tailFill.bezierCurveTo(-28, -52, -14, -22, 0, -18);
  tailFill.closePath();

  const tailStroke = new Path2D();
  tailStroke.moveTo(0, -18);
  tailStroke.bezierCurveTo(-14, -22, -28, -52, -10, -108);
  tailStroke.bezierCurveTo(16, -202, -82, -242, -122, -178);
  tailStroke.bezierCurveTo(-168, -74, -84, 18, 0, 18);
  fillRimAndStroke(ctx, tailFill, -145, -215, 16, 20, cLight, cMid, cMid, outline, 3.6, tailStroke);

  // Fluffy fur texture strokes inside plume tail
  ctx.save();
  ctx.clip(tailFill);
  ctx.strokeStyle = 'rgba(255, 235, 215, 0.14)';
  ctx.lineWidth = 2.2;
  for (const [tx, ty] of [
    [-96, -68],
    [-88, -124],
    [-58, -168],
    [-36, -118],
  ]) {
    ctx.beginPath();
    ctx.arc(tx, ty, 28, Math.PI * 0.7, Math.PI * 1.4);
    ctx.stroke();
  }
  ctx.restore();
  ctx.restore();
  ctx.restore();

  // Near Hind Leg & Near Front Arm planted on ground (y ≈ 184)
  drawSculptedPawLimb(ctx, -92, 84, pose.hindNearAngle * 0.4, 100, 50, cLight, cMid, cDark, outline, {
    pawTipColor: buff,
    clawsColor: '#3d3028',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -4, 74, pose.nearFlipperAngle * 0.35 + 0.05, 110, 44, cLight, cMid, cDark, outline, {
      pawTipColor: buff,
      clawsColor: '#3d3028',
    });
  }

  // Head with Distinct Squirrel Nose Pad, Nostrils & Whiskers
  ctx.save();
  ctx.translate(34 + pose.headX, -42 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey] of [
    [-76, -86],
    [78, -76],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    const earP = new Path2D();
    earP.arc(0, 0, 28, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, 0, -28, 0, 28, cLight, cMid, cDark, outline, 3.4);
    ctx.fillStyle = buff;
    drawOvalSpot(ctx, 0, 2, 15, 15, 0);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.ellipse(4, -6, 98, 86, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -75, -90, 55, 80, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(headP);
  // Warm apricot-buff lower cheeks, muzzle, and throat
  ctx.fillStyle = buff;
  drawOvalSpot(ctx, 16 + lookX * 0.8, 34 + lookY * 0.8, 78, 50, 0.05);
  drawSoftCheekBlushes(ctx, -48 + lookX * 0.8, 22 + lookY * 0.8, 72 + lookX * 0.8, 28 + lookY * 0.8, 25, 14, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  // Cute sculpted rounded-triangle Squirrel Nose Pad, philtrum & nostrils (User Fix #11!)
  const noseX = 18 + lookX * 0.92;
  const noseY = 14 + lookY * 0.88;
  const noseP = new Path2D();
  noseP.moveTo(noseX - 15, noseY - 6);
  noseP.quadraticCurveTo(noseX, noseY - 12, noseX + 15, noseY - 6);
  noseP.quadraticCurveTo(noseX + 14, noseY + 8, noseX, noseY + 12);
  noseP.quadraticCurveTo(noseX - 14, noseY + 8, noseX - 15, noseY - 6);
  noseP.closePath();
  fillRimAndStroke(ctx, noseP, noseX - 14, noseY - 10, noseX + 14, noseY + 12, '#6b3e38', '#3d1e1b', '#1f0d0b', outline, 2.6);
  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  drawOvalSpot(ctx, noseX - 4, noseY - 4, 5, 2.4, -0.15);
  ctx.fillStyle = '#120807';
  drawOvalSpot(ctx, noseX - 7, noseY + 2, 2.8, 2.0, 0.3);
  drawOvalSpot(ctx, noseX + 7, noseY + 2, 2.8, 2.0, -0.3);
  ctx.strokeStyle = outline;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.moveTo(noseX, noseY + 11);
  ctx.lineTo(noseX, 34 + lookY);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(40, 26, 20, 0.65)';
  ctx.lineWidth = 2.0;
  for (const wy of [16, 24]) {
    ctx.beginPath();
    ctx.moveTo(noseX - 22, wy + lookY * 0.85);
    ctx.quadraticCurveTo(noseX - 48, wy - 2 + lookY * 0.85, noseX - 68, wy + 5 + lookY * 0.85);
    ctx.moveTo(noseX + 22, wy + lookY * 0.85);
    ctx.quadraticCurveTo(noseX + 48, wy - 2 + lookY * 0.85, noseX + 66, wy + 6 + lookY * 0.85);
    ctx.stroke();
  }

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 42 + lookY, 0.84, 0.08, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -36 + lookX * 0.85, -14 + lookY * 0.85, 28, 33, -0.08, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 64 + lookX * 0.85, -4 + lookY * 0.85, 24, 29, 0.12, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -36 + lookX * 0.85, -56 + lookY * 0.85, 64 + lookX * 0.85, -42 + lookY * 0.85, 36, pose, buff, 4.0);
  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -38 + pose.nearFlipperShoulderX,
      30 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      112,
      44,
      cLight,
      cMid,
      cDark,
      outline,
      { pawTipColor: buff, clawsColor: '#3d3028' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 62, 70, -2.45 + pose.farFlipperAngle * 0.35, 90, 44, cLight, cMid, cDark, outline, {
      pawTipColor: buff,
      clawsColor: '#3d3028',
    });
  }
}

function drawSmoothCoatedOtterRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#24150c';
  const cLight = '#a8764b';
  const cMid = '#7a4f2b';
  const cDark = '#4f3017';
  const cream = '#f7e6ce';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Far Hind Leg & Far Front Leg behind torso (all 4 legs grounded on y=184!)
  drawSculptedPawLimb(ctx, -48, 88, pose.hindFarAngle * 0.4, 96, 46, cMid, cDark, outline, outline, {
    clawsColor: '#e8d7c3',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 80, pose.farFlipperAngle * 0.35 - 0.08, 104, 44, cMid, cDark, outline, outline, {
      clawsColor: '#e8d7c3',
    });
  }

  // Unified Continuous Otter Torso + Muscular Rudder Tail (Single Path2D like A16 Python!)
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const tailWag = Math.sin(pose.waveRaysPhase * 0.85) * 10 + pose.hindNearAngle * 20;
  const bodyAndTail = new Path2D();
  bodyAndTail.moveTo(-242, 102 + tailWag);
  bodyAndTail.bezierCurveTo(-214, 68 + tailWag * 0.5, -158, 38, -112, 26);
  bodyAndTail.bezierCurveTo(-84, -36, 12, -48, 66, -12);
  bodyAndTail.bezierCurveTo(106, 16, 100, 84, 52, 112);
  bodyAndTail.bezierCurveTo(4, 136, -68, 130, -108, 96);
  bodyAndTail.bezierCurveTo(-142, 102, -176, 108 + tailWag * 0.5, -214, 120 + tailWag);
  bodyAndTail.bezierCurveTo(-234, 126 + tailWag, -252, 114 + tailWag, -242, 102 + tailWag);
  bodyAndTail.closePath();

  fillRimAndStroke(ctx, bodyAndTail, -245, -42, 92, 130, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(bodyAndTail);
  ctx.fillStyle = cream;
  drawOvalSpot(ctx, 48, 52, 40, 68, 0.08);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyAndTail);
  ctx.restore();

  // Near Hind Leg & Near Front Arm planted on ground (y ≈ 184)
  drawSculptedPawLimb(ctx, -94, 86, pose.hindNearAngle * 0.4, 98, 50, cLight, cMid, cDark, outline, {
    clawsColor: '#e8d7c3',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -4, 76, pose.nearFlipperAngle * 0.35 + 0.05, 108, 46, cLight, cMid, cDark, outline, {
      clawsColor: '#e8d7c3',
    });
  }

  // Sleek Otter Head with Whiskers
  ctx.save();
  ctx.translate(36 + pose.headX, -38 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  for (const [ex, ey] of [
    [-86, -42],
    [88, -32],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    const earP = new Path2D();
    earP.arc(0, 0, 20, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, 0, -20, 0, 20, cLight, cMid, cDark, outline, 3.3);
    ctx.restore();
  }

  const headP = new Path2D();
  headP.ellipse(6, -4, 104, 82, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -75, -85, 60, 75, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(headP);
  ctx.fillStyle = cream;
  drawOvalSpot(ctx, 18 + lookX * 0.8, 38 + lookY * 0.8, 78, 44, 0.05);
  drawSoftCheekBlushes(ctx, -48 + lookX * 0.8, 22 + lookY * 0.8, 72 + lookX * 0.8, 28 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  // Otter whiskers
  ctx.strokeStyle = '#fffdf7';
  ctx.lineWidth = 2.6;
  for (const wy of [22, 32]) {
    ctx.beginPath();
    ctx.moveTo(-28 + lookX, wy + lookY);
    ctx.lineTo(-76 + lookX, wy + 6 + lookY);
    ctx.moveTo(58 + lookX, wy + lookY);
    ctx.lineTo(104 + lookX, wy + 8 + lookY);
    ctx.stroke();
  }

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 42 + lookY, 0.84, 0.08, pose, outline);
  ctx.fillStyle = '#29170c';
  drawOvalSpot(ctx, 22 + lookX, 12 + lookY, 16, 11, 0.06);

  drawGlossyAnimalEye(ctx, 'left', -36 + lookX * 0.85, -14 + lookY * 0.85, 27, 32, -0.08, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 64 + lookX * 0.85, -4 + lookY * 0.85, 23, 28, 0.12, pose, IRIS_PALETTES.warmBrown, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -36 + lookX * 0.85, -54 + lookY * 0.85, 64 + lookX * 0.85, -40 + lookY * 0.85, 36, pose, outline, 4.0);
  ctx.restore();

  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -38 + pose.nearFlipperShoulderX,
      32 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      112,
      46,
      cLight,
      cMid,
      cDark,
      outline,
      { clawsColor: '#e8d7c3' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 64, 72, -2.45 + pose.farFlipperAngle * 0.35, 92, 46, cLight, cMid, cDark, outline, {
      clawsColor: '#e8d7c3',
    });
  }
}

/* ============================================================================
 * A20 & A38: GIANT FRESHWATER PRAWN (Udang Galah) & HARLEQUIN SHRIMP
 * Rebuilt per User Fixes #13, #17 & #20:
 * - Body is NO LONGER overlapping round circles; instead it is a continuous arched
 *   crustacean strip that has scalloped/rounded dorsal tergite arches along the TOP
 *   ridge only and a smooth continuous ventral curve ending in an articulated tail fan.
 * - A20 Giant Freshwater Prawn: Extra-long segmented cobalt-blue cheliped arms
 *   terminating in cute small articulated pincer claws (chelae) at the hands!
 * - A38 Harlequin Shrimp: Porcelain-white body with ornate magenta-violet rosette
 *   blotches, scalloped petal-like raptorialgnathopod paddles, and striped swimmerets.
 * ========================================================================== */
function drawCrustaceanRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'prawn' | 'harlequin',
): void {
  const isPrawn = species === 'prawn';
  const outline = isPrawn ? '#12263a' : '#2e122b';
  const cLight = isPrawn ? '#73c2fb' : '#ffffff';
  const cMid = isPrawn ? '#2e86de' : '#f7e8fa';
  const cDark = isPrawn ? '#1b4f72' : '#d2b4de';
  const abdomenLight = isPrawn ? '#fbd266' : '#ffffff';
  const abdomenMid = isPrawn ? '#e89d25' : '#f5d9f2';
  const abdomenDark = isPrawn ? '#9e5c0c' : '#c48fd1';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // 1. Continuous Arched Crustacean Abdomen Strip (rounded along TOP dorsal ridge only, NOT overlapping circles!)
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const tailFlex = Math.sin(pose.waveRaysPhase * 0.9) * 8 + pose.hindNearAngle * 14;

  // Delicate ventral pleopods (swimmerets) along the underside of the continuous abdomen strip
  for (const [px, py, rot] of [
    [-46, 86, 0.35],
    [-82, 92, 0.5],
    [-116, 102, 0.65],
    [-144, 118, 0.8],
  ] as const) {
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(rot + Math.sin(pose.waveRaysPhase * 1.4 + px * 0.05) * 0.14);
    const pleo = new Path2D();
    pleo.ellipse(0, 18, 8, 20, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, pleo, -8, 0, 8, 36, cLight, cMid, cDark, outline, 2.5);
    ctx.restore();
  }

  // Spread Uropod Tail Fan at the tip of the continuous abdomen
  ctx.save();
  ctx.translate(-174, 128 + tailFlex);
  ctx.rotate(0.35 + tailFlex * 0.015);
  for (const [ang, rx, ry] of [
    [-0.45, 15, 36],
    [0, 16, 40],
    [0.45, 15, 36],
  ] as const) {
    ctx.save();
    ctx.rotate(ang);
    const fanP = new Path2D();
    fanP.ellipse(0, 22, rx, ry, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, fanP, -rx, 0, rx, 56, isPrawn ? '#48dbfb' : '#f48fb1', cMid, cDark, outline, 2.8);
    // Fin ray striations on tail fan blades
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 6);
    ctx.lineTo(0, 48);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();

  // Continuous Arched Shrimp Body Strip (rounded/scalloped along the TOP ridge only, smooth ventral curve)
  const bodyStrip = new Path2D();
  bodyStrip.moveTo(14, -8);
  // Top ridge with 5 gentle rounded dorsal tergite humps (continuous single outline)
  bodyStrip.quadraticCurveTo(-18, -32, -52, -16);
  bodyStrip.quadraticCurveTo(-84, -22, -112, -2);
  bodyStrip.quadraticCurveTo(-142, 4, -162, 32);
  bodyStrip.quadraticCurveTo(-184, 52, -188, 84 + tailFlex * 0.5);
  bodyStrip.quadraticCurveTo(-194, 112 + tailFlex, -176, 134 + tailFlex);
  // Smooth continuous ventral underside returning to cephalothorax
  bodyStrip.bezierCurveTo(-152, 138 + tailFlex, -138, 108 + tailFlex * 0.4, -112, 92);
  bodyStrip.bezierCurveTo(-78, 76, -34, 84, 24, 72);
  bodyStrip.closePath();

  fillRimAndStroke(ctx, bodyStrip, -192, -32, 24, 138, abdomenLight, abdomenMid, abdomenDark, outline, 3.5);

  ctx.save();
  ctx.clip(bodyStrip);
  // Internal subtle segment crease lines that stop inside the body (preserving continuous strip look)
  ctx.strokeStyle = isPrawn ? 'rgba(120, 62, 8, 0.42)' : 'rgba(136, 14, 79, 0.35)';
  ctx.lineWidth = 2.4;
  for (const [x1, y1, cx, cy, x2, y2] of [
    [-52, -16, -42, 34, -56, 78],
    [-112, -2, -96, 44, -104, 88],
    [-162, 32, -138, 68, -134, 104],
    [-186, 82 + tailFlex * 0.5, -162, 98 + tailFlex * 0.6, -154, 120 + tailFlex * 0.7],
  ] as const) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.quadraticCurveTo(cx, cy, x2, y2);
    ctx.stroke();
  }

  if (isPrawn) {
    // Golden-blue iridescent lateral band & belly dots on Udang Galah
    ctx.fillStyle = 'rgba(46, 134, 222, 0.32)';
    drawOvalSpot(ctx, -64, 28, 56, 22, -0.22);
    ctx.fillStyle = '#fff5cc';
    for (const [dx, dy] of [
      [-32, 58],
      [-68, 64],
      [-102, 74],
      [-132, 92],
    ]) {
      drawOvalSpot(ctx, dx, dy, 4.5, 3.2, -0.2);
    }
  } else {
    // Ornate magenta-crimson and violet-blue edged rosettes of Harlequin Shrimp
    for (const [rx, ry, r1, r2, rot] of [
      [-28, 22, 22, 16, 0.15],
      [-84, 34, 20, 15, -0.18],
      [-134, 62, 17, 13, -0.35],
      [-164, 102 + tailFlex * 0.5, 13, 10, -0.5],
    ] as const) {
      ctx.fillStyle = '#6a1b9a';
      drawOvalSpot(ctx, rx, ry, r1 + 3, r2 + 3, rot);
      ctx.fillStyle = '#d81b60';
      drawOvalSpot(ctx, rx, ry, r1, r2, rot);
      ctx.fillStyle = '#ff80ab';
      drawOvalSpot(ctx, rx - 3, ry - 3, r1 * 0.4, r2 * 0.4, rot);
    }
  }
  ctx.restore();
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyStrip);
  ctx.restore();

  // 2. Articulated Cheliped Arms (User Fix #13: A20 longer hand + cute small pincer claws at the tips!)
  const drawClaw = (side: -1 | 1, isForeground: boolean) => {
    ctx.save();
    const isLeft = side === -1;
    ctx.translate(
      isLeft ? -36 + pose.nearFlipperShoulderX : 68,
      30 + (isLeft ? pose.nearFlipperShoulderY : 0),
    );
    ctx.rotate(
      isLeft && isForeground
        ? 2.15 + pose.nearFlipperAngle * 0.85
        : side * 0.36 + (isLeft ? pose.nearFlipperAngle * 0.35 : pose.farFlipperAngle * 0.4),
    );

    if (isPrawn) {
      // Extra-long segmented cobalt-blue Udang Galah arm (merus + carpus + palm) + cute small pincer claws at tip!
      const armP = new Path2D();
      armP.moveTo(-8, -4);
      armP.bezierCurveTo(-18, 48, -22, 114, -10, 166);
      armP.bezierCurveTo(-4, 178, 12, 178, 16, 164);
      armP.bezierCurveTo(22, 112, 16, 46, 8, -4);
      armP.closePath();

      const armStroke = new Path2D();
      armStroke.moveTo(-8, 6);
      armStroke.bezierCurveTo(-18, 48, -22, 114, -10, 166);
      armStroke.bezierCurveTo(-4, 178, 12, 178, 16, 164);
      armStroke.bezierCurveTo(22, 112, 16, 46, 8, 6);

      fillRimAndStroke(ctx, armP, -22, 0, 22, 178, '#48dbfb', '#0abde3', '#192a56', outline, 3.3, armStroke);

      // Joint rings & spiny tubercles along the long blue prawn arm
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2.4;
      for (const jy of [54, 112]) {
        ctx.beginPath();
        ctx.arc(0, jy, 12, 0.15, Math.PI - 0.15);
        ctx.stroke();
      }

      // Cute small articulated pincer claw (chela: dactylus + propodus fingers) at the hand tip!
      const pincerOpen = 0.18 + Math.sin(pose.waveRaysPhase * 1.6) * 0.08;
      // Left pincer finger
      ctx.save();
      ctx.translate(-4, 168);
      ctx.rotate(-pincerOpen);
      const fingerL = new Path2D();
      fingerL.moveTo(-5, 0);
      fingerL.quadraticCurveTo(-12, 18, -3, 32);
      fingerL.quadraticCurveTo(3, 20, 4, 0);
      fingerL.closePath();
      fillRimAndStroke(ctx, fingerL, -12, 0, 4, 32, '#7ef9ff', '#0abde3', '#192a56', outline, 2.8);
      ctx.restore();

      // Right pincer finger
      ctx.save();
      ctx.translate(8, 168);
      ctx.rotate(pincerOpen);
      const fingerR = new Path2D();
      fingerR.moveTo(-4, 0);
      fingerR.quadraticCurveTo(-3, 20, 3, 32);
      fingerR.quadraticCurveTo(12, 18, 5, 0);
      fingerR.closePath();
      fillRimAndStroke(ctx, fingerR, -4, 0, 12, 32, '#7ef9ff', '#0abde3', '#192a56', outline, 2.8);
      ctx.restore();
    } else {
      // Broad petal-like Harlequin Shrimp paddle claw with rosette spot & scalloped edge
      const clawP = new Path2D();
      clawP.moveTo(-12, 0);
      clawP.bezierCurveTo(-44, 48, -38, 118, 12, 136);
      clawP.bezierCurveTo(48, 118, 44, 48, 12, 0);
      clawP.closePath();
      fillRimAndStroke(ctx, clawP, -40, 0, 44, 136, '#ffffff', '#f8bbd0', '#880e4f', outline, 3.4);
      ctx.fillStyle = '#6a1b9a';
      drawOvalSpot(ctx, 4, 72, 20, 16, 0.15);
      ctx.fillStyle = '#d81b60';
      drawOvalSpot(ctx, 4, 72, 16, 12, 0.15);
    }
    ctx.restore();
  };

  drawClaw(1, false);
  if (waveAmt < 0.45) {
    drawClaw(-1, false);
  }

  // 3. Cephalothorax Carapace Head, Rostrum Crest, Long Sweeping Antennae & Stalked Glossy Eyes
  ctx.save();
  ctx.translate(32 + pose.headX, -32 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  // Long sweeping feeler antennae (2 pairs for realism!)
  ctx.strokeStyle = isPrawn ? '#e67e22' : '#d81b60';
  ctx.lineWidth = 3.4;
  ctx.lineCap = 'round';
  for (const dir of [-1, 1]) {
    const sway = Math.sin(pose.waveRaysPhase * 0.9 + dir) * 8;
    ctx.beginPath();
    ctx.moveTo(dir * 26, -56);
    ctx.bezierCurveTo(dir * 98, -142 + sway, dir * 174, -114 + sway, dir * 204, -38 + sway);
    ctx.stroke();

    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(dir * 18, -52);
    ctx.bezierCurveTo(dir * 68, -110 - sway * 0.6, dir * 128, -92 - sway * 0.6, dir * 154, -48 - sway * 0.6);
    ctx.stroke();
    ctx.lineWidth = 3.4;
  }

  // Serrated dorsal rostrum crest on top of prawn/shrimp carapace
  const rostrumP = new Path2D();
  rostrumP.moveTo(-18, -68);
  rostrumP.lineTo(-4, -96);
  rostrumP.lineTo(6, -78);
  rostrumP.lineTo(18, -102);
  rostrumP.lineTo(28, -76);
  rostrumP.lineTo(42, -92);
  rostrumP.lineTo(44, -64);
  rostrumP.closePath();
  fillRimAndStroke(ctx, rostrumP, -18, -102, 44, -64, isPrawn ? '#f7b731' : '#f48fb1', cMid, cDark, outline, 2.8);

  const headP = new Path2D();
  headP.ellipse(8, 2, 92, 74, 0.05, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -70, -70, 60, 75, cLight, cMid, cDark, outline, 3.6);
  ctx.save();
  ctx.clip(headP);
  if (!isPrawn) {
    ctx.fillStyle = '#6a1b9a';
    drawOvalSpot(ctx, -42, -32, 24, 16, -0.2);
    ctx.fillStyle = '#d81b60';
    drawOvalSpot(ctx, -42, -32, 19, 12, -0.2);
  }
  drawSoftCheekBlushes(ctx, -44 + lookX * 0.8, 22 + lookY * 0.8, 66 + lookX * 0.8, 28 + lookY * 0.8, 24, 14, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  drawExpressiveAnimalMouth(ctx, 18 + lookX, 36 + lookY, 0.8, 0.06, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -32 + lookX * 0.85, -16 + lookY * 0.85, 27, 32, -0.08, pose, isPrawn ? IRIS_PALETTES.oceanBlue : IRIS_PALETTES.orchidPurple, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 62 + lookX * 0.85, -6 + lookY * 0.85, 24, 28, 0.12, pose, isPrawn ? IRIS_PALETTES.oceanBlue : IRIS_PALETTES.orchidPurple, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -32 + lookX * 0.85, -54 + lookY * 0.85, 62 + lookX * 0.85, -42 + lookY * 0.85, 34, pose, outline, 3.8);
  ctx.restore();

  if (waveAmt >= 0.45) {
    drawClaw(-1, true);
  }
}

/* ============================================================================
 * A21, A22, A26, A34: SCULPTED BONY FISH SPECIES (4 Distinct Silhouettes!)
 * Rebuilt per User Fixes #14, #15 & #17:
 * - Shaped hydrodynamic bodies (NOT single ovals), seamlessly embedded movable
 *   caudal tails ("嵌入"), fin ray striations, and ventral belly dots.
 * - A21 Asian Arowana: Verbose flowing dragon fins with golden ray striations,
 *   shiny metallic hexagonal scales with specular glints, smaller upturned mouth,
 *   and twin sensory barbels (嘴须子) attached directly to the tip of the mouth/chin!
 * - A22 Clown Featherback (Chitala ornata): Authentic silver knifefish with
 *   concave forehead, high-humped razor back, tiny feather dorsal tuft, continuous
 *   undulating ventral/anal ribbon fin merging into the tail tip, and 7 bold
 *   white-ringed black ocelli spots along the lower flank.
 * - A26 Giant Snakehead (Channa micropeltes): Elongated torpedo predator with
 *   flattened snake-like head, long rayed dorsal & anal fins, emerald-indigo
 *   chevron bars, and speckled white belly.
 * - A34 Clownfish: Sculpted reef anemonefish with double-lobed black-rimmed
 *   dorsal fin, rayed rounded paddle fins, and 3 black-edged white bars.
 * ========================================================================== */
function drawSculptedFishRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'arowana' | 'featherback' | 'snakehead' | 'clownfish',
): void {
  const cfg = {
    arowana: {
      outline: '#381805',
      cLight: '#fff099',
      cMid: '#f5982e',
      cDark: '#b84a0e',
      finCol: '#ff5722',
      iris: IRIS_PALETTES.crimsonRed,
      rx: 172,
      ry: 74,
    },
    featherback: {
      outline: '#1a2430',
      cLight: '#f4f8fc',
      cMid: '#9eb3c7',
      cDark: '#4f6478',
      finCol: '#7f96ab',
      iris: IRIS_PALETTES.goldenHazel,
      rx: 174,
      ry: 86,
    },
    snakehead: {
      outline: '#0d211e',
      cLight: '#6ee7b7',
      cMid: '#0d9488',
      cDark: '#115e59',
      finCol: '#4f46e5',
      iris: IRIS_PALETTES.amber,
      rx: 184,
      ry: 64,
    },
    clownfish: {
      outline: '#2b1004',
      cLight: '#ff9e44',
      cMid: '#ff6d00',
      cDark: '#c43c00',
      finCol: '#ff851b',
      iris: IRIS_PALETTES.amber,
      rx: 146,
      ry: 88,
    },
  }[species];

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  const tailY = Math.sin(pose.waveRaysPhase * 1.1) * 14 + pose.hindNearAngle * 24;

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Open-Rooted Dorsal & Anal Fins Drawn FIRST (deeply embedded inside the body contour so scales & body gradient flow seamlessly into them!)
  const drawFinRays = (clipP: Path2D, col: string, xStart: number, xEnd: number, yBase: number, yTip: number, step = 14) => {
    ctx.save();
    ctx.clip(clipP);
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.8;
    for (let fx = xStart; fx <= xEnd; fx += step) {
      ctx.beginPath();
      ctx.moveTo(fx, yBase);
      ctx.lineTo(fx - 12, yTip);
      ctx.stroke();
    }
    ctx.restore();
  };

  let dorsalOpenStroke: Path2D | null = null;
  let analOpenStroke: Path2D | null = null;

  if (species === 'featherback') {
    const featherDorsalFill = new Path2D();
    featherDorsalFill.moveTo(-42, -55);
    featherDorsalFill.bezierCurveTo(-54, -146, -12, -148, -2, -58);
    featherDorsalFill.closePath();
    dorsalOpenStroke = new Path2D();
    dorsalOpenStroke.moveTo(-40, -82);
    dorsalOpenStroke.bezierCurveTo(-54, -146, -12, -148, -4, -84);
    fillRimAndStroke(ctx, featherDorsalFill, -24, -60, -28, -148, cfg.cLight, cfg.finCol, cfg.cMid, cfg.outline, 3.2, dorsalOpenStroke);

    const knifeVentralFill = new Path2D();
    knifeVentralFill.moveTo(-168, 12);
    knifeVentralFill.bezierCurveTo(-128, 118, -12, 126, 56, 48);
    knifeVentralFill.closePath();
    analOpenStroke = new Path2D();
    analOpenStroke.moveTo(-166, 28);
    analOpenStroke.bezierCurveTo(-128, 118, -12, 126, 52, 66);
    fillRimAndStroke(ctx, knifeVentralFill, -60, 40, -60, 124, cfg.cMid, cfg.finCol, cfg.cDark, cfg.outline, 3.2, analOpenStroke);
    drawFinRays(knifeVentralFill, 'rgba(26, 36, 48, 0.35)', -152, 36, 44, 120, 14);
  } else if (species === 'snakehead') {
    const longDorsalFill = new Path2D();
    longDorsalFill.moveTo(-148, 6);
    longDorsalFill.bezierCurveTo(-112, -98, 28, -96, 80, -10);
    longDorsalFill.closePath();
    dorsalOpenStroke = new Path2D();
    dorsalOpenStroke.moveTo(-144, -16);
    dorsalOpenStroke.bezierCurveTo(-112, -98, 28, -96, 76, -34);
    fillRimAndStroke(ctx, longDorsalFill, -30, -20, -30, -98, cfg.cLight, cfg.finCol, '#818cf8', cfg.outline, 3.4, dorsalOpenStroke);
    drawFinRays(longDorsalFill, 'rgba(255,255,255,0.42)', -128, 60, -24, -92, 16);

    const longAnalFill = new Path2D();
    longAnalFill.moveTo(-144, 18);
    longAnalFill.bezierCurveTo(-104, 102, 4, 100, 42, 34);
    longAnalFill.closePath();
    analOpenStroke = new Path2D();
    analOpenStroke.moveTo(-140, 38);
    analOpenStroke.bezierCurveTo(-104, 102, 4, 100, 38, 56);
    fillRimAndStroke(ctx, longAnalFill, -50, 36, -50, 102, cfg.cMid, cfg.finCol, '#312e81', cfg.outline, 3.4, analOpenStroke);
  } else if (species === 'clownfish') {
    const reefDorsalFill = new Path2D();
    reefDorsalFill.moveTo(-108, -10);
    reefDorsalFill.bezierCurveTo(-84, -122, -28, -116, -12, -72);
    reefDorsalFill.bezierCurveTo(12, -120, 62, -112, 78, -14);
    reefDorsalFill.closePath();
    dorsalOpenStroke = new Path2D();
    dorsalOpenStroke.moveTo(-104, -38);
    dorsalOpenStroke.bezierCurveTo(-84, -122, -28, -116, -12, -72);
    dorsalOpenStroke.bezierCurveTo(12, -120, 62, -112, 74, -44);
    fillRimAndStroke(ctx, reefDorsalFill, -20, -30, -20, -120, cfg.cLight, cfg.finCol, cfg.cMid, cfg.outline, 4.8, dorsalOpenStroke);

    const reefAnalFill = new Path2D();
    reefAnalFill.moveTo(-90, 32);
    reefAnalFill.bezierCurveTo(-68, 114, -18, 112, -2, 42);
    reefAnalFill.closePath();
    analOpenStroke = new Path2D();
    analOpenStroke.moveTo(-86, 56);
    analOpenStroke.bezierCurveTo(-68, 114, -18, 112, -4, 68);
    fillRimAndStroke(ctx, reefAnalFill, -45, 50, -45, 114, cfg.cMid, cfg.finCol, cfg.cDark, cfg.outline, 4.8, analOpenStroke);
  } else {
    // Asian Arowana: Verbose, sweeping majestic dragon dorsal & anal fins deeply embedded into body
    const aroDorsalFill = new Path2D();
    aroDorsalFill.moveTo(-152, 16);
    aroDorsalFill.bezierCurveTo(-140, -136, -54, -132, -4, -18);
    aroDorsalFill.closePath();
    dorsalOpenStroke = new Path2D();
    dorsalOpenStroke.moveTo(-148, -6);
    dorsalOpenStroke.bezierCurveTo(-140, -136, -54, -132, -8, -42);
    fillRimAndStroke(ctx, aroDorsalFill, -78, -22, -78, -136, cfg.cLight, cfg.finCol, '#fff3a1', cfg.outline, 3.5, dorsalOpenStroke);
    drawFinRays(aroDorsalFill, '#fde047', -136, -22, -16, -124, 14);

    const aroAnalFill = new Path2D();
    aroAnalFill.moveTo(-152, 8);
    aroAnalFill.bezierCurveTo(-136, 144, -42, 140, 10, 32);
    aroAnalFill.closePath();
    analOpenStroke = new Path2D();
    analOpenStroke.moveTo(-148, 28);
    analOpenStroke.bezierCurveTo(-136, 144, -42, 140, 6, 62);
    fillRimAndStroke(ctx, aroAnalFill, -70, 42, -70, 144, cfg.cMid, cfg.finCol, '#9a1f06', cfg.outline, 3.5, analOpenStroke);
    drawFinRays(aroAnalFill, '#fde047', -136, -6, 36, 132, 14);
  }

  // 2. Unified Continuous Body + Swaying Caudal Tail Silhouette (zero peduncle seam or color jump!)
  const bodyP = new Path2D();
  if (species === 'featherback') {
    bodyP.moveTo(-158, -4);
    bodyP.bezierCurveTo(-122, -62, -56, -104, 12, -88);
    bodyP.bezierCurveTo(54, -78, 76, -38, 112, -22);
    bodyP.bezierCurveTo(148, -6, 162, 16, 144, 38);
    bodyP.bezierCurveTo(106, 78, -24, 88, -158, 38);
    bodyP.bezierCurveTo(-194, 46 + tailY * 0.7, -236, 38 + tailY, -242, 18 + tailY);
    bodyP.bezierCurveTo(-236, -2 + tailY, -194, -8 + tailY * 0.7, -158, -4);
    bodyP.closePath();
  } else if (species === 'arowana') {
    bodyP.moveTo(-142, -12);
    bodyP.bezierCurveTo(-88, -54, 48, -58, 134, -22);
    bodyP.bezierCurveTo(168, -6, 172, 24, 144, 48);
    bodyP.bezierCurveTo(88, 92, -64, 92, -142, 34);
    // Continuous broad fan-shaped dragon caudal tail flowing directly from muscular peduncle
    bodyP.bezierCurveTo(-176, 68 + tailY * 0.6, -238, 92 + tailY, -252, 42 + tailY);
    bodyP.bezierCurveTo(-266, 12 + tailY, -264, -22 + tailY, -248, -52 + tailY);
    bodyP.bezierCurveTo(-232, -86 + tailY, -174, -52 + tailY * 0.6, -142, -12);
    bodyP.closePath();
  } else if (species === 'snakehead') {
    bodyP.moveTo(-152, -10);
    bodyP.bezierCurveTo(-108, -48, 34, -52, 136, -24);
    bodyP.bezierCurveTo(178, -12, 184, 24, 146, 46);
    bodyP.bezierCurveTo(68, 78, -88, 78, -152, 34);
    bodyP.bezierCurveTo(-188, 64 + tailY * 0.6, -246, 82 + tailY, -258, 36 + tailY);
    bodyP.bezierCurveTo(-270, 8 + tailY, -268, -18 + tailY, -254, -46 + tailY);
    bodyP.bezierCurveTo(-238, -76 + tailY, -186, -46 + tailY * 0.6, -152, -10);
    bodyP.closePath();
  } else {
    bodyP.moveTo(-124, -12);
    bodyP.bezierCurveTo(-88, -78, 42, -82, 118, -24);
    bodyP.bezierCurveTo(148, 2, 144, 42, 112, 64);
    bodyP.bezierCurveTo(38, 98, -82, 92, -124, 34);
    bodyP.bezierCurveTo(-162, 66 + tailY * 0.6, -218, 56 + tailY, -220, 12 + tailY);
    bodyP.bezierCurveTo(-218, -34 + tailY, -162, -46 + tailY * 0.6, -124, -12);
    bodyP.closePath();
  }

  fillRimAndStroke(
    ctx,
    bodyP,
    168,
    -65,
    -255,
    85,
    cfg.cLight,
    cfg.cMid,
    cfg.finCol,
    cfg.outline,
    species === 'clownfish' ? 4.8 : 3.7,
  );

  ctx.save();
  ctx.clip(bodyP);
  // Caudal tail ray striations seamlessly inside the continuous tail fan
  ctx.strokeStyle = species === 'arowana' ? '#fde047' : 'rgba(255,255,255,0.48)';
  ctx.lineWidth = 1.8;
  for (const ry of [-42, -20, 0, 20, 42]) {
    ctx.beginPath();
    ctx.moveTo(-144, 10 + tailY * 0.25);
    ctx.lineTo(-238, ry + 10 + tailY);
    ctx.stroke();
  }

  if (species === 'clownfish') {
    for (const bx of [-98, -18, 54]) {
      const barP = new Path2D();
      barP.moveTo(bx - 18, -105);
      barP.quadraticCurveTo(bx + 8, 14, bx - 16, 125);
      barP.lineTo(bx + 18, 125);
      barP.quadraticCurveTo(bx + 36, 14, bx + 16, -105);
      barP.closePath();
      ctx.fillStyle = '#ffffff';
      ctx.fill(barP);
      ctx.lineWidth = 6.5;
      ctx.strokeStyle = '#1a0d06';
      ctx.stroke(barP);
    }
  } else if (species === 'arowana') {
    for (let r = -1; r <= 1; r++) {
      for (let c = -3; c <= 2; c++) {
        const sx = c * 32 - 12 + (r % 2) * 14;
        const sy = r * 24 + 12;
        ctx.fillStyle = r === -1 ? 'rgba(255, 245, 158, 0.55)' : 'rgba(245, 152, 46, 0.35)';
        drawOvalSpot(ctx, sx, sy, 14, 11, 0);
        ctx.strokeStyle = 'rgba(255, 250, 215, 0.88)';
        ctx.lineWidth = 2.6;
        ctx.beginPath();
        ctx.arc(sx, sy, 16, -0.95, 0.95);
        ctx.stroke();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        drawOvalSpot(ctx, sx + 4, sy - 4, 4.5, 2.2, -0.3);
      }
    }
    ctx.strokeStyle = '#b84a0e';
    ctx.lineWidth = 3.0;
    ctx.beginPath();
    ctx.arc(48, 12, 36, 0.35, 1.35);
    ctx.stroke();
  } else if (species === 'featherback') {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    drawOvalSpot(ctx, -18, -18, 96, 26, -0.08);
    for (const [ox, oy, r] of [
      [-136, 24, 9],
      [-108, 28, 10.5],
      [-78, 32, 12],
      [-46, 34, 12.5],
      [-14, 34, 11.5],
      [16, 32, 10],
      [44, 28, 8.5],
    ] as const) {
      ctx.fillStyle = '#ffffff';
      drawOvalSpot(ctx, ox, oy, r + 3.2, r + 3.2, 0);
      ctx.fillStyle = '#0f172a';
      drawOvalSpot(ctx, ox, oy, r, r, 0);
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      drawOvalSpot(ctx, ox - 2, oy - 2, r * 0.28, r * 0.28, 0);
    }
  } else if (species === 'snakehead') {
    ctx.fillStyle = '#ecfdf5';
    drawOvalSpot(ctx, 0, 56, 146, 28, 0);
    ctx.fillStyle = 'rgba(30, 27, 75, 0.72)';
    for (let sx = -132; sx <= 36; sx += 32) {
      drawOvalSpot(ctx, sx, 2, 14, 52, 0.28);
    }
    ctx.fillStyle = 'rgba(13, 148, 136, 0.55)';
    for (let bx = -110; bx <= 50; bx += 22) {
      drawOvalSpot(ctx, bx, 44 + (bx % 2) * 4, 3.5, 2.2, 0);
    }
  }

  drawSoftCheekBlushes(ctx, 32, 26, 116, 30, 24, 14, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = species === 'clownfish' ? 4.8 : 3.7;
  ctx.strokeStyle = cfg.outline;
  ctx.stroke(bodyP);
  if (dorsalOpenStroke) ctx.stroke(dorsalOpenStroke);
  if (analOpenStroke) ctx.stroke(analOpenStroke);

  // 4. Verbose Pectoral Fins (Both Far and Near Pectoral Fins so both hands/fins are visible!)
  const drawPectoralFin = (x: number, y: number, ang: number, scaleX = 1) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scaleX, 1);
    ctx.rotate(ang);
    const pecFin = new Path2D();
    const pecStroke = new Path2D();
    const len = species === 'arowana' ? -104 : -84;
    pecFin.moveTo(6, -10);
    pecFin.quadraticCurveTo(18, 0, 8, 12);
    pecFin.bezierCurveTo(2, 44, -52, 80, len + 16, 56);
    pecFin.bezierCurveTo(len, 8, -42, -32, 6, -10);
    pecFin.closePath();

    pecStroke.moveTo(4, -10);
    pecStroke.bezierCurveTo(-42, -32, len, 8, len + 16, 56);
    pecStroke.bezierCurveTo(-52, 80, 2, 44, 6, 12);
    fillRimAndStroke(
      ctx,
      pecFin,
      len,
      -28,
      16,
      68,
      cfg.cLight,
      cfg.finCol,
      cfg.cDark,
      cfg.outline,
      species === 'clownfish' ? 4.8 : 3.4,
      pecStroke,
    );
    ctx.save();
    ctx.clip(pecFin);
    ctx.strokeStyle = species === 'arowana' ? '#fde047' : 'rgba(255,255,255,0.48)';
    ctx.lineWidth = 1.6;
    for (const py of [12, 28, 44, 56]) {
      ctx.beginPath();
      ctx.moveTo(4, 2);
      ctx.lineTo(len + 12, py);
      ctx.stroke();
    }
    ctx.restore();
    ctx.restore();
  };

  drawPectoralFin(58, 46, -0.35 - pose.farFlipperAngle * 0.35, -0.78);
  drawPectoralFin(
    -8 + pose.nearFlipperShoulderX,
    34 + pose.nearFlipperShoulderY,
    pose.nearFlipperAngle * 0.45 + 0.22 - waveAmt * 0.55,
  );

  // 5. Eyes, Mouth & Asian Arowana Jaw-Tip Barbels (嘴须子 attached directly to mouth!)
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  const mouthX = (species === 'arowana' ? 112 : 84) + lookX;
  const mouthY = (species === 'arowana' ? 28 : 38) + lookY;
  const mouthScale = species === 'arowana' ? 0.58 : 0.82;

  drawExpressiveAnimalMouth(ctx, mouthX, mouthY, mouthScale, species === 'arowana' ? -0.12 : 0.06, pose, cfg.outline);

  if (species === 'arowana') {
    const barbelSway = Math.sin(pose.waveRaysPhase * 1.4) * 4;
    ctx.strokeStyle = '#ff3d00';
    ctx.lineWidth = 4.0;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(mouthX + 14, mouthY + 2);
    ctx.quadraticCurveTo(mouthX + 42, mouthY + 10 + barbelSway, mouthX + 58, mouthY + 26 + barbelSway);
    ctx.moveTo(mouthX + 8, mouthY + 6);
    ctx.quadraticCurveTo(mouthX + 32, mouthY + 18 + barbelSway, mouthX + 44, mouthY + 34 + barbelSway);
    ctx.stroke();
  }

  drawGlossyAnimalEye(
    ctx,
    'left',
    42 + lookX * 0.85,
    -12 + lookY * 0.85,
    species === 'featherback' ? 24 : 26,
    species === 'featherback' ? 28 : 31,
    -0.08,
    pose,
    cfg.iris,
    cfg.cLight,
    cfg.cMid,
    cfg.outline,
  );
  drawGlossyAnimalEye(
    ctx,
    'right',
    116 + lookX * 0.85,
    -4 + lookY * 0.85,
    species === 'featherback' ? 20 : 22,
    species === 'featherback' ? 24 : 26,
    0.12,
    pose,
    cfg.iris,
    cfg.cLight,
    cfg.cMid,
    cfg.outline,
  );
  drawExpressiveAnimalBrows(ctx, 42 + lookX * 0.85, -50 + lookY * 0.85, 116 + lookX * 0.85, -38 + lookY * 0.85, 34, pose, cfg.outline, 3.8);
  ctx.restore();
}

/* ============================================================================
 * A27, A31, A32: MARINE MAMMALS (3 Distinct Silhouettes & Head Structures!)
 * Upgraded per User Fix #17:
 * - Longer, shaped hydrodynamic bodies (NOT a single oval) with continuous
 *   muscular caudal peduncle and seamlessly embedded ("嵌入") movable tail flukes.
 * - Added fin striations, skin creases, and subtle ventral belly speckles.
 * - A27 Dugong: Plump cinnamon-taupe sea cow, no dorsal fin, notched sirenia fluke,
 *   bristled downturned disk-muzzle.
 * - A31 Indo-Pacific Humpback Dolphin: Pastel rose-pink dolphin with elongated
 *   fatty dorsal hump, speckled belly, and long slender rostrum beak.
 * - A32 False Killer Whale (+30% larger scale): Sleek obsidian-slate oceanic
 *   delphinid with overhanging melon head, S-bent elbow flippers & silver chest blaze.
 * ========================================================================== */
function drawMarineMammalRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'dugong' | 'pink_dolphin' | 'false_killer_whale',
): void {
  const cfg = {
    dugong: {
      outline: '#2b221e',
      cLight: '#ccb9ae',
      cMid: '#9e897d',
      cDark: '#6e5c52',
      belly: '#e6d8cf',
      iris: IRIS_PALETTES.warmBrown,
    },
    pink_dolphin: {
      outline: '#421828',
      cLight: '#ffc8d8',
      cMid: '#f48fb1',
      cDark: '#c2597d',
      belly: '#fff0f5',
      iris: IRIS_PALETTES.oceanBlue,
    },
    false_killer_whale: {
      outline: '#0b0f17',
      cLight: '#4b5563',
      cMid: '#272e38',
      cDark: '#11161d',
      belly: '#cbd5e1',
      iris: IRIS_PALETTES.amber,
    },
  }[species];

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  const flukeY = Math.sin(pose.waveRaysPhase * 0.95) * 14 + pose.hindNearAngle * 24;

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Unified Continuous Hydrodynamic Cetacean / Sirenia Body + Dorsal Fin + Swaying Horizontal Flukes!
  const bodyP = new Path2D();
  if (species === 'false_killer_whale') {
    bodyP.moveTo(-148, 22);
    bodyP.bezierCurveTo(-124, -18, -96, -34, -74, -44);
    // Continuous falcate dorsal fin integrated directly into the dorsal contour
    bodyP.quadraticCurveTo(-42, -154, -104, -138);
    bodyP.quadraticCurveTo(-72, -84, -14, -52);
    bodyP.bezierCurveTo(54, -76, 114, -56, 142, -22);
    bodyP.bezierCurveTo(176, 4, 158, 58, 102, 74);
    bodyP.bezierCurveTo(18, 98, -98, 86, -148, 48);
    // Continuous swaying tail flukes flowing from muscular caudal stock
    bodyP.bezierCurveTo(-188, 66 + flukeY * 0.6, -242, 92 + flukeY, -264, 58 + flukeY);
    bodyP.quadraticCurveTo(-234, 34 + flukeY, -268, 8 + flukeY);
    bodyP.bezierCurveTo(-248, -26 + flukeY, -188, 4 + flukeY * 0.6, -148, 22);
    bodyP.closePath();
  } else if (species === 'dugong') {
    bodyP.moveTo(-148, 24);
    bodyP.bezierCurveTo(-116, -66, 28, -78, 118, -24);
    bodyP.bezierCurveTo(154, 2, 148, 64, 96, 86);
    bodyP.bezierCurveTo(16, 114, -104, 96, -148, 52);
    bodyP.bezierCurveTo(-188, 72 + flukeY * 0.6, -244, 96 + flukeY, -264, 60 + flukeY);
    bodyP.quadraticCurveTo(-232, 36 + flukeY, -268, 10 + flukeY);
    bodyP.bezierCurveTo(-248, -24 + flukeY, -188, 6 + flukeY * 0.6, -148, 24);
    bodyP.closePath();
  } else {
    // Pink Dolphin with low broad triangular fatty dorsal ridge + continuous flukes
    bodyP.moveTo(-148, 22);
    bodyP.bezierCurveTo(-124, -12, -106, -24, -92, -32);
    bodyP.bezierCurveTo(-68, -96, -48, -118, -82, -108);
    bodyP.bezierCurveTo(-44, -88, -18, -62, 12, -48);
    bodyP.bezierCurveTo(64, -68, 104, -48, 128, -18);
    bodyP.bezierCurveTo(162, 8, 148, 56, 98, 74);
    bodyP.bezierCurveTo(18, 102, -102, 88, -148, 50);
    bodyP.bezierCurveTo(-188, 68 + flukeY * 0.6, -242, 92 + flukeY, -264, 58 + flukeY);
    bodyP.quadraticCurveTo(-234, 34 + flukeY, -268, 8 + flukeY);
    bodyP.bezierCurveTo(-248, -26 + flukeY, -188, 4 + flukeY * 0.6, -148, 22);
    bodyP.closePath();
  }
  fillRimAndStroke(ctx, bodyP, -180, -85, 155, 108, cfg.cLight, cfg.cMid, cfg.cDark, cfg.outline, 3.7);

  ctx.save();
  ctx.clip(bodyP);
  // Fluke striations inside continuous tail
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 1.6;
  for (const fy of [14, 34, 54]) {
    ctx.beginPath();
    ctx.moveTo(-152, 36 + flukeY * 0.3);
    ctx.lineTo(-248, fy + flukeY);
    ctx.stroke();
  }
  ctx.fillStyle = cfg.belly;
  if (species === 'false_killer_whale') {
    drawOvalSpot(ctx, 14, 72, 96, 32, -0.04);
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    for (const bx of [-42, -12, 18, 48]) {
      drawOvalSpot(ctx, bx, 64, 4, 2.5, 0);
    }
  } else {
    drawOvalSpot(ctx, 16, 74, 122, 48, -0.05);
    ctx.fillStyle = species === 'pink_dolphin' ? 'rgba(194, 89, 125, 0.35)' : 'rgba(110, 92, 82, 0.32)';
    for (const [dx, dy] of [
      [-64, 56],
      [-32, 64],
      [0, 62],
      [34, 66],
      [-48, 48],
    ]) {
      drawOvalSpot(ctx, dx, dy, 4.5, 3.0, -0.1);
    }
  }
  drawSoftCheekBlushes(ctx, 18, 26, 110, 32, 28, 16, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.7;
  ctx.strokeStyle = cfg.outline;
  ctx.stroke(bodyP);

  // 4. Sculpted Pectoral Flippers (Both Far and Near Flippers visible!)
  const drawFlipper = (x: number, y: number, ang: number, scaleX = 1) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scaleX, 1);
    ctx.rotate(ang);
    const flipFill = new Path2D();
    const flipStroke = new Path2D();
    if (species === 'false_killer_whale') {
      flipFill.moveTo(6, -10);
      flipFill.quadraticCurveTo(18, 0, 8, 12);
      flipFill.quadraticCurveTo(-72, 68, -116, 48);
      flipFill.quadraticCurveTo(-92, -14, -56, -18);
      flipFill.lineTo(6, -10);
      flipFill.closePath();

      flipStroke.moveTo(4, -10);
      flipStroke.lineTo(-56, -18);
      flipStroke.quadraticCurveTo(-92, -14, -116, 48);
      flipStroke.quadraticCurveTo(-72, 68, 6, 12);
    } else {
      flipFill.moveTo(6, -10);
      flipFill.quadraticCurveTo(18, 0, 8, 12);
      flipFill.bezierCurveTo(4, 48, -72, 86, -104, 64);
      flipFill.bezierCurveTo(-118, 12, -48, -28, 6, -10);
      flipFill.closePath();

      flipStroke.moveTo(4, -10);
      flipStroke.bezierCurveTo(-48, -28, -118, 12, -104, 64);
      flipStroke.bezierCurveTo(-72, 86, 4, 48, 6, 12);
    }
    fillRimAndStroke(ctx, flipFill, -114, -20, 16, 70, cfg.cLight, cfg.cMid, cfg.cDark, cfg.outline, 3.5, flipStroke);
    ctx.save();
    ctx.clip(flipFill);
    ctx.strokeStyle = 'rgba(255,255,255,0.32)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-88, 38);
    ctx.moveTo(0, 6);
    ctx.lineTo(-76, 52);
    ctx.stroke();
    ctx.restore();
    ctx.restore();
  };

  drawFlipper(48, 52, -0.35 - pose.farFlipperAngle * 0.35, -0.78);
  drawFlipper(
    -24 + pose.nearFlipperShoulderX,
    38 + pose.nearFlipperShoulderY,
    pose.nearFlipperAngle * 0.45 + 0.25 - waveAmt * 0.55,
  );

  // 5. Snout/Rostrum, Eyes & Mouth
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  if (species === 'dugong') {
    const snoutFill = new Path2D();
    snoutFill.moveTo(52 + lookX, 8 + lookY);
    snoutFill.bezierCurveTo(96 + lookX, -14 + lookY, 148 + lookX, 8 + lookY, 144 + lookX, 46 + lookY);
    snoutFill.bezierCurveTo(138 + lookX, 78 + lookY, 72 + lookX, 82 + lookY, 44 + lookX, 54 + lookY);
    snoutFill.closePath();
    const snoutStroke = new Path2D();
    snoutStroke.moveTo(64 + lookX, 4 + lookY);
    snoutStroke.bezierCurveTo(98 + lookX, -12 + lookY, 148 + lookX, 8 + lookY, 144 + lookX, 46 + lookY);
    snoutStroke.bezierCurveTo(138 + lookX, 78 + lookY, 76 + lookX, 80 + lookY, 54 + lookX, 56 + lookY);
    fillRimAndStroke(ctx, snoutFill, 44, -10, 146, 78, cfg.belly, cfg.cLight, cfg.cMid, cfg.outline, 3.5, snoutStroke);
    ctx.strokeStyle = '#5c4b42';
    ctx.lineWidth = 2.2;
    for (const [wx, wy] of [
      [74, 46],
      [90, 52],
      [108, 48],
      [124, 42],
    ]) {
      ctx.beginPath();
      ctx.moveTo(wx + lookX, wy + lookY);
      ctx.lineTo(wx + lookX - 4, wy + lookY + 9);
      ctx.stroke();
    }
  } else if (species === 'pink_dolphin') {
    const beakFill = new Path2D();
    beakFill.moveTo(86 + lookX, 2 + lookY);
    beakFill.bezierCurveTo(138 + lookX, 2 + lookY, 182 + lookX, 14 + lookY, 178 + lookX, 28 + lookY);
    beakFill.bezierCurveTo(172 + lookX, 42 + lookY, 128 + lookX, 40 + lookY, 82 + lookX, 34 + lookY);
    beakFill.closePath();
    const beakStroke = new Path2D();
    beakStroke.moveTo(96 + lookX, 2 + lookY);
    beakStroke.bezierCurveTo(138 + lookX, 2 + lookY, 182 + lookX, 14 + lookY, 178 + lookX, 28 + lookY);
    beakStroke.bezierCurveTo(172 + lookX, 42 + lookY, 128 + lookX, 40 + lookY, 92 + lookX, 34 + lookY);
    fillRimAndStroke(ctx, beakFill, 82, 0, 180, 42, cfg.cLight, cfg.cMid, cfg.cDark, cfg.outline, 3.4, beakStroke);
  }

  drawExpressiveAnimalMouth(ctx, 72 + lookX, 46 + lookY, 0.86, 0.08, pose, cfg.outline);
  drawGlossyAnimalEye(ctx, 'left', 22 + lookX * 0.85, -12 + lookY * 0.85, 27, 32, -0.08, pose, cfg.iris, cfg.cLight, cfg.cMid, cfg.outline);
  drawGlossyAnimalEye(ctx, 'right', 106 + lookX * 0.85, -2 + lookY * 0.85, 23, 28, 0.12, pose, cfg.iris, cfg.cLight, cfg.cMid, cfg.outline);
  drawExpressiveAnimalBrows(ctx, 22 + lookX * 0.85, -54 + lookY * 0.85, 106 + lookX * 0.85, -40 + lookY * 0.85, 36, pose, cfg.outline, 4.0);
  ctx.restore();
}

/* ============================================================================
 * A30 & A33: SHARK SPECIES (Whale Shark vs Blacktip Reef Shark)
 * Upgraded per User Fix #17 & Latest Screenshot Review:
 * - 100% Continuous caudal tail & open-base dorsal/pectoral fins (no body outline
 *   cutting across dorsal fin base or caudal peduncle!).
 * - A30 Whale Shark: Eyes placed near the front of the wide flat head (`x = 64`
 *   and `x = 134`), with the white checkerboard dermal grid & snow-white
 *   constellation polka dots running across the top crown and posterior back
 *   WITHOUT overlapping the eyes!
 * ========================================================================== */
function drawSharkRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'whale_shark' | 'blacktip',
): void {
  const isWhale = species === 'whale_shark';
  const outline = isWhale ? '#0c1e33' : '#1c242b';
  const cLight = isWhale ? '#38bdf8' : '#a8b8c4';
  const cMid = isWhale ? '#0284c7' : '#64748b';
  const cDark = isWhale ? '#0c4a6e' : '#334155';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  const tailY = Math.sin(pose.waveRaysPhase * 1.0) * 15 + pose.hindNearAngle * 26;

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Single Continuous Hydrodynamic Shark Silhouette (Body + Primary Dorsal Fin + Second Dorsal Fin + Swaying Heterocercal Caudal Tail!)
  // Zero peduncle seam, zero dorsal base cut line, and zero gradient jump!
  const bodyP = new Path2D();
  if (isWhale) {
    bodyP.moveTo(-152, -2);
    // Second posterior dorsal fin integrated along upper caudal peduncle
    bodyP.quadraticCurveTo(-136, -52, -116, -22);
    bodyP.bezierCurveTo(-104, -30, -96, -36, -86, -42);
    // Primary rounded whale-shark dorsal fin integrated directly into dorsal back
    bodyP.bezierCurveTo(-72, -134, -22, -130, -8, -54);
    // Broad flat anterior crown & snout
    bodyP.bezierCurveTo(54, -68, 114, -52, 148, -26);
    bodyP.bezierCurveTo(178, -6, 176, 42, 134, 68);
    // Smooth ventral belly tapering to wide muscular caudal peduncle
    bodyP.bezierCurveTo(48, 102, -88, 86, -152, 36);
    // Lower lobe & upper lobe of swaying heterocercal whale-shark caudal tail
    bodyP.bezierCurveTo(-188, 66 + tailY * 0.6, -238, 96 + tailY, -256, 56 + tailY);
    bodyP.bezierCurveTo(-244, 28 + tailY, -236, 14 + tailY, -248, -4 + tailY);
    bodyP.bezierCurveTo(-268, -46 + tailY, -242, -92 + tailY, -198, -52 + tailY * 0.7);
    bodyP.bezierCurveTo(-176, -32 + tailY * 0.4, -162, -12, -152, -2);
    bodyP.closePath();
  } else {
    bodyP.moveTo(-152, 0);
    bodyP.quadraticCurveTo(-136, -48, -116, -18);
    bodyP.bezierCurveTo(-100, -28, -84, -36, -68, -42);
    // Falcate blacktip primary dorsal fin integrated directly into dorsal back
    bodyP.quadraticCurveTo(-36, -158, -104, -142);
    bodyP.quadraticCurveTo(-68, -82, -6, -48);
    bodyP.bezierCurveTo(58, -56, 118, -32, 164, 4);
    bodyP.bezierCurveTo(124, 78, -64, 88, -152, 34);
    bodyP.bezierCurveTo(-188, 64 + tailY * 0.6, -236, 92 + tailY, -254, 52 + tailY);
    bodyP.bezierCurveTo(-242, 24 + tailY, -234, 12 + tailY, -246, -6 + tailY);
    bodyP.bezierCurveTo(-266, -48 + tailY, -240, -90 + tailY, -196, -50 + tailY * 0.7);
    bodyP.bezierCurveTo(-174, -30 + tailY * 0.4, -162, -10, -152, 0);
    bodyP.closePath();
  }
  fillRimAndStroke(ctx, bodyP, -220, -110, 166, 98, cLight, cMid, cDark, outline, 3.7);

  ctx.save();
  ctx.clip(bodyP);
  // Caudal fin ray striations inside continuous tail
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 1.6;
  for (const ty of [-46, -18, 22, 48]) {
    ctx.beginPath();
    ctx.moveTo(-154, 16 + tailY * 0.25);
    ctx.lineTo(-238, ty + tailY);
    ctx.stroke();
  }

  // Crisp snow-white countershaded underbelly with subtle dermal dots
  ctx.fillStyle = '#f8fafc';
  drawOvalSpot(ctx, 18, 68, 144, 44, -0.04);
  ctx.fillStyle = isWhale ? 'rgba(2, 132, 199, 0.28)' : 'rgba(100, 116, 139, 0.28)';
  for (let bx = -84; bx <= 64; bx += 26) {
    drawOvalSpot(ctx, bx, 60 + (bx % 2) * 4, 3.5, 2.2, 0);
  }

  if (isWhale) {
    // Whale shark checkerboard dermal keels + white constellation polka dots across the TOP and posterior back
    // (strictly above/behind the front-placed eyes at x=64, y=4 and x=134, y=8 so pattern NEVER overlaps eyes!)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.42)';
    ctx.lineWidth = 2.2;
    for (let gx = -134; gx <= 106; gx += 30) {
      const yBottom = gx <= 18 ? 22 : -34;
      ctx.beginPath();
      ctx.moveTo(gx, -78);
      ctx.lineTo(gx - 6, yBottom);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(-148, -22);
    ctx.quadraticCurveTo(-20, -48, 116, -38);
    ctx.moveTo(-148, -2);
    ctx.lineTo(18, -14);
    ctx.moveTo(-144, 16);
    ctx.lineTo(14, 10);
    ctx.stroke();

    // Snow-white constellation polka dots across top crown, dorsal fin, caudal tail & posterior back (never overlapping eyes!)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
    for (let sx = -138; sx <= 110; sx += 24) {
      for (let sy = -54; sy <= 14; sy += 18) {
        const px = sx + (Math.abs(sy) % 4) * 3;
        const py = sy;
        if (px > 22 && py > -34) continue;
        drawOvalSpot(ctx, px, py, 4.8, 4.8, 0);
      }
    }
    for (const [dx, dy] of [
      [-56, -96],
      [-40, -80],
      [-64, -72],
      [-212, -32 + tailY],
      [-228, -48 + tailY],
      [-196, -14 + tailY],
      [-216, 36 + tailY],
    ]) {
      drawOvalSpot(ctx, dx, dy, 4.5, 4.5, 0);
    }
  } else {
    // Blacktip Reef Shark signature white lateral Z-stripe + black fin tips
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(-104, 24);
    ctx.lineTo(18, 14);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-110, -124, 78, 16);
    ctx.fillStyle = '#090d14';
    ctx.fillRect(-110, -160, 78, 38);
    ctx.fillRect(-270, -98 + tailY, 48, 175);
  }

  // 5 Shark Gill Slits behind head (well behind the front-placed eyes)
  ctx.strokeStyle = outline;
  ctx.lineWidth = 2.6;
  const gillStartX = isWhale ? -22 : -12;
  for (let g = 0; g < 5; g++) {
    const gx = gillStartX + g * 7;
    ctx.beginPath();
    ctx.moveTo(gx, -2);
    ctx.quadraticCurveTo(gx - 3, 14, gx, 26);
    ctx.stroke();
  }

  drawSoftCheekBlushes(ctx, isWhale ? 56 : 24, 28, isWhale ? 136 : 114, 34, 24, 14, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(bodyP);

  // 4. Sweeping Pectoral Fins (Both Far and Near Pectoral Fins visible!)
  const drawSharkPectoral = (x: number, y: number, ang: number, scaleX = 1) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scaleX, 1);
    ctx.rotate(ang);
    const pecP = new Path2D();
    const pecStroke = new Path2D();
    pecP.moveTo(6, -10);
    pecP.quadraticCurveTo(18, 0, 8, 12);
    pecP.bezierCurveTo(4, 48, -78, 86, -116, 68);
    pecP.bezierCurveTo(-132, 14, -52, -32, 6, -10);
    pecP.closePath();

    pecStroke.moveTo(4, -10);
    pecStroke.bezierCurveTo(-52, -32, -132, 14, -116, 68);
    pecStroke.bezierCurveTo(-78, 86, 4, 48, 6, 12);
    fillRimAndStroke(ctx, pecP, -124, -25, 16, 75, cLight, cMid, cDark, outline, 3.5, pecStroke);
    ctx.save();
    ctx.clip(pecP);
    if (!isWhale) {
      ctx.fillStyle = '#090d14';
      drawOvalSpot(ctx, -106, 54, 28, 28, 0);
    } else {
      ctx.fillStyle = '#ffffff';
      for (const [px, py] of [
        [-42, 16],
        [-68, 28],
        [-88, 44],
      ]) {
        drawOvalSpot(ctx, px, py, 4.5, 4.5, 0);
      }
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-96, 42);
    ctx.moveTo(0, 6);
    ctx.lineTo(-82, 58);
    ctx.stroke();
    ctx.restore();
    ctx.restore();
  };

  drawSharkPectoral(52, 52, -0.35 - pose.farFlipperAngle * 0.35, -0.78);
  drawSharkPectoral(
    -26 + pose.nearFlipperShoulderX,
    38 + pose.nearFlipperShoulderY,
    pose.nearFlipperAngle * 0.45 + 0.22 - waveAmt * 0.55,
  );

  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  const leftEyeX = (isWhale ? 64 : 26) + lookX * 0.85;
  const leftEyeY = (isWhale ? 4 : -10) + lookY * 0.85;
  const rightEyeX = (isWhale ? 134 : 112) + lookX * 0.85;
  const rightEyeY = (isWhale ? 8 : -2) + lookY * 0.85;
  const mouthX = (isWhale ? 98 : 72) + lookX;
  const mouthY = (isWhale ? 46 : 44) + lookY;

  drawExpressiveAnimalMouth(ctx, mouthX, mouthY, isWhale ? 1.04 : 0.84, 0.08, pose, outline);
  drawGlossyAnimalEye(
    ctx,
    'left',
    leftEyeX,
    leftEyeY,
    isWhale ? 24 : 26,
    isWhale ? 28 : 31,
    -0.06,
    pose,
    isWhale ? IRIS_PALETTES.oceanBlue : IRIS_PALETTES.goldenHazel,
    cLight,
    cMid,
    outline,
  );
  drawGlossyAnimalEye(
    ctx,
    'right',
    rightEyeX,
    rightEyeY,
    isWhale ? 20 : 22,
    isWhale ? 24 : 27,
    0.1,
    pose,
    isWhale ? IRIS_PALETTES.oceanBlue : IRIS_PALETTES.goldenHazel,
    cLight,
    cMid,
    outline,
  );
  drawExpressiveAnimalBrows(
    ctx,
    leftEyeX,
    leftEyeY - 36,
    rightEyeX,
    rightEyeY - 32,
    isWhale ? 32 : 36,
    pose,
    outline,
    4.0,
  );
  ctx.restore();
}

/* ============================================================================
 * A35: GIANT CLAM (Tridacna gigas)
 * Matches 35_giant_clam.png: Deeply fluted cream-amber upper & lower shell valves
 * with radial rib striations, iridescent turquoise-and-cobalt wavy mantle with
 * bio-luminescent ocelli spots & expressive eyes peeking inside.
 * ========================================================================== */
function drawGiantClamRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#261e14';
  const shellLight = '#fff7e0';
  const shellMid = '#e6ce9c';
  const shellDark = '#b8985d';

  // Lower Fluted Shell Valve with radial rib ridges
  const lowerShell = new Path2D();
  lowerShell.moveTo(-162, 22);
  lowerShell.bezierCurveTo(-152, 132, 152, 132, 162, 22);
  lowerShell.closePath();
  fillRimAndStroke(ctx, lowerShell, -155, 22, 155, 130, shellLight, shellMid, shellDark, outline, 3.7);
  ctx.save();
  ctx.clip(lowerShell);
  ctx.strokeStyle = 'rgba(138, 104, 48, 0.35)';
  ctx.lineWidth = 2.4;
  for (const rx of [-96, -48, 0, 48, 96]) {
    ctx.beginPath();
    ctx.moveTo(rx * 0.4, 118);
    ctx.lineTo(rx, 24);
    ctx.stroke();
  }
  ctx.restore();

  // Iridescent Turquoise & Royal-Blue Wavy Mantle with Glowing Eyes
  const mantle = new Path2D();
  mantle.ellipse(0, 18, 142, 66, 0, 0, Math.PI * 2);
  fillRimAndStroke(ctx, mantle, -140, -48, 140, 84, '#48dbfb', '#0abde3', '#192a56', '#0c2461', 3.6);
  ctx.save();
  ctx.clip(mantle);
  ctx.fillStyle = '#7ef9ff';
  for (const mx of [-104, -76, 76, 104]) {
    drawOvalSpot(ctx, mx, 18, 7, 5, 0);
  }
  ctx.restore();

  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  drawSoftCheekBlushes(ctx, -64 + lookX * 0.8, 32 + lookY * 0.8, 64 + lookX * 0.8, 32 + lookY * 0.8, 26, 15, pose.blushAlpha);
  drawExpressiveAnimalMouth(ctx, 0 + lookX, 42 + lookY, 0.84, 0.04, pose, '#0c2461');
  drawGlossyAnimalEye(ctx, 'left', -44 + lookX * 0.85, 6 + lookY * 0.85, 28, 33, -0.06, pose, IRIS_PALETTES.emerald, '#48dbfb', '#0abde3', '#0c2461');
  drawGlossyAnimalEye(ctx, 'right', 44 + lookX * 0.85, 6 + lookY * 0.85, 28, 33, 0.06, pose, IRIS_PALETTES.emerald, '#48dbfb', '#0abde3', '#0c2461');

  // Hinged Upper Fluted Shell Valve that opens/waves with pose
  ctx.save();
  ctx.translate(0, -14);
  ctx.rotate(pose.headRot * 0.5 - Math.abs(Math.sin(pose.waveRaysPhase * 0.6)) * 0.08);
  const upperShell = new Path2D();
  upperShell.moveTo(-162, 0);
  upperShell.bezierCurveTo(-156, -134, -78, -108, -56, -136);
  upperShell.bezierCurveTo(-24, -108, 24, -108, 56, -136);
  upperShell.bezierCurveTo(78, -108, 156, -134, 162, 0);
  upperShell.closePath();
  fillRimAndStroke(ctx, upperShell, -155, -134, 155, 0, shellLight, shellMid, shellDark, outline, 3.7);
  ctx.save();
  ctx.clip(upperShell);
  ctx.strokeStyle = 'rgba(138, 104, 48, 0.35)';
  ctx.lineWidth = 2.4;
  for (const rx of [-96, -48, 0, 48, 96]) {
    ctx.beginPath();
    ctx.moveTo(rx * 0.35, -8);
    ctx.lineTo(rx, -124);
    ctx.stroke();
  }
  ctx.restore();
  ctx.restore();
}

/* ============================================================================
 * A36: BLUESPOTTED FANTAIL RAY (Taeniura lymma)
 * Upgraded per User Fix #17:
 * - Shaped undulating pectoral wing disc (not a simple oval), seamlessly embedded
 *   ("嵌入") movable fantail ribbon tail with electric-blue side stripes & terminal
 *   tail fold, fin ray striations, and dark-rimmed electric-blue ocelli spots.
 * ========================================================================== */
function drawBluespottedRayRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#261e0a';
  const cLight = '#f2ce5f';
  const cMid = '#c79928';
  const cDark = '#8f6810';
  const tailSway = Math.sin(pose.waveRaysPhase * 0.95) * 0.14 + pose.hindNearAngle * 0.65;

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Seamlessly Continuous Fantail Ribbon Tail (drawn before open-root disc)
  ctx.save();
  ctx.translate(-162, 18);
  ctx.rotate(tailSway);
  const tailFill = new Path2D();
  tailFill.moveTo(24, -10);
  tailFill.bezierCurveTo(-56, 4, -142, 42, -186, 86);
  tailFill.bezierCurveTo(-198, 98, -182, 118, -158, 108);
  tailFill.bezierCurveTo(-108, 84, -38, 42, 24, 12);
  tailFill.closePath();

  const tailStroke = new Path2D();
  tailStroke.moveTo(2, -9);
  tailStroke.bezierCurveTo(-56, 4, -142, 42, -186, 86);
  tailStroke.bezierCurveTo(-198, 98, -182, 118, -158, 108);
  tailStroke.bezierCurveTo(-108, 84, -38, 42, 2, 10);
  fillRimAndStroke(ctx, tailFill, -195, -12, 24, 114, cLight, cMid, cDark, outline, 3.5, tailStroke);

  ctx.save();
  ctx.clip(tailFill);
  ctx.strokeStyle = '#00b0ff';
  ctx.lineWidth = 4.2;
  ctx.beginPath();
  ctx.moveTo(8, -4);
  ctx.bezierCurveTo(-54, 12, -128, 48, -176, 92);
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  drawOvalSpot(ctx, -176, 98, 16, 10, -0.5);
  ctx.restore();
  ctx.restore();

  // 2. Shaped Undulating Pectoral Wing Disc with Open Posterior Root Stroke!
  const disc = new Path2D();
  disc.moveTo(-164, 8);
  disc.bezierCurveTo(-136, -92, 24, -102, 146, -24);
  disc.bezierCurveTo(182, 0, 178, 38, 138, 64);
  disc.bezierCurveTo(44, 118, -118, 108, -164, 28);
  disc.closePath();

  const discStroke = new Path2D();
  discStroke.moveTo(-162, 8);
  discStroke.bezierCurveTo(-136, -92, 24, -102, 146, -24);
  discStroke.bezierCurveTo(182, 0, 178, 38, 138, 64);
  discStroke.bezierCurveTo(44, 118, -118, 108, -162, 28);
  fillRimAndStroke(ctx, disc, -165, -96, 175, 112, cLight, cMid, cDark, outline, 3.7, discStroke);

  ctx.save();
  ctx.clip(disc);
  ctx.fillStyle = '#fff8dc';
  drawOvalSpot(ctx, 18, 82, 128, 34, -0.04);
  ctx.strokeStyle = 'rgba(143, 104, 16, 0.25)';
  ctx.lineWidth = 1.6;
  for (let rx = -110; rx <= 60; rx += 34) {
    ctx.beginPath();
    ctx.moveTo(rx, -10);
    ctx.lineTo(rx - 22, -88);
    ctx.stroke();
  }

  for (const [bx, by, br] of [
    [-116, -16, 12],
    [-76, -44, 10.5],
    [-88, 22, 13],
    [-44, 46, 11],
    [-18, -58, 10.5],
    [28, -54, 9.5],
    [98, 36, 11],
    [-132, 20, 9.5],
  ] as const) {
    ctx.fillStyle = '#0c2461';
    drawOvalSpot(ctx, bx, by, br + 2.2, (br + 2.2) * 0.78, 0.15);
    ctx.fillStyle = '#00b0ff';
    drawOvalSpot(ctx, bx, by, br, br * 0.78, 0.15);
  }
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  drawSoftCheekBlushes(ctx, -28 + lookX * 0.8, 32 + lookY * 0.8, 84 + lookX * 0.8, 36 + lookY * 0.8, 26, 15, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(discStroke);

  const lookX2 = pose.headLookX * 14;
  const lookY2 = pose.headLookY * 10;
  drawExpressiveAnimalMouth(ctx, 32 + lookX2, 46 + lookY2, 0.85, 0.06, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -18 + lookX2 * 0.85, -8 + lookY2 * 0.85, 28, 33, -0.08, pose, IRIS_PALETTES.oceanBlue, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 78 + lookX2 * 0.85, -2 + lookY2 * 0.85, 24, 29, 0.1, pose, IRIS_PALETTES.oceanBlue, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -18 + lookX2 * 0.85, -50 + lookY2 * 0.85, 78 + lookX2 * 0.85, -40 + lookY2 * 0.85, 36, pose, outline, 4.0);
  ctx.restore();
}

/* ============================================================================
 * A37 & A39: CEPHALOPODS (Coconut Octopus & Pharaoh Cuttlefish)
 * Rebuilt per User Fix #19:
 * - Tentacles/arms (触手) radiate and curl in DIFFERENT directions (left-up,
 *   down-left, splaying outward left & right, curling right-up), NOT all pointing
 *   in the same direction!
 * - Tentacle roots are seamlessly embedded ("嵌入") into the mantle skirt.
 * ========================================================================== */
function drawCephalopodRig(
  ctx: CanvasRenderingContext2D,
  pose: TurtlePose,
  species: 'octopus' | 'cuttlefish',
): void {
  const isOcto = species === 'octopus';
  const outline = isOcto ? '#2b1018' : '#26142e';
  const cLight = isOcto ? '#ff9478' : '#ffd166';
  const cMid = isOcto ? '#e0533c' : '#d97724';
  const cDark = isOcto ? '#992518' : '#7c2d12';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Distinct multi-directional tentacle configurations:
  // curlDir = -1 curls outward to the LEFT; curlDir = +1 curls outward to the RIGHT!
  const TENTACLE_SPECS = [
    { baseX: -94, baseY: 44, baseAngle: 0.72, curlDir: -1 as const, lenScale: 1.05 }, // Far-left sweeps out & up-left
    { baseX: -58, baseY: 54, baseAngle: 0.34, curlDir: -1 as const, lenScale: 0.98 }, // Mid-left curls down-left
    { baseX: -20, baseY: 60, baseAngle: 0.08, curlDir: -1 as const, lenScale: 0.92 }, // Inner-left curls gently left
    { baseX: 22, baseY: 60, baseAngle: -0.1, curlDir: 1 as const, lenScale: 0.92 },   // Inner-right curls gently right
    { baseX: 60, baseY: 54, baseAngle: -0.38, curlDir: 1 as const, lenScale: 0.98 },  // Mid-right curls down-right
    { baseX: 96, baseY: 44, baseAngle: -0.76, curlDir: 1 as const, lenScale: 1.06 },  // Far-right sweeps out & up-right
  ];

  const drawTentacle = (i: number, isForegroundWave: boolean) => {
    const spec = TENTACLE_SPECS[i];
    ctx.save();
    ctx.translate(
      spec.baseX + (i === 0 ? pose.nearFlipperShoulderX : 0),
      spec.baseY + (i === 0 ? pose.nearFlipperShoulderY : 0),
    );
    const dynamicSway = Math.sin(pose.waveRaysPhase * 1.1 + i * 1.15) * 0.14 * spec.curlDir;
    ctx.rotate(isForegroundWave ? 1.85 + pose.nearFlipperAngle * 0.75 : spec.baseAngle + dynamicSway);
    // Flip X by curlDir so left arms curl left and right arms curl right!
    ctx.scale(spec.curlDir * spec.lenScale, spec.lenScale);

    const armFill = new Path2D();
    armFill.moveTo(-16, -8);
    armFill.bezierCurveTo(-28, 48, -14, 108, 24, 120);
    armFill.bezierCurveTo(48, 126, 52, 92, 28, 84);
    armFill.bezierCurveTo(8, 76, 8, 36, 16, -8);
    armFill.closePath();

    // Open root stroke so the tentacle merges seamlessly into the head/mantle base
    const armStroke = new Path2D();
    armStroke.moveTo(-16, 4);
    armStroke.bezierCurveTo(-28, 48, -14, 108, 24, 120);
    armStroke.bezierCurveTo(48, 126, 52, 92, 28, 84);
    armStroke.bezierCurveTo(8, 76, 8, 36, 16, 4);

    fillRimAndStroke(ctx, armFill, -28, 0, 48, 124, cLight, cMid, cDark, outline, 3.4, armStroke);

    // Glowing suction cups along outer underside of each tentacle
    ctx.fillStyle = isOcto ? '#e0f7fa' : '#f3e8ff';
    for (const [sx, sy] of [
      [-12, 32],
      [-10, 56],
      [-2, 80],
      [14, 98],
    ] as const) {
      drawOvalSpot(ctx, sx, sy, 5.8, 4.2, 0.2);
    }
    ctx.restore();
  };

  // Bulbous Mantle Dome Head drawn first at top, with tentacles seamlessly emerging below
  ctx.save();
  ctx.translate(8 + pose.headX, -28 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  if (!isOcto) {
    // Undulating bio-luminescent violet lateral skirt fin of Pharaoh Cuttlefish with fin rays
    const skirtFin = new Path2D();
    skirtFin.ellipse(0, -28, 152, 90, 0, 0, Math.PI * 2);
    fillRimAndStroke(ctx, skirtFin, -152, -118, 152, 62, '#c084fc', '#9333ea', '#581c87', outline, 3.4);
    ctx.save();
    ctx.clip(skirtFin);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1.6;
    for (let sy = -90; sy <= 30; sy += 24) {
      ctx.beginPath();
      ctx.moveTo(-148, sy);
      ctx.lineTo(148, sy);
      ctx.stroke();
    }
    ctx.restore();
  }

  const mantleP = new Path2D();
  mantleP.moveTo(0, -132);
  mantleP.bezierCurveTo(96, -130, 132, -48, 118, 38);
  mantleP.bezierCurveTo(106, 88, -106, 88, -118, 38);
  mantleP.bezierCurveTo(-132, -48, -96, -130, 0, -132);
  mantleP.closePath();
  fillRimAndStroke(ctx, mantleP, -90, -130, 90, 85, cLight, cMid, cDark, outline, 3.7);

  ctx.save();
  ctx.clip(mantleP);
  if (!isOcto) {
    // Cuttlefish bio-luminescent zebra mantle stripes
    ctx.fillStyle = 'rgba(255, 245, 200, 0.68)';
    for (let sy = -98; sy <= -22; sy += 22) {
      drawOvalSpot(ctx, 0, sy, 78, 7.5, 0);
    }
  } else {
    // Coconut Octopus mottled dermal bio-luminescent spots & longitudinal vein lines
    ctx.fillStyle = 'rgba(255, 225, 200, 0.48)';
    drawOvalSpot(ctx, -48, -72, 16, 12, -0.3);
    drawOvalSpot(ctx, 54, -64, 14, 10, 0.3);
    drawOvalSpot(ctx, -6, -94, 12, 9, 0);
  }
  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 32 + lookY * 0.8, 68 + lookX * 0.8, 36 + lookY * 0.8, 28, 16, pose.blushAlpha);
  ctx.restore();

  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(mantleP);
  ctx.restore();

  // Draw multi-directional tentacles seamlessly emerging from the lower mantle skirt
  for (let i = 0; i < TENTACLE_SPECS.length; i++) {
    if (i === 0 && waveAmt >= 0.45) continue;
    drawTentacle(i, false);
  }

  // Re-enter head transform to draw eyes, brows & mouth on top of tentacle bases
  ctx.save();
  ctx.translate(8 + pose.headX, -28 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  drawExpressiveAnimalMouth(ctx, 8 + lookX, 52 + lookY, 0.85, 0.06, pose, outline);
  drawGlossyAnimalEye(
    ctx,
    'left',
    -42 + lookX * 0.85,
    2 + lookY * 0.85,
    31,
    36,
    -0.08,
    pose,
    isOcto ? IRIS_PALETTES.goldenHazel : IRIS_PALETTES.emerald,
    cLight,
    cMid,
    outline,
  );
  drawGlossyAnimalEye(
    ctx,
    'right',
    56 + lookX * 0.85,
    6 + lookY * 0.85,
    27,
    32,
    0.1,
    pose,
    isOcto ? IRIS_PALETTES.goldenHazel : IRIS_PALETTES.emerald,
    cLight,
    cMid,
    outline,
  );
  drawExpressiveAnimalBrows(ctx, -42 + lookX * 0.85, -42 + lookY * 0.85, 56 + lookX * 0.85, -36 + lookY * 0.85, 38, pose, outline, 4.0);
  ctx.restore();

  // Foreground Waving Tentacle
  if (waveAmt >= 0.45) {
    drawTentacle(0, true);
  }
}

/* ============================================================================
 * A40: HORNED SEA STAR / CHOCOLATE CHIP SEA STAR (Protoreaster nodosus)
 * Upgraded per User Fix #17:
 * - Sculpted 5-rayed starfish with radial skeletal ridge lines, chocolate-brown
 *   conical tubercles/nodes with glossy highlights, and marginal dermal papulae dots.
 * ========================================================================== */
function drawHornedSeaStarRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#2e1308';
  const cLight = '#ffb078';
  const cMid = '#eb6b38';
  const cDark = '#a83612';
  const hornCol = '#3d1c0a';

  ctx.save();
  ctx.translate(0 + pose.shellOffsetX, 12 + pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);
  const starP = new Path2D();
  const outerR = 184;
  const innerR = 78;
  for (let i = 0; i < 10; i++) {
    const isOuter = i % 2 === 0;
    const armIdx = Math.floor(i / 2);
    let ang = -Math.PI / 2 + (i * Math.PI) / 5;
    if (isOuter && armIdx === 4 && waveAmt >= 0.45) {
      ang += Math.sin(pose.waveRaysPhase) * 0.16;
    }
    const r = isOuter ? outerR : innerR;
    const px = Math.cos(ang) * r;
    const py = Math.sin(ang) * r;
    if (i === 0) starP.moveTo(px, py);
    else starP.quadraticCurveTo(Math.cos(ang - 0.15) * (r * 0.92), Math.sin(ang - 0.15) * (r * 0.92), px, py);
  }
  starP.closePath();

  fillRimAndStroke(ctx, starP, -155, -170, 155, 170, cLight, cMid, cDark, outline, 3.8);

  // Radial carinal ridge lines + Signature Chocolate-Chip Conical Tubercles along the 5 rays
  ctx.save();
  ctx.clip(starP);
  ctx.strokeStyle = 'rgba(168, 54, 18, 0.45)';
  ctx.lineWidth = 3.2;
  for (let a = 0; a < 5; a++) {
    const ang = -Math.PI / 2 + (a * 2 * Math.PI) / 5;
    ctx.beginPath();
    ctx.moveTo(Math.cos(ang) * 42, Math.sin(ang) * 42);
    ctx.lineTo(Math.cos(ang) * 162, Math.sin(ang) * 162);
    ctx.stroke();

    for (const dist of [78, 118, 152]) {
      const nx = Math.cos(ang) * dist;
      const ny = Math.sin(ang) * dist;
      const nr = dist === 152 ? 7.5 : 11;
      ctx.fillStyle = hornCol;
      drawOvalSpot(ctx, nx, ny, nr, nr, 0);
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      drawOvalSpot(ctx, nx - 2.5, ny - 2.5, nr * 0.32, nr * 0.32, 0);
    }
  }
  ctx.restore();

  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;
  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 26 + lookY * 0.8, 56 + lookX * 0.8, 26 + lookY * 0.8, 26, 15, pose.blushAlpha);
  drawExpressiveAnimalMouth(ctx, 0 + lookX, 38 + lookY, 0.84, 0.05, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -38 + lookX * 0.85, -4 + lookY * 0.85, 28, 33, -0.06, pose, IRIS_PALETTES.amber, cLight, cMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 38 + lookX * 0.85, -4 + lookY * 0.85, 28, 33, 0.06, pose, IRIS_PALETTES.amber, cLight, cMid, outline);
  drawExpressiveAnimalBrows(ctx, -38 + lookX * 0.85, -46 + lookY * 0.85, 38 + lookX * 0.85, -46 + lookY * 0.85, 36, pose, outline, 4.0);

  ctx.restore();
}

/* ============================================================================
 * A23: SOUTHERN RIVER TERRAPIN / TUNTUNG SUNGAI (Batagur affinis)
 * Rebuilt from scratch per User Fix #15 ("A22, A23, A24: redo. not even close to actual models"):
 * - Grounded standing freshwater river terrapin with a low, streamlined olive-grey
 *   and charcoal-slate oval carapace (distinct from domed Box Turtle & marine Sea Turtles)
 * - Characteristic upturned, pointed tubular river-terrapin snout ("pig-nosed" profile)
 * - Pale silvery-grey head skin with breeding charcoal-black face mask & pale yellow-white iris
 * - Strongly webbed, clawed freshwater swimming feet (NOT marine paddles)
 * ========================================================================== */
function drawRiverTerrapinRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#1b221e';
  const skinLight = '#b0bdb5';
  const skinMid = '#78877e';
  const skinDark = '#46524b';
  const shellLight = '#7c8c6e';
  const shellMid = '#516146';
  const shellDark = '#2f3b28';
  const plastronCream = '#ebe5ce';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  ctx.save();
  ctx.translate(pose.shellOffsetX, 32 + pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. All 4 Grounded Webbed Clawed Legs + Muscular Neck Bridge drawn BEFORE the carapace/plastron
  // with stocky, realistic turtle leg proportions (32 + 58 + 90 = 180 on the ground!)
  drawSculptedPawLimb(ctx, -46, 58, pose.hindFarAngle * 0.4, 90, 44, skinMid, skinDark, outline, outline, {
    clawsColor: '#e2dec9',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 46, 58, pose.farFlipperAngle * 0.35 - 0.06, 90, 44, skinMid, skinDark, outline, outline, {
      clawsColor: '#e2dec9',
    });
  }
  drawSculptedPawLimb(ctx, -92, 58, pose.hindNearAngle * 0.45 + 0.06, 90, 48, skinLight, skinMid, skinDark, outline, {
    clawsColor: '#e2dec9',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, 2, 58, pose.nearFlipperAngle * 0.35 + 0.05, 90, 46, skinLight, skinMid, skinDark, outline, {
      clawsColor: '#e2dec9',
    });
  }

  // Muscular Terrapin Neck Bridge connecting anterior shell opening to the head
  const neckBridge = new Path2D();
  neckBridge.moveTo(14, -8);
  neckBridge.quadraticCurveTo(46, -24, 68 + pose.headX * 0.5, -24 + pose.headY * 0.5);
  neckBridge.lineTo(66 + pose.headX * 0.5, 28 + pose.headY * 0.5);
  neckBridge.quadraticCurveTo(42, 48, 12, 48);
  neckBridge.closePath();
  fillRimAndStroke(ctx, neckBridge, 14, -24, 72, 48, skinLight, skinMid, skinDark, outline, 3.4);

  // 2. Low, Streamlined Hydrodynamic Oval Carapace & Plastron of Batagur affinis
  const shellP = new Path2D();
  shellP.moveTo(-136, 52);
  shellP.bezierCurveTo(-142, -32, -62, -62, 12, -48);
  shellP.bezierCurveTo(64, -38, 90, 6, 84, 52);
  shellP.bezierCurveTo(42, 74, -84, 74, -136, 52);
  shellP.closePath();
  fillRimAndStroke(ctx, shellP, -138, -58, 86, 72, shellLight, shellMid, shellDark, outline, 3.6);

  ctx.save();
  ctx.clip(shellP);
  ctx.strokeStyle = 'rgba(27, 34, 30, 0.55)';
  ctx.lineWidth = 2.6;
  for (const sx of [-86, -42, 4, 46]) {
    ctx.beginPath();
    ctx.moveTo(sx, -52);
    ctx.quadraticCurveTo(sx - 12, 8, sx - 4, 52);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(-128, 32);
  ctx.quadraticCurveTo(-22, 46, 78, 36);
  ctx.stroke();

  ctx.fillStyle = plastronCream;
  ctx.fillRect(-138, 42, 228, 34);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(shellP);

  // 3. Seamlessly Welded Short River-Terrapin Tail (drawn after shell with open root so no shell line cuts across tail!)
  drawEmbeddedTail(ctx, -124, 52, -168, 68 + pose.hindNearAngle * 18, 20, 5, skinLight, skinMid, skinDark, outline);

  // 4. Batagur affinis Head with Closed Smoothly Rounded Cranium & Upturned Pointed Snout (zero flat back cut!)
  ctx.save();
  ctx.translate(58 + pose.headX * 0.65, -8 + pose.headY * 0.65);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 12;
  const lookY = pose.headLookY * 8;

  const headFill = new Path2D();
  headFill.moveTo(-54, 4);
  headFill.bezierCurveTo(-56, -34, -24, -54, 24, -56);
  headFill.bezierCurveTo(46, -56, 62 + lookX * 0.5, -32 + lookY * 0.4, 86 + lookX * 0.7, -30 + lookY * 0.5);
  headFill.bezierCurveTo(106 + lookX * 0.85, -36 + lookY * 0.6, 108 + lookX * 0.85, -14 + lookY * 0.6, 104 + lookX * 0.8, 12 + lookY * 0.6);
  headFill.bezierCurveTo(96 + lookX * 0.7, 36 + lookY * 0.5, 58 + lookX * 0.4, 46 + lookY * 0.4, 18, 48);
  headFill.bezierCurveTo(-22, 50, -52, 34, -54, 4);
  headFill.closePath();

  fillRimAndStroke(ctx, headFill, -56, -56, 108, 50, skinLight, skinMid, skinDark, outline, 3.6);

  ctx.save();
  ctx.clip(headFill);
  ctx.fillStyle = 'rgba(30, 38, 34, 0.52)';
  drawOvalSpot(ctx, 28 + lookX * 0.5, -18 + lookY * 0.5, 58, 32, -0.08);
  drawSoftCheekBlushes(ctx, -12 + lookX * 0.7, 16 + lookY * 0.7, 68 + lookX * 0.7, 18 + lookY * 0.7, 20, 12, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headFill);

  ctx.fillStyle = outline;
  drawOvalSpot(ctx, 96 + lookX * 0.8, -22 + lookY * 0.55, 3.8, 2.6, -0.2);

  drawExpressiveAnimalMouth(ctx, 46 + lookX * 0.7, 22 + lookY * 0.6, 0.76, 0.04, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -2 + lookX * 0.7, -12 + lookY * 0.7, 20, 23, -0.06, pose, IRIS_PALETTES.goldenHazel, skinLight, skinMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 62 + lookX * 0.75, -8 + lookY * 0.7, 17, 20, 0.1, pose, IRIS_PALETTES.goldenHazel, skinLight, skinMid, outline);
  drawExpressiveAnimalBrows(ctx, -2 + lookX * 0.7, -40 + lookY * 0.7, 62 + lookX * 0.75, -34 + lookY * 0.7, 26, pose, outline, 3.6);
  ctx.restore();

  // 5. Foreground Waving Limb or Chin-Touching Limb
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -18 + pose.nearFlipperShoulderX,
      46 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      92,
      44,
      skinLight,
      skinMid,
      skinDark,
      outline,
      { clawsColor: '#e2dec9' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 56, 56, -2.45 + pose.farFlipperAngle * 0.35, 84, 42, skinLight, skinMid, skinDark, outline, {
      clawsColor: '#e2dec9',
    });
  }
  ctx.restore();
}

/* ============================================================================
 * A24: MALAYAN / AMBOINA BOX TURTLE (Cuora amboinensis)
 * Rebuilt from scratch per User Fix #15 & Latest Screenshot Review (image_9b77a0a7.png):
 * - All 4 grounded terrestrial legs + muscular neck bridge drawn BEFORE the helmet
 *   carapace/plastron so legs emerge from underneath the shell with ZERO air gap
 *   and zero capsule dome overlapping the yellow plastron!
 * - Closed, smoothly rounded head cranium (zero flat vertical cut on left of head!)
 *   with diagnostic 3 lemon-yellow lateral stripes & yellow chin/throat.
 * ========================================================================== */
function drawBoxTurtleRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#1a120b';
  const shellLight = '#5c3c24';
  const shellMid = '#362112';
  const shellDark = '#1c1008';
  const goldTrim = '#facc15';
  const headDark = '#292524';
  const headMid = '#44403c';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  ctx.save();
  ctx.translate(pose.shellOffsetX, 32 + pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. All 4 Grounded Terrestrial Legs + Muscular Neck Bridge drawn BEFORE the domed shell
  // with stocky, realistic turtle leg proportions (32 + 58 + 90 = 180 on the ground!)
  drawSculptedPawLimb(ctx, -46, 58, pose.hindFarAngle * 0.4, 90, 44, headMid, headDark, outline, outline, {
    pawTipColor: goldTrim,
    clawsColor: '#fef08a',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 46, 58, pose.farFlipperAngle * 0.35 - 0.06, 90, 44, headMid, headDark, outline, outline, {
      pawTipColor: goldTrim,
      clawsColor: '#fef08a',
    });
  }
  drawSculptedPawLimb(ctx, -90, 58, pose.hindNearAngle * 0.45 + 0.06, 90, 48, headMid, headDark, outline, outline, {
    pawTipColor: goldTrim,
    clawsColor: '#fef08a',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, 2, 58, pose.nearFlipperAngle * 0.35 + 0.05, 90, 46, headMid, headDark, outline, outline, {
      pawTipColor: goldTrim,
      clawsColor: '#fef08a',
    });
  }

  // Muscular Box-Turtle Neck Bridge with yellow throat stripe connecting shell opening to head
  const neckBridge = new Path2D();
  neckBridge.moveTo(14, -8);
  neckBridge.quadraticCurveTo(46, -24, 68 + pose.headX * 0.5, -22 + pose.headY * 0.5);
  neckBridge.lineTo(66 + pose.headX * 0.5, 30 + pose.headY * 0.5);
  neckBridge.quadraticCurveTo(42, 48, 12, 48);
  neckBridge.closePath();
  fillRimAndStroke(ctx, neckBridge, 14, -24, 72, 48, '#57534e', headMid, headDark, outline, 3.4);

  // 2. High Hemispherical Helmet-Like Domed Carapace & Yellow Plastron of Cuora amboinensis
  const domeP = new Path2D();
  domeP.moveTo(-128, 56);
  domeP.bezierCurveTo(-136, -68, -64, -112, -10, -110);
  domeP.bezierCurveTo(50, -108, 92, -52, 82, 54);
  domeP.bezierCurveTo(36, 74, -80, 74, -128, 56);
  domeP.closePath();
  fillRimAndStroke(ctx, domeP, -132, -110, 84, 72, shellLight, shellMid, shellDark, outline, 3.8);

  ctx.save();
  ctx.clip(domeP);
  ctx.strokeStyle = 'rgba(250, 204, 21, 0.35)';
  ctx.lineWidth = 2.2;
  for (const [sx, sy, rx, ry] of [
    [-68, -24, 28, 34],
    [-12, -32, 30, 38],
    [42, -18, 26, 32],
  ] as const) {
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.fillStyle = '#fef08a';
  ctx.fillRect(-132, 40, 220, 36);
  ctx.strokeStyle = outline;
  ctx.lineWidth = 3.0;
  ctx.beginPath();
  ctx.moveTo(-128, 40);
  ctx.quadraticCurveTo(-18, 52, 82, 40);
  ctx.stroke();
  ctx.restore();
  ctx.lineWidth = 3.8;
  ctx.strokeStyle = outline;
  ctx.stroke(domeP);

  // 3. Seamlessly Welded Short Tail (drawn after dome with open root so no shell line cuts across tail!)
  drawEmbeddedTail(ctx, -118, 54, -156, 70 + pose.hindNearAngle * 14, 18, 4, headMid, headDark, outline, outline);

  // 4. Cuora amboinensis Head with Closed Smoothly Rounded Cranium & 3 Lemon-Yellow Stripes (zero flat vertical cut!)
  ctx.save();
  ctx.translate(58 + pose.headX * 0.65, -6 + pose.headY * 0.65);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 12;
  const lookY = pose.headLookY * 8;

  const headFill = new Path2D();
  headFill.moveTo(-54, 4);
  headFill.bezierCurveTo(-56, -34, -22, -54, 30, -56);
  headFill.bezierCurveTo(56, -56, 74 + lookX * 0.6, -24 + lookY * 0.5, 92 + lookX * 0.78, -6 + lookY * 0.6);
  headFill.bezierCurveTo(98 + lookX * 0.8, 12 + lookY * 0.6, 86 + lookX * 0.65, 34 + lookY * 0.55, 64 + lookX * 0.5, 42 + lookY * 0.5);
  headFill.bezierCurveTo(22, 52, -22, 48, -46, 30);
  headFill.bezierCurveTo(-52, 22, -54, 14, -54, 4);
  headFill.closePath();

  fillRimAndStroke(ctx, headFill, -56, -56, 96, 50, '#57534e', headMid, headDark, outline, 3.6);

  ctx.save();
  ctx.clip(headFill);
  ctx.fillStyle = '#fef08a';
  drawOvalSpot(ctx, 18 + lookX * 0.5, 38 + lookY * 0.5, 76, 22, 0.05);

  ctx.strokeStyle = '#facc15';
  ctx.lineCap = 'round';
  ctx.lineWidth = 6.5;
  ctx.beginPath();
  ctx.moveTo(-52, -22);
  ctx.quadraticCurveTo(14 + lookX * 0.5, -42 + lookY * 0.5, 86 + lookX * 0.75, -12 + lookY * 0.6);
  ctx.stroke();
  ctx.lineWidth = 5.2;
  ctx.beginPath();
  ctx.moveTo(-52, 0);
  ctx.quadraticCurveTo(16 + lookX * 0.5, -8 + lookY * 0.5, 88 + lookX * 0.75, -4 + lookY * 0.6);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-50, 18);
  ctx.quadraticCurveTo(18 + lookX * 0.5, 16 + lookY * 0.5, 84 + lookX * 0.75, 8 + lookY * 0.6);
  ctx.stroke();

  drawSoftCheekBlushes(ctx, -12 + lookX * 0.7, 16 + lookY * 0.7, 66 + lookX * 0.7, 18 + lookY * 0.7, 20, 12, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headFill);

  drawExpressiveAnimalMouth(ctx, 42 + lookX * 0.7, 22 + lookY * 0.6, 0.76, 0.05, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -2 + lookX * 0.7, -12 + lookY * 0.7, 21, 24, -0.06, pose, IRIS_PALETTES.amber, headMid, headDark, outline);
  drawGlossyAnimalEye(ctx, 'right', 60 + lookX * 0.75, -8 + lookY * 0.7, 18, 21, 0.1, pose, IRIS_PALETTES.amber, headMid, headDark, outline);
  drawExpressiveAnimalBrows(ctx, -2 + lookX * 0.7, -40 + lookY * 0.7, 60 + lookX * 0.75, -34 + lookY * 0.7, 28, pose, '#facc15', 3.8);
  ctx.restore();

  // 5. Foreground Waving Limb or Chin-Touching Limb
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -18 + pose.nearFlipperShoulderX,
      46 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      102,
      44,
      headMid,
      headDark,
      outline,
      outline,
      { pawTipColor: goldTrim, clawsColor: '#fef08a' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 56, 56, -2.45 + pose.farFlipperAngle * 0.35, 88, 42, headMid, headDark, outline, outline, {
      pawTipColor: goldTrim,
      clawsColor: '#fef08a',
    });
  }
  ctx.restore();
}

/* ============================================================================
 * A29: HAWKSBILL SEA TURTLE (Eretmochelys imbricata)
 * Rebuilt & Refined per User Fix #18 & Latest Screenshot 1 Review:
 * - Follows the exact anatomical layering of A28 Green Sea Turtle:
 *   1. Far front & hind flippers
 *   2. Golden-amber ventral plastron under-shell with cream scute plates
 *   3. Heart-shaped tortoiseshell carapace with imbricated scutes & serrated rear rim
 *   4. Near front paddle flipper tucked under cheek/shoulder
 *   5. Cute large Hawksbill head with mahogany scales & hooked raptor beak drawn ON TOP!
 * ========================================================================== */
function drawHawksbillSeaTurtleRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#241205';
  const skinLight = '#f7d794';
  const skinMid = '#c48b3f';
  const skinDark = '#6e4212';
  const shellGold = '#f59e0b';
  const shellAmber = '#b45309';
  const shellMahogany = '#451a03';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  const drawHawksbillFlipper = (x: number, y: number, ang: number, len: number, wid: number) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    const flipFill = new Path2D();
    flipFill.moveTo(-wid * 0.42, 0);
    flipFill.quadraticCurveTo(0, -14, wid * 0.42, 0);
    flipFill.bezierCurveTo(wid * 0.55, len * 0.35, wid * 0.55, len * 0.88, 0, len);
    flipFill.bezierCurveTo(-wid * 0.65, len * 0.85, -wid * 0.85, len * 0.35, -wid * 0.42, 0);
    flipFill.closePath();

    const flipStroke = new Path2D();
    flipStroke.moveTo(-wid * 0.42, 2);
    flipStroke.bezierCurveTo(-wid * 0.85, len * 0.35, -wid * 0.65, len * 0.85, 0, len);
    flipStroke.bezierCurveTo(wid * 0.55, len * 0.88, wid * 0.55, len * 0.35, wid * 0.42, 2);

    fillRimAndStroke(ctx, flipFill, -wid, -10, wid, len, skinLight, skinMid, skinDark, outline, 3.4, flipStroke);

    ctx.save();
    ctx.clip(flipFill);
    for (let sy = 20; sy <= len - 22; sy += 20) {
      ctx.fillStyle = shellMahogany;
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2.0;
      ctx.beginPath();
      ctx.ellipse(-4, sy, wid * 0.28, 8.5, 0.12, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();

    ctx.fillStyle = '#fef3c7';
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.0;
    for (const cy of [len * 0.48, len * 0.68]) {
      ctx.beginPath();
      ctx.moveTo(-wid * 0.52, cy);
      ctx.lineTo(-wid * 0.76, cy + 8);
      ctx.lineTo(-wid * 0.46, cy + 12);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  };

  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // 1. Far front & hind flippers tucked deep inside the carapace/plastron silhouette
  drawHawksbillFlipper(38, 36, pose.farFlipperAngle * 0.45 - 0.58, 126, 42);
  drawHawksbillFlipper(-104, 34, pose.hindNearAngle * 0.5 + 0.88, 92, 36);
  drawHawksbillFlipper(-38, 56, pose.hindFarAngle * 0.45 + 0.18, 78, 34);

  // 2. Sculpted Golden-Cream Ventral Belly & Plastron Under-Shell (matching A28 plastron geometry)
  const bellyP = new Path2D();
  bellyP.moveTo(-132, 24);
  bellyP.bezierCurveTo(-72, 12, 12, 10, 58, 26);
  bellyP.bezierCurveTo(66, 56, 42, 86, -8, 94);
  bellyP.bezierCurveTo(-64, 102, -118, 78, -132, 24);
  bellyP.closePath();
  fillRimAndStroke(ctx, bellyP, -120, 14, 54, 94, skinLight, skinMid, skinDark, outline, 3.5);

  ctx.save();
  ctx.clip(bellyP);
  const plastronP = new Path2D();
  plastronP.ellipse(-28, 62, 64, 34, -0.05, 0, Math.PI * 2);
  ctx.fillStyle = '#fef3c7';
  ctx.fill(plastronP);
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 2.2;
  ctx.stroke(plastronP);
  ctx.beginPath();
  ctx.moveTo(-28, 28);
  ctx.lineTo(-28, 96);
  ctx.moveTo(-88, 56);
  ctx.lineTo(32, 54);
  ctx.moveTo(-84, 74);
  ctx.lineTo(28, 72);
  ctx.stroke();
  ctx.restore();
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = outline;
  ctx.stroke(bellyP);

  // 3. Heart-Shaped Tortoiseshell Carapace with Imbricated Scutes & Saw-Toothed Serrated Rear Margin
  const shellP = new Path2D();
  shellP.moveTo(52, 6);
  shellP.bezierCurveTo(38, -78, -68, -92, -142, -24);
  shellP.lineTo(-164, -6);
  shellP.lineTo(-150, 6);
  shellP.lineTo(-168, 20);
  shellP.lineTo(-150, 28);
  shellP.lineTo(-160, 42);
  shellP.lineTo(-136, 44);
  shellP.bezierCurveTo(-64, 52, 18, 36, 52, 6);
  shellP.closePath();
  fillRimAndStroke(ctx, shellP, -168, -86, 52, 48, shellGold, shellAmber, shellMahogany, outline, 3.7);

  ctx.save();
  ctx.clip(shellP);
  for (const [sx, sy, rx, ry, rot] of [
    [-108, -14, 28, 22, -0.15],
    [-60, -26, 32, 26, -0.08],
    [-8, -22, 30, 24, 0.06],
    [-92, 16, 26, 18, -0.1],
    [-42, 14, 30, 20, 0],
    [8, 10, 24, 16, 0.1],
  ] as const) {
    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(rot);
    ctx.fillStyle = shellMahogany;
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(-rx, -ry * 0.5);
    ctx.quadraticCurveTo(0, -ry, rx, -ry * 0.3);
    ctx.lineTo(rx * 0.7, ry * 0.8);
    ctx.quadraticCurveTo(-rx * 0.4, ry, -rx, -ry * 0.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(rx * 0.4, 0);
    ctx.lineTo(-rx * 0.6, -ry * 0.3);
    ctx.moveTo(rx * 0.4, 0);
    ctx.lineTo(-rx * 0.5, ry * 0.4);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
  ctx.lineWidth = 3.7;
  ctx.strokeStyle = outline;
  ctx.stroke(shellP);

  // 4. Near Front Paddle Flipper emerging from shoulder socket BEFORE head group (so cheek overlaps top shoulder like A28!)
  drawHawksbillFlipper(
    -58 + pose.nearFlipperShoulderX,
    28 + pose.nearFlipperShoulderY,
    pose.nearFlipperAngle * 0.45 + 0.28 - waveAmt * 0.65,
    132,
    46,
  );

  // 5. Cute Large Hawksbill Head with Hooked Raptor Beak & Glossy Amber Eyes (drawn ON TOP of anterior carapace & shoulder!)
  ctx.save();
  ctx.translate(42 + pose.headX * 0.6, -18 + pose.headY * 0.6);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 12;
  const lookY = pose.headLookY * 8;

  const headFill = new Path2D();
  headFill.moveTo(-68, -14);
  headFill.bezierCurveTo(-58, -74, 24, -84, 78 + lookX * 0.5, -42 + lookY * 0.4);
  headFill.bezierCurveTo(112 + lookX * 0.7, -14 + lookY * 0.5, 118 + lookX * 0.8, 24 + lookY * 0.6, 98 + lookX * 0.75, 42 + lookY * 0.6);
  // Characteristic hooked Hawksbill upper beak tip
  headFill.lineTo(84 + lookX * 0.7, 32 + lookY * 0.6);
  headFill.bezierCurveTo(54 + lookX * 0.5, 56 + lookY * 0.5, -24, 58, -58, 32);
  headFill.bezierCurveTo(-72, 20, -74, 2, -68, -14);
  headFill.closePath();

  fillRimAndStroke(ctx, headFill, -68, -78, 112, 56, skinLight, skinMid, skinDark, outline, 3.6);

  ctx.save();
  ctx.clip(headFill);
  for (const [hx, hy, rx, ry] of [
    [12, -52, 24, 13],
    [48, -44, 18, 10],
    [-38, -28, 16, 11],
    [-46, 2, 12, 9],
  ] as const) {
    ctx.fillStyle = shellMahogany;
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.ellipse(hx + lookX * 0.4, hy + lookY * 0.4, rx, ry, 0.12, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
  ctx.fillStyle = '#f59e0b';
  drawOvalSpot(ctx, 94 + lookX * 0.75, 18 + lookY * 0.55, 22, 22, 0.2);
  drawSoftCheekBlushes(ctx, -18 + lookX * 0.7, 22 + lookY * 0.7, 68 + lookX * 0.7, 24 + lookY * 0.7, 22, 13, pose.blushAlpha);
  ctx.restore();
  ctx.lineWidth = 3.6;
  ctx.strokeStyle = outline;
  ctx.stroke(headFill);

  drawExpressiveAnimalMouth(ctx, 42 + lookX * 0.7, 28 + lookY * 0.6, 0.78, 0.08, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -8 + lookX * 0.7, -8 + lookY * 0.7, 25, 29, -0.06, pose, IRIS_PALETTES.amber, skinLight, skinMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 62 + lookX * 0.75, -2 + lookY * 0.7, 21, 25, 0.1, pose, IRIS_PALETTES.amber, skinLight, skinMid, outline);
  drawExpressiveAnimalBrows(ctx, -8 + lookX * 0.7, -44 + lookY * 0.7, 62 + lookX * 0.75, -36 + lookY * 0.7, 30, pose, outline, 3.8);
  ctx.restore();
  ctx.restore();
}

/* ============================================================================
 * A41: GIANT PANDA (Ailuropoda melanoleuca)
 * Added per User Fix #3 ("Add A41: Panda. Have emotions: idle, waving, laugh,
 * sleepy, blush, blink eyes"):
 * - Grounded standing chibi-realistic Giant Panda with plush creamy-white fur,
 *   velvety jet-black round ears, iconic tilted black eye patches, black shoulder
 *   saddle harness merging seamlessly into the front arms and hind legs ("嵌入"),
 *   cute pink-and-charcoal paw pads, and a fresh green bamboo shoot!
 * ========================================================================== */
function drawGiantPandaRig(ctx: CanvasRenderingContext2D, pose: TurtlePose): void {
  const outline = '#171717';
  const furWhite = '#ffffff';
  const furCream = '#f5f2eb';
  const furShadow = '#d6d1c4';
  const blackLight = '#3f3f46';
  const blackMid = '#1f1f23';
  const blackDark = '#09090b';
  const waveAmt = clamp(1 - pose.nearFlipperDownAmount - pose.nearFlipperTuckAmount, 0, 1);

  // Far Hind Leg & Far Front Leg behind torso (all 4 legs grounded on y=186!)
  drawSculptedPawLimb(ctx, -48, 86, pose.hindFarAngle * 0.4, 100, 52, blackLight, blackMid, blackDark, outline, {
    pawTipColor: '#27272a',
    clawsColor: '#e4e4e7',
  });
  if (pose.farFlipperChinAmount <= 0.4) {
    drawSculptedPawLimb(ctx, 48, 78, pose.farFlipperAngle * 0.35 - 0.08, 108, 50, blackLight, blackMid, blackDark, outline, {
      pawTipColor: '#27272a',
      clawsColor: '#e4e4e7',
    });
  }

  // 1. Plump Creamy-White Panda Torso + Black Shoulder Saddle Band + Fluffy White Tail Puff
  ctx.save();
  ctx.translate(pose.shellOffsetX, pose.shellOffsetY);
  ctx.rotate(pose.shellRot);

  // Cute round white panda tail puff embedded on lower rump
  const tailP = new Path2D();
  tailP.arc(-108, 66, 22, 0, Math.PI * 2);
  fillRimAndStroke(ctx, tailP, -130, 44, -86, 88, furWhite, furCream, furShadow, outline, 3.5);

  const torso = new Path2D();
  torso.ellipse(-10, 44, 108, 92, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, torso, -110, -48, 90, 134, furWhite, furCream, furShadow, outline, 3.8);

  ctx.save();
  ctx.clip(torso);
  // Characteristic black shoulder/chest saddle band of Giant Panda extending down to y=98
  // so the near & far front black arms weld directly into the black shoulder saddle!
  const saddleP = new Path2D();
  saddleP.moveTo(-42, -52);
  saddleP.quadraticCurveTo(18, -28, 92, -38);
  saddleP.lineTo(98, 98);
  saddleP.quadraticCurveTo(22, 106, -38, 96);
  saddleP.closePath();
  ctx.fillStyle = blackMid;
  ctx.fill(saddleP);

  // Black hind hip patch so the near & far black hind legs weld directly into black hip fur without an internal outline ring!
  const hipPatch = new Path2D();
  hipPatch.ellipse(-92, 88, 38, 36, 0.1, 0, Math.PI * 2);
  ctx.fillStyle = blackMid;
  ctx.fill(hipPatch);

  // Plush belly fur tuft lines
  ctx.strokeStyle = 'rgba(160, 150, 135, 0.45)';
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.arc(-44, 78, 26, 0.25, Math.PI - 0.25);
  ctx.stroke();
  ctx.restore();
  ctx.lineWidth = 3.8;
  ctx.strokeStyle = outline;
  ctx.stroke(torso);
  ctx.restore();

  // 2. Seamlessly Embedded ("嵌入") Jet-Black Near Hind Leg & Near Front Arm planted on y=186
  drawSculptedPawLimb(ctx, -96, 82, pose.hindNearAngle * 0.4 + 0.05, 104, 56, blackLight, blackMid, blackDark, outline, {
    pawTipColor: '#27272a',
    clawsColor: '#f4f4f5',
  });
  if (waveAmt < 0.45) {
    drawSculptedPawLimb(ctx, -4, 74, pose.nearFlipperAngle * 0.35 + 0.05, 112, 52, blackLight, blackMid, blackDark, outline, {
      pawTipColor: '#27272a',
      clawsColor: '#f4f4f5',
    });
  }

  // Fresh green bamboo stalk held near chest/paw
  ctx.save();
  ctx.translate(68, 56);
  ctx.rotate(0.28 + Math.sin(pose.waveRaysPhase * 0.7) * 0.05);
  ctx.fillStyle = '#4ade80';
  ctx.strokeStyle = '#14532d';
  ctx.lineWidth = 3.0;
  ctx.beginPath();
  ctx.roundRect(-7, -56, 14, 96, 6);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-8, -24);
  ctx.lineTo(8, -24);
  ctx.moveTo(-8, 12);
  ctx.lineTo(8, 12);
  ctx.stroke();
  for (const [lx, ly, rot] of [
    [7, -34, -0.55],
    [-7, -14, 2.4],
    [7, -4, -0.35],
  ] as const) {
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(rot);
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.ellipse(16, 0, 18, 6.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();

  // 3. Large Round Panda Head, Velvety Black Ears & Iconic Black Eye Patches
  ctx.save();
  ctx.translate(28 + pose.headX, -44 + pose.headY);
  ctx.rotate(pose.headRot);
  ctx.scale(pose.headScaleX, pose.headScaleY);
  const lookX = pose.headLookX * 14;
  const lookY = pose.headLookY * 10;

  // Round velvety jet-black panda ears
  for (const [ex, ey] of [
    [-78, -76],
    [82, -68],
  ] as const) {
    ctx.save();
    ctx.translate(ex + lookX * 0.3, ey + lookY * 0.3);
    const earP = new Path2D();
    earP.arc(0, 0, 32, 0, Math.PI * 2);
    fillRimAndStroke(ctx, earP, -32, -32, 32, 32, blackLight, blackMid, blackDark, outline, 3.6);
    ctx.fillStyle = '#27272a';
    drawOvalSpot(ctx, 0, 2, 16, 16, 0);
    ctx.restore();
  }

  // Plump cheeks & rounded panda head
  const headP = new Path2D();
  headP.ellipse(4, -2, 106, 92, 0.03, 0, Math.PI * 2);
  fillRimAndStroke(ctx, headP, -95, -92, 95, 92, furWhite, furCream, furShadow, outline, 3.8);

  ctx.save();
  ctx.clip(headP);
  // Iconic tilted teardrop black panda eye patches!
  ctx.fillStyle = blackMid;
  drawOvalSpot(ctx, -38 + lookX * 0.8, -10 + lookY * 0.8, 36, 44, 0.28);
  drawOvalSpot(ctx, 62 + lookX * 0.8, -2 + lookY * 0.8, 32, 40, -0.28);

  drawSoftCheekBlushes(ctx, -56 + lookX * 0.8, 28 + lookY * 0.8, 76 + lookX * 0.8, 34 + lookY * 0.8, 28, 16, Math.max(0.28, pose.blushAlpha));
  ctx.restore();
  ctx.lineWidth = 3.8;
  ctx.strokeStyle = outline;
  ctx.stroke(headP);

  // Cute plush muzzle & black button nose
  const muzzleP = new Path2D();
  muzzleP.ellipse(16 + lookX * 0.9, 24 + lookY * 0.85, 36, 26, 0.04, 0, Math.PI * 2);
  fillRimAndStroke(ctx, muzzleP, -20, 0, 52, 50, '#ffffff', furCream, furShadow, outline, 3.0);

  const noseX = 18 + lookX * 0.95;
  const noseY = 12 + lookY * 0.9;
  ctx.fillStyle = blackDark;
  drawOvalSpot(ctx, noseX, noseY, 15, 10, 0.04);
  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  drawOvalSpot(ctx, noseX - 4, noseY - 3, 5, 2.5, -0.15);

  drawExpressiveAnimalMouth(ctx, 18 + lookX * 0.9, 36 + lookY * 0.85, 0.86, 0.06, pose, outline);
  drawGlossyAnimalEye(ctx, 'left', -36 + lookX * 0.85, -12 + lookY * 0.85, 26, 30, -0.06, pose, IRIS_PALETTES.warmBrown, blackLight, blackMid, outline);
  drawGlossyAnimalEye(ctx, 'right', 60 + lookX * 0.85, -4 + lookY * 0.85, 23, 27, 0.1, pose, IRIS_PALETTES.warmBrown, blackLight, blackMid, outline);
  drawExpressiveAnimalBrows(ctx, -36 + lookX * 0.85, -54 + lookY * 0.85, 60 + lookX * 0.85, -42 + lookY * 0.85, 34, pose, outline, 4.0);
  ctx.restore();

  // Foreground Waving Panda Arm (waves outward to top-left with cute pink paw pads!) or Chin-Touching Arm
  if (waveAmt >= 0.45) {
    drawSculptedPawLimb(
      ctx,
      -36 + pose.nearFlipperShoulderX,
      24 + pose.nearFlipperShoulderY,
      2.15 + pose.nearFlipperAngle * 0.85,
      118,
      54,
      blackLight,
      blackMid,
      blackDark,
      outline,
      { pawTipColor: '#f472b6', clawsColor: '#f4f4f5' },
    );
  }
  if (pose.farFlipperChinAmount > 0.4) {
    drawSculptedPawLimb(ctx, 58, 68, -2.45 + pose.farFlipperAngle * 0.35, 92, 48, blackLight, blackMid, blackDark, outline, {
      pawTipColor: '#f472b6',
      clawsColor: '#f4f4f5',
    });
  }
}

