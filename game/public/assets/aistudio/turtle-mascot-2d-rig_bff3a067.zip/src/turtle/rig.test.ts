import assert from 'node:assert/strict';
import test from 'node:test';
import {TurtleRigController} from './rig';
import {MotionType} from './types';

test('TurtleRigController initializes in idle motion facing right', () => {
  const rig = new TurtleRigController();
  assert.equal(rig.getMotion(), 'idle');
  assert.equal(rig.getDirection(), 'right');
  const pose = rig.step(0.05);
  assert.equal(pose.facing, 1);
  assert.ok(pose.nearFlipperDownAmount > 0.5);
});

test('TurtleRigController smoothly turns between right and left directions', () => {
  const rig = new TurtleRigController('waving', 'right');
  rig.toggleDirection();
  assert.equal(rig.getDirection(), 'left');

  // Step through transition
  for (let i = 0; i < 40; i++) {
    rig.step(0.03);
  }
  assert.ok(rig.pose.facing < -0.95);

  rig.toggleDirection();
  assert.equal(rig.getDirection(), 'right');
  for (let i = 0; i < 40; i++) {
    rig.step(0.03);
  }
  assert.ok(rig.pose.facing > 0.95);
});

test('TurtleRigController supports all 10 continuous emotion motions plus manual blink in both directions', () => {
  const rig = new TurtleRigController();
  const motions: MotionType[] = [
    'idle',
    'waving',
    'laugh',
    'wondered',
    'angry',
    'crying',
    'describing',
    'sleepy',
    'blush',
    'congratulate',
  ];

  for (const dir of ['right', 'left'] as const) {
    rig.setDirection(dir);
    for (const m of motions) {
      rig.setMotion(m);
      assert.equal(rig.getMotion(), m);
      for (let i = 0; i < 25; i++) {
        rig.step(0.025);
      }

      if (m === 'idle') {
        assert.ok(rig.pose.nearFlipperDownAmount > 0.8);
      } else if (m === 'laugh') {
        assert.ok(rig.pose.laughEyeAmount > 0.8);
      } else if (m === 'wondered') {
        assert.ok(rig.pose.farFlipperChinAmount > 0.8);
        assert.ok(rig.pose.questionMarkAlpha > 0.8);
      } else if (m === 'angry') {
        assert.ok(rig.pose.angryLidAmount > 0.8);
        assert.ok(rig.pose.angryVeinAlpha > 0.8);
      } else if (m === 'crying') {
        assert.ok(rig.pose.tearsAlpha > 0.8);
        assert.ok(rig.tearDrops.length > 0);
      } else if (m === 'describing') {
        assert.ok(rig.pose.farFlipperRaiseAmount > 0.8);
        assert.ok(rig.pose.nearFlipperTuckAmount > 0.8);
      } else if (m === 'sleepy') {
        assert.ok(rig.pose.sleepyLidAmount > 0.8);
        assert.ok(rig.pose.sleepyZzzAlpha > 0.8);
      } else if (m === 'blush') {
        assert.ok(rig.pose.blushAlpha > 0.85);
        assert.ok(rig.pose.blushHeartsAlpha > 0.8);
      } else if (m === 'congratulate') {
        assert.ok(rig.pose.congratsAlpha > 0.8);
        assert.ok(rig.pose.farFlipperRaiseAmount > 0.8);
      }
    }

    rig.triggerBlink();
    rig.step(0.09);
    assert.ok(rig.isBlinking());
  }
});

import fs from 'node:fs';
import {ROSTER_ASSETS} from '../roster/catalog';

test('ROSTER_ASSETS contains all 71 assets (41 Animals and 30 Plants) with unique IDs and codes', () => {
  assert.equal(ROSTER_ASSETS.length, 71);
  const animals = ROSTER_ASSETS.filter((a) => a.isAnimal);
  const plants = ROSTER_ASSETS.filter((a) => !a.isAnimal);
  assert.equal(animals.length, 41);
  assert.equal(plants.length, 30);

  const ids = new Set(ROSTER_ASSETS.map((a) => a.id));
  const codes = new Set(ROSTER_ASSETS.map((a) => a.code));
  assert.equal(ids.size, 71);
  assert.equal(codes.size, 71);
});

test('All 41 Animals and 30 Plants are explicitly handled as pure 2D Canvas rigs with zero drawImage calls', () => {
  const animalSrc = fs.readFileSync('src/roster/animalRenderer.ts', 'utf8');
  const plantSrc = fs.readFileSync('src/roster/plantRenderer.ts', 'utf8');
  const turtleSrc = fs.readFileSync('src/turtle/renderer.ts', 'utf8');

  assert.ok(!animalSrc.includes('drawImage'), 'animalRenderer.ts must not use drawImage');
  assert.ok(!plantSrc.includes('drawImage'), 'plantRenderer.ts must not use drawImage');
  assert.ok(!turtleSrc.includes('drawImage'), 'turtle/renderer.ts must not use drawImage');

  for (const asset of ROSTER_ASSETS) {
    if (asset.id === 'animal_28_green_sea_turtle') continue;
    if (asset.isAnimal) {
      assert.ok(
        animalSrc.includes(asset.id) || turtleSrc.includes(asset.id),
        `Animal ${asset.code} (${asset.id}) must have an explicit rig in animalRenderer.ts or turtle/renderer.ts`,
      );
    } else {
      assert.ok(
        plantSrc.includes(`'${asset.id}'`),
        `Plant ${asset.code} (${asset.id}) must have an explicit case in plantRenderer.ts`,
      );
    }
  }
});



