import {TurtleRigController} from './turtle/rig';
import {Direction, MotionType} from './turtle/types';
import {renderTurtle} from './turtle/renderer';
import {ROSTER_ASSETS, RosterAsset, AssetCategory} from './roster/catalog';
import {renderAnimalAsset} from './roster/animalRenderer';
import {renderPlantAsset} from './roster/plantRenderer';

const ALL_TURTLE_EMOTIONS: Array<{id: MotionType; label: string}> = [
  {id: 'idle', label: 'Idle'},
  {id: 'waving', label: 'Waving'},
  {id: 'laugh', label: 'Laugh'},
  {id: 'wondered', label: 'Wondered'},
  {id: 'angry', label: 'Angry'},
  {id: 'crying', label: 'Sad / Crying'},
  {id: 'describing', label: 'Describing'},
  {id: 'sleepy', label: 'Sleepy / Bored'},
  {id: 'blush', label: 'Blush'},
  {id: 'congratulate', label: 'Congratulate'},
];

const STANDARD_ANIMAL_EMOTIONS: Set<MotionType> = new Set([
  'idle',
  'waving',
  'laugh',
  'wondered',
  'angry',
  'crying',
  'sleepy',
  'blush',
]);

const PANDA_EMOTIONS: Set<MotionType> = new Set([
  'idle',
  'waving',
  'laugh',
  'sleepy',
  'blush',
]);

const CATEGORY_TABS: Array<{id: 'all' | AssetCategory; label: string}> = [
  {id: 'all', label: 'All (71)'},
  {id: 'animals_land', label: 'Land Animals (19)'},
  {id: 'animals_freshwater', label: 'Freshwater (8)'},
  {id: 'animals_marine', label: 'Marine (14)'},
  {id: 'plants_land', label: 'Land Plants (18)'},
  {id: 'plants_aquatic', label: 'Aquatic Plants (12)'},
];

function initApp(): void {
  const root = document.getElementById('root');
  if (!root) return;

  const params = new URLSearchParams(window.location.search);
  const initialAssetParam = params.get('asset') ?? params.get('species');
  let currentAsset: RosterAsset =
    ROSTER_ASSETS.find(
      (a) =>
        a.id === initialAssetParam ||
        a.code.toLowerCase() === initialAssetParam?.toLowerCase()
    ) ??
    ROSTER_ASSETS.find((a) => a.id === 'animal_28_green_sea_turtle') ??
    ROSTER_ASSETS[0];

  const allValidMotions: MotionType[] = ALL_TURTLE_EMOTIONS.map((e) => e.id);
  const rawMotionParam = params.get('motion') ?? params.get('emotion');
  const normalizedMotionParam = (rawMotionParam === 'sad' ? 'crying' : rawMotionParam) as MotionType | null;
  const initialMotion: MotionType =
    normalizedMotionParam && allValidMotions.includes(normalizedMotionParam)
      ? normalizedMotionParam
      : 'idle';

  const initialDirParam = params.get('dir') as Direction | null;
  const initialDir: Direction =
    initialDirParam === 'left' || initialDirParam === 'right' ? initialDirParam : 'right';

  const rig = new TurtleRigController(initialMotion, initialDir);
  let activeCategory: 'all' | AssetCategory = 'all';

  root.innerHTML = '';

  // 1. Top Roster Selector Bar (clean navigation for all 70 species)
  const topBar = document.createElement('header');
  topBar.className = 'roster-bar';
  topBar.setAttribute('aria-label', 'Species Selector');

  const categoryGroup = document.createElement('div');
  categoryGroup.className = 'category-tabs';
  const categoryButtons = new Map<'all' | AssetCategory, HTMLButtonElement>();

  const navGroup = document.createElement('div');
  navGroup.className = 'species-nav';

  const prevBtn = document.createElement('button');
  prevBtn.type = 'button';
  prevBtn.className = 'ctrl-btn nav-step-btn';
  prevBtn.dataset.action = 'prev-asset';
  prevBtn.textContent = '◀';
  prevBtn.setAttribute('aria-label', 'Previous Species');

  const speciesSelect = document.createElement('select');
  speciesSelect.className = 'species-select';
  speciesSelect.id = 'species-select';
  speciesSelect.setAttribute('aria-label', 'Select Species');

  const nextBtn = document.createElement('button');
  nextBtn.type = 'button';
  nextBtn.className = 'ctrl-btn nav-step-btn';
  nextBtn.dataset.action = 'next-asset';
  nextBtn.textContent = '▶';
  nextBtn.setAttribute('aria-label', 'Next Species');

  navGroup.append(prevBtn, speciesSelect, nextBtn);
  topBar.append(categoryGroup, navGroup);

  // 2. Main 2D Vector Canvas Stage
  const stage = document.createElement('main');
  stage.className = 'stage-container';

  const canvas = document.createElement('canvas');
  canvas.id = 'turtle-canvas';
  canvas.setAttribute('aria-label', 'Animated 2D Species Canvas');
  stage.appendChild(canvas);

  // 3. Bottom Emotion & Turn Controls Bar
  const controlsBar = document.createElement('nav');
  controlsBar.className = 'controls-bar';
  controlsBar.setAttribute('aria-label', 'Emotion Controls');

  const dirBtn = document.createElement('button');
  dirBtn.type = 'button';
  dirBtn.className = 'ctrl-btn dir-btn';
  dirBtn.textContent = 'Turn Left / Right';
  dirBtn.setAttribute('aria-label', 'Turn Left / Right');

  const motionButtons = new Map<MotionType, HTMLButtonElement>();

  dirBtn.addEventListener('click', () => {
    rig.toggleDirection();
    syncDOMState();
  });
  controlsBar.appendChild(dirBtn);

  for (const spec of ALL_TURTLE_EMOTIONS) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ctrl-btn';
    btn.dataset.action = spec.id;
    btn.textContent = spec.label;
    btn.addEventListener('click', () => {
      rig.setMotion(spec.id);
      syncDOMState();
    });
    motionButtons.set(spec.id, btn);
    controlsBar.appendChild(btn);
  }

  const blinkBtn = document.createElement('button');
  blinkBtn.type = 'button';
  blinkBtn.className = 'ctrl-btn';
  blinkBtn.dataset.action = 'blink';
  blinkBtn.textContent = 'Blink Eyes';
  blinkBtn.addEventListener('click', () => {
    rig.triggerBlink();
    blinkBtn.setAttribute('aria-pressed', 'true');
    window.setTimeout(() => {
      blinkBtn.setAttribute('aria-pressed', 'false');
    }, 520);
  });
  controlsBar.appendChild(blinkBtn);

  const getFilteredAssets = (): RosterAsset[] => {
    if (activeCategory === 'all') return ROSTER_ASSETS;
    return ROSTER_ASSETS.filter((a) => a.category === activeCategory);
  };

  const populateSelectOptions = () => {
    const list = getFilteredAssets();
    speciesSelect.innerHTML = '';
    for (const item of list) {
      const opt = document.createElement('option');
      opt.value = item.id;
      opt.textContent = `${item.code} — ${item.name}`;
      if (item.id === currentAsset.id) {
        opt.selected = true;
      }
      speciesSelect.appendChild(opt);
    }
  };

  const isGreenSeaTurtle = () => currentAsset.id === 'animal_28_green_sea_turtle';
  const isGiantPanda = () => currentAsset.id === 'animal_41_giant_panda';

  const isMotionAllowedForAsset = (motion: MotionType): boolean => {
    if (!currentAsset.isAnimal) return false;
    if (isGreenSeaTurtle()) return true;
    if (isGiantPanda()) return PANDA_EMOTIONS.has(motion);
    return STANDARD_ANIMAL_EMOTIONS.has(motion);
  };

  const syncDOMState = () => {
    if (currentAsset.isAnimal && !isMotionAllowedForAsset(rig.getMotion())) {
      rig.setMotion('idle');
    }

    const activeMotion = rig.getMotion();
    const activeDir = rig.getDirection();
    document.body.dataset.asset = currentAsset.id;
    document.body.dataset.code = currentAsset.code;
    document.body.dataset.kind = currentAsset.isAnimal ? 'animal' : 'plant';
    document.body.dataset.motion = activeMotion;
    document.body.dataset.direction = activeDir;
    dirBtn.dataset.direction = activeDir;

    for (const [catId, btn] of categoryButtons.entries()) {
      btn.setAttribute('aria-pressed', String(catId === activeCategory));
    }

    // Emotion buttons are enabled/shown ONLY for the 41 Animals (hidden for the 30 Plants)
    controlsBar.style.display = currentAsset.isAnimal ? 'flex' : 'none';

    const showAllTurtleEmotions = isGreenSeaTurtle();
    for (const [m, btn] of motionButtons.entries()) {
      const isAllowed = isMotionAllowedForAsset(m);
      btn.style.display = isAllowed ? 'inline-block' : 'none';
      if (m === 'sleepy') {
        btn.textContent = showAllTurtleEmotions ? 'Sleepy / Bored' : 'Sleepy';
      } else if (m === 'crying') {
        btn.textContent = showAllTurtleEmotions ? 'Crying' : 'Sad';
      }
      btn.setAttribute('aria-pressed', String(m === activeMotion));
    }

    if (speciesSelect.value !== currentAsset.id) {
      speciesSelect.value = currentAsset.id;
    }
  };

  for (const tab of CATEGORY_TABS) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'cat-tab-btn';
    btn.dataset.category = tab.id;
    btn.textContent = tab.label;
    btn.addEventListener('click', () => {
      activeCategory = tab.id;
      const filtered = getFilteredAssets();
      if (!filtered.some((a) => a.id === currentAsset.id) && filtered.length > 0) {
        currentAsset = filtered[0];
      }
      populateSelectOptions();
      syncDOMState();
    });
    categoryButtons.set(tab.id, btn);
    categoryGroup.appendChild(btn);
  }

  speciesSelect.addEventListener('change', () => {
    const found = ROSTER_ASSETS.find((a) => a.id === speciesSelect.value);
    if (found) {
      currentAsset = found;
      syncDOMState();
    }
  });

  const stepSpecies = (delta: number) => {
    const list = getFilteredAssets();
    const idx = list.findIndex((a) => a.id === currentAsset.id);
    const nextIdx = (idx + delta + list.length) % list.length;
    currentAsset = list[nextIdx];
    populateSelectOptions();
    syncDOMState();
  };

  prevBtn.addEventListener('click', () => stepSpecies(-1));
  nextBtn.addEventListener('click', () => stepSpecies(1));

  canvas.addEventListener('click', () => {
    if (currentAsset.isAnimal) {
      rig.triggerBlink();
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.target === speciesSelect) return;
    if (e.key === 'ArrowLeft' && currentAsset.isAnimal) {
      rig.setDirection('left');
      syncDOMState();
    } else if (e.key === 'ArrowRight' && currentAsset.isAnimal) {
      rig.setDirection('right');
      syncDOMState();
    } else if ((e.key === ' ' || e.key.toLowerCase() === 'b') && currentAsset.isAnimal) {
      rig.triggerBlink();
    } else if (e.key === '[') {
      stepSpecies(-1);
    } else if (e.key === ']') {
      stepSpecies(1);
    } else if (e.key >= '0' && e.key <= '9' && currentAsset.isAnimal) {
      const idx = e.key === '0' ? 9 : Number(e.key) - 1;
      const spec = ALL_TURTLE_EMOTIONS[idx];
      if (spec && isMotionAllowedForAsset(spec.id)) {
        rig.setMotion(spec.id);
        syncDOMState();
      }
    }
  });

  root.append(topBar, stage, controlsBar);
  populateSelectOptions();
  syncDOMState();

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  let cssWidth = 800;
  let cssHeight = 600;

  const handleResize = () => {
    const rect = stage.getBoundingClientRect();
    cssWidth = Math.max(300, rect.width);
    cssHeight = Math.max(260, rect.height);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(cssWidth * dpr);
    canvas.height = Math.round(cssHeight * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  handleResize();
  window.addEventListener('resize', handleResize);

  let lastTime = performance.now();
  let elapsedSec = 0;

  const renderFrame = (pose: ReturnType<typeof rig.step>) => {
    if (currentAsset.id === 'animal_28_green_sea_turtle') {
      renderTurtle(ctx, cssWidth, cssHeight, pose, rig.tearDrops);
    } else if (currentAsset.isAnimal) {
      renderAnimalAsset(
        ctx,
        currentAsset.id,
        cssWidth,
        cssHeight,
        pose,
        rig.tearDrops,
        elapsedSec
      );
    } else {
      renderPlantAsset(ctx, currentAsset.id, cssWidth, cssHeight, pose, elapsedSec);
    }
  };

  const animate = (now: number) => {
    const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
    lastTime = now;
    elapsedSec += dt;

    const pose = rig.step(dt);
    renderFrame(pose);

    requestAnimationFrame(animate);
  };

  const initialPose = rig.step(0.016);
  renderFrame(initialPose);
  requestAnimationFrame(animate);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
